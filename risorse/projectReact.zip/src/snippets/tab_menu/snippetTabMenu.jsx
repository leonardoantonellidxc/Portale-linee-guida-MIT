import TabMenu from "../../lib36/components/tab_menu/tabMenu";

let tab_button_1 = {
    id: 'tab0-1',
    type: 'active',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_button_2 = {
    id: 'tab0-2',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "save",
}

let tab_button_3 = {
    id: 'tab0-3',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_button_4 = {
    id: 'tab0-4',
    type: 'disabled',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "save",
}


let tab_light_button_1 = {
    id: 'tab1-1',
    type: 'active',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_light_button_2 = {
    id: 'tab1-2',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_light_button_3 = {
    id: 'tab1-3',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_light_button_4 = {
    id: 'tab1-4',
    type: 'disabled',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}


let tab_white_button_1 = {
    id: 'tab2-1',
    type: 'active',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_white_button_2 = {
    id: 'tab2-2',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_white_button_3 = {
    id: 'tab2-3',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

let tab_white_button_4 = {
    id: 'tab2-4',
    type: 'disabled',
    link: '#',
    text: 'Label text',
    sprite_example: '#it-example',
    button_action: "draft",
}

const actionFunc = (buttonCase) => {
    if (buttonCase) {
        switch (buttonCase) {
            case "back":
                window.location.replace("/events/page/2");
                break;

            case "draft":
                alert("Draft action here");
                break;
            case "save":
                alert("Save action here");
                break;
            default:
                alert("no default functions for case: " + buttonCase);

        }
    }
};

const SnippetTabMenu = () => {
    return (
        <div className="demon-view">
            <div className="container pb-8">
                <div className="pt-6">
                    <div className="pt-2 pt-lg-5">
                        <ul className={`nav nav-tabs`} id="null" role="tablist" >
                            < TabMenu ob={tab_button_1} activeFunctions={actionFunc} />
                            < TabMenu ob={tab_button_2} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_button_3} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_button_4} activeFunctions={actionFunc}/>
                        </ul>
                    </div>
                </div>
                <div className="pt-6">
                    <div className="pt-2 pt-lg-5">
                        <ul className={`light nav nav-tabs`} id="myTab1" role="tablist" >
                            < TabMenu ob={tab_light_button_1} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_light_button_2} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_light_button_3} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_light_button_4} activeFunctions={actionFunc}/>
                        </ul>
                    </div>
                </div>
                <div className="pt-6">
                    <div className="pt-2 pt-lg-5">
                        <ul className={`nav nav-tabs white`} id="null" role="tablist" >
                            < TabMenu ob={tab_white_button_1} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_white_button_2} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_white_button_3} activeFunctions={actionFunc}/>
                            < TabMenu ob={tab_white_button_4} activeFunctions={actionFunc}/>
                        </ul>
                    </div>
                </div>
            </div>
        </div>)
}

export default SnippetTabMenu;