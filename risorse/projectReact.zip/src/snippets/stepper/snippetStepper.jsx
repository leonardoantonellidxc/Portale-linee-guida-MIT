import Stepper from "../../lib36/components/stepper/stepper";

let stepper = {
    title: ' Titolo del flusso ',
    mobile_progress: {
        label_title: 'Step 3/6',
        label_percent: '50%'
    },
    sprite_example: "#it-example",
    item: [
        {
            step_icon_span: '1',
            type: '',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'Lorem ipsum',
            step_sprite: '',

        },
        {
            step_icon_span: '2',
            type: '',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'Lorem ipsum',
            step_sprite: '',

        },
        {
            step_icon_span: '',
            type: 'success',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'Completato',
            step_sprite: '#it-check-circle',
        },
        {
            type: 'active',
            step_icon_span: '3',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In corso',
            step_sprite: '',
        },
        {
            type: 'danger',
            step_icon_span: '',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In errore',
            step_sprite: '#it-error-circle',

        },
    ],
    mobile_item: [
        {
            type: '',
            step_icon_span: '1',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In corso',
            step_sprite: '',
            step_maximize_sprite: '#it-maximize',
            label_title: 'Step 1/6',
            label_percent: '20%',
        },
        {
            type: '',
            step_icon_span: '2',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In corso',
            step_sprite: '',
            step_maximize_sprite: '#it-maximize',
            label_title: 'Step 2/6',
            label_percent: '40%',
        },
        {
            type: 'success',
            step_icon_span: '',
            type: 'success',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In corso',
            step_sprite: '#it-check-circle',
            step_maximize_sprite: '#it-maximize',
            label_title: 'Step 3/6',
            label_percent: '60%',
        },
        {
            step_icon_span: '3',
            type: 'active',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In corso',
            step_sprite: '',
            step_maximize_sprite: '#it-maximize',
            label_title: 'Step 4/6',
            label_percent: '80%',
        },
        {
            step_icon_span: '',
            type: 'danger',
            step_info_title: 'Testo - in corso segnaposto',
            step_info_text: 'In corso',
            step_sprite: '#it-error-circle',
            step_maximize_sprite: '#it-maximize',
            label_title: 'Step error',
            label_percent: 'error',

        }]
};

const SnippetStepper = () => {
    return (
        <div className="demon-view">
            <div className="container pb-8">
                <div className="pt-6">
                    <div className="pt-2 pt-lg-5">
                        <Stepper ob={stepper} />
                    </div>
                </div>
            </div>
        </div>
    );

}

export default SnippetStepper;
