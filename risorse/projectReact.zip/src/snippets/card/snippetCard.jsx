import Card from "../../lib36/components/card/card";
import example_01 from '../../lib36/static/imgs/TMP/card/example-01.jpg';
import example_01_back from '../../lib36/static/imgs/TMP/card/example-back-01.jpg';



let card = {
    hover: "",
    card_img: example_01,
    clock_text: ' Lorem ipsum ',
    img_text: ' 10 Dicembre 2023 ',
    label_text_1: ' Label Text ',
    label_text_2: ' Label Text ',
    label_text_3: ' Label Text ',
    title: ' Titolo della card ',
    sub_title: 'Sottotitolo della card',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    title_alert_warning: 'Titolo alert warning',
    button_text1: ' Button text ',
    button_text2: ' Button text ',
    clock_sprite: "#it-clock",
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "draft",

}

let card_hover = {
    hover: 'hover',
    card_img: example_01,
    clock_text: ' Lorem ipsum ',
    img_text: ' 10 Dicembre 2023 ',
    label_text_1: ' Label Text ',
    label_text_2: ' Label Text ',
    label_text_3: ' Label Text ',
    title: ' Titolo della card ',
    sub_title: 'Sottotitolo della card',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    title_alert_warning: 'Titolo alert warning',
    button_text1: ' Button text ',
    button_text2: ' Button text ',
    clock_sprite: "#it-clock",
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "save",

}
let card_img_back = {
    hover: "",
    card_img_back: example_01_back,
    span_text_1: ' Lorem Ipsum ',
    span_text_2: ' Lorem Ipsum ',
    span_text_3: ' Lorem Ipsum ',
    title: ' Titolo della card ',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    button_text1: ' Button text ',
    button_text2: ' Button text ',
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "draft",

}

let card_img_back_hover = {
    hover: 'hover',
    card_img_back: example_01_back,
    span_text_1: ' Lorem Ipsum ',
    span_text_2: ' Lorem Ipsum ',
    span_text_3: ' Lorem Ipsum ',
    title: ' Titolo della card ',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    button_text1: ' Button text ',
    button_text2: ' Button text ',
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "draft",

}

let card_wrapper_primary = {
    wrapper: true,
    type: 'primary',
    label_text: ' Label Text ',
    title: ' Titolo della card ',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: ' Altre opzioni ',
    button_text2: ' Avvia verifica ',
    sprite: '#it-locked',
    border: "",
    badge_type: "badge-primary",
    button_action: "draft",
}
let card_wrapper_danger = {
    wrapper: true,
    type: 'danger',
    label_text: ' Label Text ',
    title: ' Titolo della card ',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: 'Altre opzioni ',
    button_text2: ' Avvia verifica ',
    sprite: '#it-error-circle',
    border: "",
    badge_type: "badge-danger",
    button_action: "draft",


}
let card_wrapper_success = {
    wrapper: true,
    type: 'success',
    label_text: ' Label Text ',
    title: ' Titolo della card ',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: ' Altre opzioni ',
    button_text2: ' Avvia verifica ',
    sprite: '#it-check-circle',
    border: "",
    badge_type: "badge-success",
    button_action: "draft",


}
let card_wrapper_warning = {
    wrapper: true,
    type: 'warning',
    label_text: ' Label Text ',
    title: ' Titolo della card ',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: ' Altre opzioni ',
    button_text2: ' Avvia verifica ',
    sprite: '#it-unlocked',
    border: "",
    badge_type: "badge-warning",
    button_action: "draft",


}
let card_wrapper_disabled = {
    wrapper: true,
    type: 'disabled',
    label_text: ' Label Text ',
    title: ' Titolo della card ',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: ' Altre opzioni ',
    button_text2: ' Avvia verifica ',
    sprite: '#it-primary',
    border: "disabled",
    badge_type: "disabled",
    button_action: "draft",


}

const actionFunc = (buttonCase) => {
    if (buttonCase) {
      switch (buttonCase) {
        case "back":
          window.location.replace("/events/page/2");
          break;
  
        case "draft":
          alert("Draft action here");
          break;
        case "save":
          alert("Save action here");
          break;
        default:
          alert("no default functions for case: " + buttonCase);
  
      }
    }
  };

const SnippetCard = () => {
    return (
        <div>
            <div className="demon-view">

                <div className="container pb-8">

                    <div className="">
                        <div className="row">
                            <div className="col-lg-4 pt-4">
                                <Card ob={card} activeFunctions={actionFunc}/>
                            </div>
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_hover} activeFunctions={actionFunc}/>
                            </div>
                        </div>
                    </div>
                    <div className="pt-4 pt-lg-5">
                        <div className="row">
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_img_back} activeFunctions={actionFunc}/>
                            </div>
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_img_back_hover} activeFunctions={actionFunc}/>
                            </div>
                        </div>
                    </div>
                    <div className="pt-4 pt-lg-5">
                        <div className="row">
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_wrapper_primary} activeFunctions={actionFunc}/>
                            </div>
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_wrapper_danger} activeFunctions={actionFunc}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-lg-4 pt-4">
                                < Card ob={card_wrapper_success} activeFunctions={actionFunc}/>
                            </div>
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_wrapper_warning} activeFunctions={actionFunc}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-lg-4 pt-4">
                                <Card ob={card_wrapper_disabled} activeFunctions={actionFunc}/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SnippetCard;
