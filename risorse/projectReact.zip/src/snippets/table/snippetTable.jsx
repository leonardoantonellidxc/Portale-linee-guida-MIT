import Table from "../../lib36/components/table/table";


const table_lg = {
    size: 'lg',
    sprite_more: '#it-more-actions',
    t_head: [
        {
            type: 'checkbox',
            check_name: 'field-0',
            check_value: '',
            aria_label: 'Lorem ipsum',
            checked: false,
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'text',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'text',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'badge',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'date',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'button',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        { type: 'more' }
    ],
    t_rows: [
        {
            active: false,
            td: [
                { type: 'checkbox', check_name: 'field-1', check_value: '', aria_label: 'Lorem ipsum', checked: false },
                { type: 'text', text: 'Label text' },
                { type: 'text', text: 'Label text' },
                { type: 'badge', text: 'Label text', badge_text: 'Badge' },
                { type: 'date', date: '01/01/2020' },
                { type: 'button', button_text: 'Button text', sprite_example: '#it-example', button_action: "draft", },
            ]
        },
    ],

    t_rows: [
        [
            {
                check_name: 'field-1',
                check_value: '',
                aria_label: 'Lorem ipsum',
            },
            {
                text: 'Label text',

            },
            {
                text: 'Label text'
            },
            {
                text: 'Label text',
                badge_text: 'Badge'
            },
            {
                date: '01/01/2020'
            },
            {
                button_text: 'Button text',
                link: '#',
                sprite_example: '#it-example',
                button_action: "draft",
            },
            {
                type: 'more', sprite_more: '#it-more-actions'
            }]
        ,
        [{
            check_name: 'field-2',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-3',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-4',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-5',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-6',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-7',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-8',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-9',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-10',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-11',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]

    ],
    t_rows_states: [
        { active: false },
        { active: true },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
    ]
};

let table_md = {
    size: 'md',
    sprite_more: '#it-more-actions',

    t_head: [
        {
            type: 'checkbox',
            check_name: 'field-12',
            check_value: '',
            aria_label: 'Lorem ipsum',
            checked: false,
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'text',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'text',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'badge',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'date',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        {
            type: 'button',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',
        },
        { type: 'more' }
    ],
    t_rows: [
        [
            {
                check_name: 'field-13',
                check_value: '',
                aria_label: 'Lorem ipsum',
            },
            {
                text: 'Label text'
            },
            {
                text: 'Label text'
            },
            {
                text: 'Label text',
                badge_text: 'Badge'
            },
            {
                date: '01/01/2020'
            },
            {
                button_text: 'Button text',
                link: '#',
                sprite_example: '#it-example',
                button_action: "draft",
            },
            {
            }]
        ,
        [{
            check_name: 'field-14',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-15',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-16',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-17',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-18',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-19',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-20',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-21',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-22',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-23',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
    ],
    t_rows_states: [
        { active: false },
        { active: true },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
    ]
}

let table_sm = {
    size: 'sm',
    sprite_more: '#it-more',
    t_head: [
        {
            type: 'checkbox',
            check_name: 'field-24',
            check_value: '',
            aria_label: 'Lorem ipsum',
            checked: false,
            sprite_sort: '#it-arrow-vertical',

        },
        {
            type: 'text',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',

        },
        {
            type: 'text',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',

        },
        {
            type: 'badge',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',

        },
        {
            type: 'date',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',

        },
        {
            type: 'button',
            span_title: 'Title',
            sprite_sort: '#it-arrow-vertical',

        },
        { type: 'more' }
    ],
    t_rows: [
        [
            {
                check_name: 'field-25',
                check_value: '',
                aria_label: 'Lorem ipsum',
            },
            {
                text: 'Label text'
            },
            {
                text: 'Label text'
            },
            {
                text: 'Label text',
                badge_text: 'Badge'
            },
            {
                date: '01/01/2020'
            },
            {
                button_text: 'Button text',
                link: '#',
                sprite_example: '#it-example',
                button_action: "draft",
            },
            {
            }]
        ,
        [{
            check_name: 'field-26',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-27',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-28',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-29',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-30',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-31',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-32',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-33',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-34',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
        [{
            check_name: 'field-35',
            check_value: '',
            aria_label: 'Lorem ipsum',
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text'
        },
        {
            text: 'Label text',
            badge_text: 'Badge'
        },
        {
            date: '01/01/2020'
        },
        {
            button_text: 'Button text',
            link: '#',
            sprite_example: '#it-example',
            button_action: "draft",
        },
        {
        }]
        ,
    ],
    t_rows_states: [
        { active: false },
        { active: true },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
        { active: false },
    ]
}

const actionFunc = (buttonCase) => {
    if (buttonCase) {
      switch (buttonCase) {
        case "back":
          window.location.replace("/events/page/2");
          break;
  
        case "draft":
          alert("Draft action here");
          break;
        case "save":
          alert("Save action here");
          break;
        default:
          alert("no default functions for case: " + buttonCase);
  
      }
    }
  };


const SnippetTable = () => {
    return (<div>
        <div className="demon-view">
            <div className="container pb-8">
                <div className="pt-6">
                    <div className="h2">Table LG</div>
                    <div className="pt-2 pt-lg-5">
                        <Table ob={table_lg} activeFunctions={actionFunc}/>
                    </div>
                </div>
                <div className="pt-6">
                    <div className="h2">Table MD</div>
                    <div className="pt-2 pt-lg-5">
                        <Table ob={table_md} activeFunctions={actionFunc}/>
                    </div>
                </div>
                <div className="pt-6">
                    <div className="h2">Table SM</div>
                    <div className="pt-2 pt-lg-5">
                        <Table ob={table_sm} activeFunctions={actionFunc}/>
                    </div>
                </div>
            </div >
        </div >

    </div >)

}

export default SnippetTable;