import HeroBanner from "../../lib36/components/hero_banner/heroBanner";
import header_01 from '../../lib36/static/imgs/TMP/hero_banner/header-01.jpg';

let hero_banner_l1 = {
    level: 1,
    title: 'Titolo',
    subtitle: 'Inserisci qui il sottotitolo',
    body_text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididuntLorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor`,
    button_action: "draft",

    inputSearch: {
        name: 'field1',
        placeholder: 'Cerca tra tutti i servizi...',
        value: '',
        is_search_sprite: '#it-search',
    },
    chips: [
        { chip: 'Lorem ipsum', is_example_sprite: "#it-example", button_action: "draft", },
        { chip: 'Lorem ipsum', is_example_sprite: "#it-example", button_action: "draft", },
        { chip: 'Lorem ipsum', is_example_sprite: "#it-example", button_action: "draft", },
    ],
    cards: [
        {
            title: 'Titolo della card',
            text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit
              aliquam pretium porta dolor mauris. Amet ut duis in non.`,
            buttonText: 'Button text',
            is_example_sprite: "#it-example",
            is_arrow_sprite: "#it-arrow-right",
            button_action: "draft",
        },
        {
            title: 'Titolo della card',
            text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit
              aliquam pretium porta dolor mauris. Amet ut duis in non.`,
            buttonText: 'Button text',
            is_example_sprite: "#it-example",
            is_arrow_sprite: "#it-arrow-right",
            button_action: "draft",
        },
        {
            title: 'Titolo della card',
            text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit
              aliquam pretium porta dolor mauris. Amet ut duis in non.`,
            buttonText: 'Button text',
            is_example_sprite: "#it-example",
            is_arrow_sprite: "#it-arrow-right",
            button_action: "draft",
        }
    ]
};

let hero_banner_l2 = {
    level: 2,
    title: 'Titolo',
    subtitle: 'Inserisci qui il sottotitolo',
    button_action: "draft",
    body_text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididuntLorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor`,
    inputSearch: {
        name: 'field1',
        placeholder: 'Cerca tra tutti i servizi...',
        value: '',
        is_search_sprite: '#it-search',
    },
    chips: [
        { chip: 'Lorem ipsum', is_example_sprite: "#it-example", button_action: "draft", },
        { chip: 'Lorem ipsum', is_example_sprite: "#it-example", button_action: "draft", },
        { chip: 'Lorem ipsum', is_example_sprite: "#it-example", button_action: "draft", },
    ],
    breadcrumb: [
        {
            link: '#',
            pageTitle: 'Page',
            active: false
        },
        {
            link: '#',
            pageTitle: 'Page',
            active: false
        },
        {
            link: '#',
            pageTitle: 'Page',
            active: false
        },
        {
            pageTitle: 'Page',
            active: true
        }
    ],
    image: {
        src: header_01,
        alt: 'Lorem ipsum'
    }
};

const actionFunc = (buttonCase) => {
    if (buttonCase) {
        switch (buttonCase) {
            case "back":
                window.location.replace("/events/page/2");
                break;

            case "draft":
                alert("Draft action here");
                break;
            case "save":
                alert("Save action here");
                break;
            default:
                alert("no default functions for case: " + buttonCase);

        }
    }
};

const SnippetHeroBanner = () => {
    return (
        <div className="demon-view">
            <div>
                <div className="container pt-8 pb-4">
                </div>
                <HeroBanner ob={hero_banner_l1} activeFunctions={actionFunc} />
                <div className="container pt-8 pb-4">
                </div>
                <HeroBanner ob={hero_banner_l2} activeFunctions={actionFunc} />
            </div>
        </div>
    )
};

export default SnippetHeroBanner;