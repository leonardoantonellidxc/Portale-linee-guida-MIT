import SidebarNavigation from "../../lib36/components/sidebar_navigation/sidebarNavigation";

let navigation = {
    title: 'Sidebar Navigation',
    items: [
        {
            isDropdown: false,
            link: '#',
            text: 'Lorem ipsum',
            hover: false,
            sprite_expand: '#it-expand',
            sub_items: [
                {
                    isActive: false,
                    text: 'Lorem ipsum',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: true,
                    text: 'Lorem ipsum',
                    hover: false,
                    button_action: "save",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum',
                    hover: false,
                    button_action: "save",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum',
                    hover: false,
                    button_action: "draft",
                },
            ]
        },
        {
            isDropdown: true,
            link: '#',
            text: 'Lorem ipsum',
            sprite_expand: '#it-expand',
            sub_items: [
                {
                    isActive: false,
                    text: 'Lorem ipsum1',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum2',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: true,
                    text: 'Lorem ipsum3',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum4',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum5',
                    hover: false,
                    button_action: "draft",
                },
                {
                    isActive: false,
                    text: 'Lorem ipsum6',
                    hover: false,
                    button_action: "draft",
                },
            ]
        },
        {
            isDropdown: false,
            link: '#',
            text: 'Lorem ipsum',
            hover: false,
            sprite_expand: '#it-expand',
            button_action: "draft",
        },
        {
            isDropdown: false,
            link: '#',
            text: 'Lorem ipsum',
            hover: false,
            sprite_expand: '#it-expand',
            button_action: "draft",
        },
        {
            isDropdown: false,
            link: '#',
            text: 'Lorem ipsum',
            hover: false,
            sprite_expand: '#it-expand',
            button_action: "draft",
        },
        {
            isDropdown: false,
            link: '#',
            text: 'Lorem ipsum',
            hover: false,
            sprite_expand: '#it-expand',
            button_action: "draft",
        },
    ]
}

const actionFunc = (buttonCase) => {
    if (buttonCase) {
      switch (buttonCase) {
        case "back":
          window.location.replace("/events/page/2");
          break;
  
        case "draft":
          alert("Draft action here");
          break;
        case "save":
          alert("Save action here");
          break;
        default:
          alert("no default functions for case: " + buttonCase);
  
      }
    }
  };


const SnippetSidebarNavigation = () => {
    return (
        <div className="demon-view">
            <SidebarNavigation ob={navigation} activeFunctions={actionFunc}/>
        </div>)
};

export default SnippetSidebarNavigation;