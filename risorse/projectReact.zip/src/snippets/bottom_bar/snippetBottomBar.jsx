import BottomBar from "../../lib36/components/bottom_bar/bottomBar"


const ob_light = {
    type_bottom_bar: "",
    left_group: [
        {
            type: "danger",
            subtype: "",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "link",
            subtype: "",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        }
    ],
    right_group: [
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        }
    ]
};

const ob_dark = {
    type_bottom_bar: " bar-dark",
    left_group: [
        {
            type: "danger",
            subtype: "",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "btn-link",
            subtype: "",
            size: "btn-outline-white",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        }
    ],
    right_group: [
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        },
        {
            type: "primary",
            subtype: "icon",
            size: "",
            text: "Button text",
            sprite: "#it-example",
            button_action: "draft",
        }
    ]
};

const actionFunc = (buttonCase) => {
    if (buttonCase) {
        switch (buttonCase) {
            case "back":
                window.location.replace("/events/page/2");
                break;

            case "draft":
                alert("Draft action here");
                break;
            case "save":
                alert("Save action here");
                break;
            default:
                alert("no default functions for case: " + buttonCase);

        }
    }
};

const SnippetBottomBar = () => {
    return (
        <div className="demon-view">
            <div className="container pb-8">
                <div className="h2">Bottom bar</div>
                <div className="pt-6">
                    <div className="bg-primary10 px-5">
                        <BottomBar ob={ob_light} activeFunctions={actionFunc} />
                    </div>
                </div>
                <div className="pt-6">
                    <div className=" bg-primary95 px-5 mt-4 ">
                        <BottomBar ob={ob_dark} activeFunctions={actionFunc} />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SnippetBottomBar