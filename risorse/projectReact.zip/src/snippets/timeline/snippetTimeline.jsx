import Timeline from "../../lib36/components/timeline/timeline";

let ob_timeline_default = {
  type: "primary",
  date: "15/04/2024",
  subtype: "",
  state: "In lavorazione",
  title: "La pratica è in gestione alla DGT Nord Ovest",
  body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.`,
  firstButtonText: "Aprova documento",
  secondButtonText: "Label text",
  sprite_icon: "#it-example",
  button_action: "draft",
};
let ob_timeline_active = {
  type: "primary",
  subtype: "active",
  date: "15/04/2024",
  state: "In lavorazione",
  title: "La pratica è in gestione alla DGT Nord Ovest",
  body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
  do eiusmod tempor incididunt ut labore.`,
  firstButtonText: "Aprova documento",
  secondButtonText: "Label text",
  sprite_icon: "#it-example",
  button_action: "draft",
};

let ob_timeline_success = {
  type: "success",
  date: "15/04/2024",
  state: "In lavorazione",
  title: "La pratica è in gestione alla DGT Nord Ovest",
  body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
  do eiusmod tempor incididunt ut labore.`,
  firstButtonText: "Aprova documento",
  secondButtonText: "Label text",
  subtype: "success",
  sprite_icon: "#it-check-circle",
  button_action: "draft",
};

let ob_timeline_warning = {
  type: "warning",
  date: "15/04/2024",
  state: "In lavorazione",
  title: "La pratica è in gestione alla DGT Nord Ovest",
  body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
  do eiusmod tempor incididunt ut labore.`,
  firstButtonText: "Aprova documento",
  secondButtonText: "Label text",
  subtype: "warning",
  sprite_icon: "#it-warning",
  button_action: "draft",
};
let ob_timeline_danger = {
  type: "danger",
  date: "15/04/2024",
  state: "In lavorazione",
  title: "La pratica è in gestione alla DGT Nord Ovest",
  body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
  do eiusmod tempor incididunt ut labore.`,
  firstButtonText: "Aprova documento",
  secondButtonText: "Label text",
  subtype: "danger",
  sprite_icon: "#it-error-circle",
  button_action: "draft",
};

const actionFunc = (buttonCase) => {
  if (buttonCase) {
    switch (buttonCase) {
      case "back":
        window.location.replace("/events/page/2");
        break;

      case "draft":
        alert("Draft action here");
        break;
      case "save":
        alert("Save action here");
        break;
      default:
        alert("no default functions for case: " + buttonCase);

    }
  }
};

const SnippetTimeline = () => {
  return (
    <div className="container py-5" id="demonView4-402-1">
      <div className="row">
        <div className="col-md-6 col-lg-4 pt-4">
          <div className="pt-3">
          <div className="h6">Default</div>
            <Timeline ob={ob_timeline_default} activeFunctions={actionFunc} />
          </div>
        </div>
        <div className="col-md-6 col-lg-4 pt-4">
          <div className="pt-3">
          <div className="h6">Active</div>
            <Timeline ob={ob_timeline_active} activeFunctions={actionFunc}/>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6 col-lg-4 pt-4">
          <div className="pt-3">
          <div className="h6">Success</div>
            <Timeline ob={ob_timeline_success} activeFunctions={actionFunc}/>
          </div>
        </div>
        <div className="col-md-6 col-lg-4 pt-4">
          <div className="pt-3">
          <div className="h6">Warning</div>
            <Timeline ob={ob_timeline_warning} activeFunctions={actionFunc}/>
          </div>
        </div>
        <div className="col-md-6 col-lg-4 pt-4">
          <div className="pt-3">
          <div className="h6">Danger</div>
            <Timeline ob={ob_timeline_danger} activeFunctions={actionFunc}/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SnippetTimeline;
