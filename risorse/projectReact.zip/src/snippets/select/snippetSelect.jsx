import Select from "../../lib36/form/select/select";

let ob_select_fields_left = {
  id: "field1Label",
  type: "",
  is_icon: true,
  options: [
    {
      value: '0', text: ''
    },
    {
      value: '1',
      text: 'Lorem ipsum 1',
    },
    {
      value: '2',
      text: 'Lorem ipsum 2'
    }
  ],
  message: "Testo informativo",
  sprite_fill: "#it-info-circle",
  sprite_example: "#it-example",
};


let ob_select_fields_right = {
  id: "field5Label",
  type: "",
  is_icon: false,
  options: [
    {
      value: '0', text: ''
    },
    {
      value: '1',
      text: 'Lorem ipsum 1',
    },
    {
      value: '2',
      text: 'Lorem ipsum 2'
    }
  ],
  message: "Testo informativo",
  sprite_fill: "#it-info-circle",
  sprite_example: "#it-example",
};

let ob_select_fields_disabled_left = {
  id: "field1Label",
  type: "disabled",
  is_icon: true,
  message: "Testo informativo",
  sprite_fill: "#it-info-circle",
  sprite_example: "#it-example",
};

let ob_select_fields_disabled_right = {
  id: "field5Label",
  type: "disabled",
  is_icon: false,
  message: "Testo informativo",
  sprite_fill: "#it-info-circle",
  sprite_example: "#it-example",
};

let ob_select_fields_readonly_left = {
  id: "field1Label",
  type: "readonly",
  is_icon: true,
  message: "Testo informativo",
  sprite_fill: "#it-info-circle",
  sprite_example: "#it-example",
};

let ob_select_fields_readonly_right = {
  id: "field5Label",
  type: "readonly",
  is_icon: false,
  message: "Testo informativo",
  sprite_fill: "#it-info-circle",
  sprite_example: "#it-example",
};

let ob_select_fields_invalid_left = {
  id: "field1Label",
  type: "is-invalid",
  is_icon: true,
  options: [
    {
      value: '0', text: ''
    },
    {
      value: '1',
      text: 'Lorem ipsum 1',
    },
    {
      value: '2',
      text: 'Lorem ipsum 2'
    }
  ],
  message: "Message explaining the error ",
  sprite_fill: "#it-error",
  sprite_example: "#it-example",
};

let ob_select_fields_invalid_right = {
  id: "field5Label",
  type: "is-invalid",
  is_icon: false,
  options: [
    {
      value: '0', text: ''
    },
    {
      value: '1',
      text: 'Lorem ipsum 1',
    },
    {
      value: '2',
      text: 'Lorem ipsum 2'
    }
  ],
  message: "Message explaining the error ",
  sprite_fill: "#it-error",
  sprite_example: "#it-example",
};

let ob_select_fields_valid_left = {
  id: "field1Label",
  type: "is-valid",
  is_icon: true,
  options: [
    {
      value: '0', text: ''
    },
    {
      value: '1',
      text: 'Lorem ipsum 1',
    },
    {
      value: '2',
      text: 'Lorem ipsum 2'
    }
  ],
  message: "Message explaining the success",
  sprite_fill: "#it-check-circle",
  sprite_example: "#it-example",
};

let ob_select_fields_valid_right = {
  id: "field5Label",
  type: "is-valid",
  is_icon: false,
  options: [
    {
      value: '0', text: ''
    },
    {
      value: '1',
      text: 'Lorem ipsum 1',
    },
    {
      value: '2',
      text: 'Lorem ipsum 2'
    }
  ],
  message: "Message explaining the success",
  sprite_fill: "#it-check-circle",
  sprite_example: "#it-example",
};



const SnippetSelect = () => {


  return (
    <div>
      <div className="demon-view">
        <div className="container pb-7">
          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_left} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_left} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_right} />
                </div>
              </div>
            </div>
          </div>
          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_disabled_left} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_disabled_right} />
                </div>
              </div>
            </div>
          </div>
          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_readonly_left} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_readonly_right} />
                </div>
              </div>
            </div>
          </div>
          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_invalid_left} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_invalid_right} />
                </div>
              </div>
            </div>
          </div>
          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_valid_left} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Select ob={ob_select_fields_valid_right} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SnippetSelect;