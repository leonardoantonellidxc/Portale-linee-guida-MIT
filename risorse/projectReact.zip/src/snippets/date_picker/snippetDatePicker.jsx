import DatePicker from "../../lib36/form/date_picker/datePicker";


let date_picker = {
  type: '',
  title: 'Label field',
  name: 'field1',
  value: '',
  message: '',
  sprite_image: '',
  div_type: '',
  is_hover: true,
  months: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
  years: [2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024],
  calendar_sprite: '#it-calendar',
  expand_sprite: '#it-expand',
}

let date_picker_disabled = {
  type: 'disabled',
  title: 'Label field',
  name: 'field1',
  value: '28/07/2024',
  message: '',
  sprite_image: '',
  div_type: '',
  is_hover: false,
  months: "",
  years: "",
  calendar_sprite: '#it-calendar',
  expand_sprite: '#it-expand',

}
let date_picker_read_only = {
  type: 'readonly',
  title: 'Label field',
  name: 'field1',
  value: '28/07/2024',
  message: '',
  sprite_image: '',
  div_type: '',
  is_hover: false,
  months: "",
  years: "",
  calendar_sprite: '#it-calendar',
  expand_sprite: '#it-expand',

}
let date_picker_valid = {
  type: 'is-valid',
  title: 'Label field',
  name: 'field1',
  value: '28/07/2024',
  message: 'Message explaining the success',
  sprite_image: '#it-check-circle',
  div_type: 'valid',
  is_hover: false,
  months: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
  years: [2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024],
  calendar_sprite: '#it-calendar',
  expand_sprite: '#it-expand',
  toValidate: true,
}
let date_picker_invalid = {
  type: 'is-invalid',
  title: 'Label field',
  name: 'field1',
  value: '28/07/2024',
  message: 'Message explaining the error',
  sprite_image: '#it-error-circle',
  div_type: 'invalid',
  is_hover: false,
  months: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
  years: [2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024],
  calendar_sprite: '#it-calendar',
  expand_sprite: '#it-expand',
  toValidate: true,

}
const SnippetDatePicker = ({ ob }) => {
  return (
    <div>
      <div>
        <div className="demon-view">
          <div className="container pb-7" demon-form="test">
            <div className="pt-3 pt-lg-7">
              <div className="row">
                <div className="col-lg-4 pt-3 pt-lg-5">
                  <DatePicker ob={date_picker} />
                </div>
                <div className="col-lg-4 pt-3 pt-lg-5">
                  <DatePicker ob={date_picker_disabled} />
                </div>
                <div className="col-lg-4 pt-3 pt-lg-5">
                  <DatePicker ob={date_picker_read_only} />
                </div>
              </div>
            </div>
            <div className="pt-3 pt-lg-7">
              <div className="pt-3 pt-lg-5">
                <DatePicker ob={date_picker_valid} />
              </div>
            </div>
            <div className="pt-3 pt-lg-7">
              <div className="pt-3 pt-lg-5">
                <DatePicker ob={date_picker_invalid} />
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

export default SnippetDatePicker;