import Modali from "../../lib36/components/modali/modali"

let button_sm = {

    open_button_text: 'Apri la modale sm',
    ID: '1',
    heading: 'Intestazione modale',
    state_message_description: 'Breve descrizione del messaggio di stato',
    state_message: `Lorem ipsum dolor sit amet consectetur. Fusce egestas diam viverra
            massa purus. Dolor consectetur ac turpis at turpis aliquam eleifend.
            Praesent in faucibus fringilla magna in velit netus faucibus.Lorem
            ipsum dolor sit amet consectetur. Fusce egestas diam viverra massa
            purus. Dolor consectetur ac turpis at turpis aliquam eleifend.
            Praesent in faucibus fringilla magna in velit netus faucibus.`,
    size: 'sm',
    example_sprite: '#it-example',
    close_circle_sprite: "#it-close-circle",
    info_sprite: "#it-info-circle",
    labeled_inputs: [
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field1',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field2',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field3',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field4',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
    ],
    text_area: {
        id: 10,
        name: 'field10',
        placeholder: 'Placeholder field',
        value: 'Lorem ipsum',
        rows: '4'
    },
    alert: {
        title: 'Titolo alert info',
        text: `Vel tempus nisl augue accumsan, scelerisque aliquet. Nibh arcu
                  risus massa ut elementum viverra iaculis. Eu lectus.`,
        close_circle_sprite: "#it-close-circle",
    },
    radio_elements: [
        {
            id: 20,
            name: 'field20',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
        {
            id: 21,
            name: 'field21',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
        {
            id: 22,
            name: 'field22',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
    ]

}

let button_md = {

    open_button_text: 'Apri la modale md',
    ID: '2',
    heading: 'Intestazione modale',
    state_message_description: 'Breve descrizione del messaggio di stato',
    state_message: `Lorem ipsum dolor sit amet consectetur. Fusce egestas diam viverra
            massa purus. Dolor consectetur ac turpis at turpis aliquam eleifend.
            Praesent in faucibus fringilla magna in velit netus faucibus.Lorem
            ipsum dolor sit amet consectetur. Fusce egestas diam viverra massa
            purus. Dolor consectetur ac turpis at turpis aliquam eleifend.
            Praesent in faucibus fringilla magna in velit netus faucibus.`,
    size: 'md',
    example_sprite: '#it-example',
    close_circle_sprite: "#it-close-circle",
    info_sprite: "#it-info-circle",
    labeled_inputs: [
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field1',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field2',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field3',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field4',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
    ],
    text_area: {
        id: 10,
        name: 'field10',
        placeholder: 'Placeholder field',
        value: 'Lorem ipsum',
        rows: '4'
    },
    alert: {
        title: 'Titolo alert info',
        text: `Vel tempus nisl augue accumsan, scelerisque aliquet. Nibh arcu
                  risus massa ut elementum viverra iaculis. Eu lectus.`,
        close_circle_sprite: "#it-close-circle",
    },
    radio_elements: [
        {
            id: 20,
            name: 'field20',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
        {
            id: 21,
            name: 'field21',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
        {
            id: 22,
            name: 'field22',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
    ]

}

let button_lg = {

    open_button_text: 'Apri la modale lg',
    ID: '3',
    heading: 'Intestazione modale',
    state_message_description: 'Breve descrizione del messaggio di stato',
    state_message: `Lorem ipsum dolor sit amet consectetur. Fusce egestas diam viverra
            massa purus. Dolor consectetur ac turpis at turpis aliquam eleifend.
            Praesent in faucibus fringilla magna in velit netus faucibus.Lorem
            ipsum dolor sit amet consectetur. Fusce egestas diam viverra massa
            purus. Dolor consectetur ac turpis at turpis aliquam eleifend.
            Praesent in faucibus fringilla magna in velit netus faucibus.`,
    size: 'lg',
    example_sprite: '#it-example',
    close_circle_sprite: "#it-close-circle",
    info_sprite: "#it-info-circle",
    labeled_inputs: [
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field1',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field2',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field3',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
        {
            id: 1,
            label_text: ' Label field ',
            placeholder: 'Placeholder field',
            name: 'field4',
            value: 'Lorem ipsum',
            example_sprite: '#it-example',
        },
    ],
    text_area: {
        id: 10,
        name: 'field10',
        placeholder: 'Placeholder field',
        value: 'Lorem ipsum',
        rows: '4'
    },
    alert: {
        title: 'Titolo alert info',
        text: `Vel tempus nisl augue accumsan, scelerisque aliquet. Nibh arcu
                  risus massa ut elementum viverra iaculis. Eu lectus.`,
        close_circle_sprite: "#it-close-circle",
    },
    radio_elements: [
        {
            id: 20,
            name: 'field20',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
        {
            id: 21,
            name: 'field21',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
        {
            id: 22,
            name: 'field22',
            value: '1',
            label_radio: 'Label radio',
            text: `Ut enim ad minim veniam, quis nostrud exercitation
                          ullamco laboris nisi ut aliquip ex ea commodo con`
        },
    ]

}


const SnippetModali = () => {
    return (
        <div className="demon-view">
            <div className="container py-5">
                <div className="row">
                    <Modali ob={button_sm} />
                    <Modali ob={button_md} />
                    <Modali ob={button_lg} />
                </div>
            </div>
        </div >)
}

export default SnippetModali