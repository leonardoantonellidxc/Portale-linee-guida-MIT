import Pagination from "../../lib36/components/pagination/pagination";


let pagination_arrows = {
    arrows: true,
    active: 1,
    lastPage: 100,
    range: 4,
    double_arrow_left: "#it-double-arrow-left",
    chevron_left: "#it-chevron-left",
    chevron_right: "#it-chevron-right",
    double_arrow_right: "#it-double-arrow-right",
}

let pagination_text = {
    text: true,
    active: 1,
    lastPage: 100,
    range: 4,
}

let pagination_select_page = {
    arrows: true,
    text: true,
    skip_page: true,
    active: 1,
    lastPage: 100,
    range: 4,
    input_name: 'fieldSkip1',
    input_value: '',
    input_id: 'fieldSkip1Label',
    double_arrow_left: "#it-double-arrow-left",
    chevron_left: "#it-chevron-left",
    chevron_right: "#it-chevron-right",
    double_arrow_right: "#it-double-arrow-right",
}

let pagination_select_page_dropdown = {
    arrows: true,
    text: true,
    skip_page: true,
    dropdown: true,
    active: 1,
    lastPage: 100,
    range: 4,
    double_arrow_left: "#it-double-arrow-left",
    chevron_left: "#it-chevron-left",
    chevron_right: "#it-chevron-right",
    double_arrow_right: "#it-double-arrow-right",
    select: {
        name: 'fieldSkip2',
        value: '',
        options: [
            { value: '1', selected: true },
            { value: '2' },
            { value: '3' },
            { value: '4' },
            { value: '5' },
            { value: '6' },
        ]
    }
}

const SnippetPagination = () => {

    const setActive = (page) => {
        console.log(`Changing to page ${page}`);
    };

    return (
        <div className="demon-view">
            <div className="container pb-8">
                <div className="pt-6">
                    <div className="pt-2 pt-lg-5">
                        <Pagination ob={pagination_arrows} setActive={setActive} />
                    </div>
                    <div className="pt-2 pt-lg-5">
                        <Pagination ob={pagination_text} setActive={setActive} />
                    </div>
                    <div className="pt-2 pt-lg-5">
                        <Pagination ob={pagination_select_page} setActive={setActive} />
                    </div>
                    <div className="pt-2 pt-lg-5">
                        <Pagination ob={pagination_select_page_dropdown} setActive={setActive} />
                    </div >
                </div >
            </div >
        </div >

    )
};

export default SnippetPagination;