
import Slider from "../../lib36/form/slider/slider.jsx";

let slider_2_range_field = {
    id: 'field1Label',
    label_text: 'Label field',
    range_field: 2,
    min: 0,
    max: 100,
    disabled: "",
    initial: 50,
    invalid: "",
    valid: "",
    sprite_info_circle: '#it-info-circle',
    sprite_example: '#it-example',
}
let slider_1_range_field = {
    id: 'field2Label',
    label_text: 'Label field',
    range_field: 1,
    min: 0,
    max: 100,
    disabled: "",
    initial: 50,
    invalid: "",
    valid: "",
    sprite_info_circle: '#it-info-circle',
    sprite_example: '#it-example',
}
let slider_2_range_field_disabled = {
    id: 'field10Label',
    label_text: 'Label field',
    range_field: 2,
    min: 0,
    max: 100,
    disabled: 'disabled',
    invalid: '',
    valid: "",
    sprite_info_circle: '#it-info-circle',
    sprite_example: '#it-example',
}
let slider_1_range_field_disabled = {
    id: 'field1Label',
    label_text: 'Label field',
    range_field: 1,
    min: 0,
    max: 100,
    disabled: 'disabled',
    initial: 50,
    invalid: '',
    valid: "",
    sprite_info_circle: '#it-info-circle',
    sprite_example: '#it-example',
}
let slider_2_range_field_invalid = {
    id: 'field20Label',
    label_text: 'Label field',
    range_field: 2,
    min: 0,
    max: 100,
    disabled: "",
    initial: 50,
    invalid: "is-invalid",
    valid: "",
    sprite_info_circle: '#it-info-circle',
    sprite_example: '#it-example',
}
let slider_2_range_field_valid = {
    id: 'field30Label',
    label_text: 'Label field',
    range_field: 2,
    min: 0,
    max: 100,
    disabled: "",
    initial: 50,
    invalid: '',
    valid: "is-valid",
    minValid: 20,
    maxValid: 50,
    toValidate: true,
    sprite_info_circle: '#it-info-circle',
    sprite_example: '#it-example',
}
const SnippetSlider = () => {
    return (
        <div className="demon-view">
            <div className="container pb-7">
                <div className="pt-3 pt-lg-7">
                    <div className="pt-2 pt-lg-5">
                        <div className="row">
                            <div className="col-md-6 col-lg-4 pt-3 pt-lg-5">
                                <Slider ob={slider_2_range_field} />
                            </div>
                            <div className="col-md-6 col-lg-4 pt-3 pt-lg-5">
                                <Slider ob={slider_1_range_field} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="pt-3 pt-lg-7">
                    <div className="pt-2 pt-lg-5">
                        <div className="row">
                            <div className="col-md-6 col-lg-4 pt-3 pt-lg-5">
                                <Slider ob={slider_2_range_field_disabled} />
                            </div>
                            <div className="col-md-6 col-lg-4 pt-3 pt-lg-5">
                                <Slider ob={slider_1_range_field_disabled} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="pt-3 pt-lg-7">
                    <div className="pt-2 pt-lg-5">
                        <div className="row">
                            <div className="col-md-6 col-lg-4 pt-3 pt-lg-5">
                                <Slider ob={slider_2_range_field_invalid} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="pt-3 pt-lg-7">
                    <div className="pt-2 pt-lg-5">
                        <div className="row">
                            <div className="col-md-6 col-lg-4 pt-3 pt-lg-5">
                                <Slider ob={slider_2_range_field_valid} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SnippetSlider;