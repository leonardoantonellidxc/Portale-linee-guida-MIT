import Input from "../../lib36/form/input/input"
import Form from "../../lib36/form/input/form"


let ob_input_field_1 = {
  disabled: false,
  readonly: false,
  name: 'field1',
  type: "",
  value: 'Lorem ipsum',
  example: true,
  show: true,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  example_sprite: "#it-example",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',

}

let ob_input_field_2 = {
  disabled: false,
  readonly: false,
  name: 'field2',
  type: "",
  value: 'Lorem ipsum',
  example: true,
  show: false,
  hide: false,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  example_sprite: "#it-example",

}

let ob_input_field_3 = {
  disabled: false,
  readonly: false,
  name: 'field3',
  type: "",
  value: 'Lorem ipsum',
  example: false,
  show: true,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_4 = {
  disabled: false,
  readonly: false,
  name: 'field4',
  type: "",
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  password_hide: '#it-password-hide',
}
let ob_input_field_5 = {
  disabled: false,
  readonly: false,
  name: 'field5',
  type: "",
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: false,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",

}

let ob_input_field_disabled_field1 = {
  disabled: true,
  readonly: false,
  name: 'field1',
  type: "disabled",
  value: 'Lorem ipsum',
  example: true,
  show: true,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  example_sprite: "#it-example",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_disabled_field2 = {
  disabled: true,
  readonly: false,
  name: 'field2',
  type: "disabled",
  value: 'Lorem ipsum',
  example: true,
  show: false,
  hide: false,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  example_sprite: "#it-example",
}

let ob_input_field_disabled_field3 = {
  disabled: true,
  readonly: false,
  name: 'field3',
  type: "disabled",
  value: 'Lorem ipsum',
  example: false,
  show: true,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_disabled_field4 = {
  disabled: true,
  readonly: false,
  name: 'field4',
  type: "disabled",
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  password_hide: '#it-password-hide',
}
let ob_input_field_disabled_field5 = {
  disabled: true,
  readonly: false,
  name: 'field5',
  type: "disabled",
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: false,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
}
let ob_input_field_readonly_field1 = {
  disabled: false,
  readonly: true,
  name: 'field1',
  type: "readonly",
  value: 'Lorem ipsum',
  example: true,
  show: true,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  example_sprite: "#it-example",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_readonly_field2 = {
  disabled: false,
  readonly: true,
  name: 'field2',
  type: "readonly",
  value: 'Lorem ipsum',
  example: true,
  show: false,
  hide: false,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  example_sprite: "#it-example",
}

let ob_input_field_readonly_field3 = {
  disabled: false,
  readonly: true,
  name: 'field3',
  type: "readonly",
  value: 'Lorem ipsum',
  example: false,
  show: true,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_readonly_field4 = {
  disabled: false,
  readonly: true,
  name: 'field4',
  type: "readonly",
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
  password_hide: '#it-password-hide',
}
let ob_input_field_readonly_field5 = {
  disabled: false,
  readonly: true,
  name: 'field5',
  type: "readonly",
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: false,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
}
let ob_input_field_invalid_field1 = {
  disabled: false,
  readonly: false,
  type: 'invalid',
  message: ' Message explaining the error ',
  name: 'field1',
  value: 'Lorem ipsum',
  example: true,
  show: true,
  hide: true,
  sprite_fill: "#it-error-circle",
  helper_counter: false,
  label: "Label Text",
  example_sprite: "#it-example",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_invalid_field2 = {
  disabled: false,
  readonly: false,
  type: 'invalid',
  message: ' Message explaining the error ',
  name: 'field2',
  value: 'Lorem ipsum',
  example: true,
  show: false,
  hide: false,
  sprite_fill: "#it-error-circle",
  helper_counter: false,
  label: "Label Text",
  example_sprite: "#it-example",
}

let ob_input_field_invalid_field3 = {
  disabled: false,
  readonly: false,
  type: 'invalid',
  message: ' Message explaining the error ',
  name: 'field3',
  value: 'Lorem ipsum',
  example: false,
  show: true,
  hide: true,
  sprite_fill: "#it-error-circle",
  helper_counter: false,
  label: "Label Text",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_invalid_field4 = {
  disabled: false,
  readonly: false,
  type: 'invalid',
  message: ' Message explaining the error ',
  name: 'field4',
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: true,
  sprite_fill: "#it-error-circle",
  helper_counter: false,
  label: "Label Text",
  password_hide: '#it-password-hide',
}
let ob_input_field_invalid_field5 = {
  disabled: false,
  readonly: false,
  type: 'invalid',
  message: ' Message explaining the error ',
  name: 'field5',
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: false,
  sprite_fill: "#it-error-circle",
  helper_counter: false,
  label: "Label Text",
}
let ob_input_field_valid_field1 = {
  disabled: false,
  readonly: false,
  type: 'valid',
  message: ' Message explaining the success ',
  name: 'field1',
  value: 'Lorem ipsum',
  example: true,
  show: true,
  hide: true,
  sprite_fill: "#it-check-circle",
  helper_counter: false,
  label: "Label Text",
  example_sprite: "#it-example",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_valid_field2 = {
  disabled: false,
  readonly: false,
  type: 'valid',
  message: ' Message explaining the success ',
  name: 'field2',
  value: 'Lorem ipsum',
  example: true,
  show: false,
  hide: false,
  sprite_fill: "#it-check-circle",
  helper_counter: false,
  label: "Label Text",
  example_sprite: "#it-example",
}

let ob_input_field_valid_field3 = {
  disabled: false,
  readonly: false,
  type: 'valid',
  message: ' Message explaining the success ',
  name: 'field3',
  value: 'Lorem ipsum',
  example: false,
  show: true,
  hide: true,
  sprite_fill: "#it-check-circle",
  helper_counter: false,
  label: "Label Text",
  password_icon: '#it-password-show',
  password_hide: '#it-password-hide',
}

let ob_input_field_valid_field4 = {
  disabled: false,
  readonly: false,
  type: 'valid',
  message: ' Message explaining the success ',
  name: 'field4',
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: true,
  sprite_fill: "#it-check-circle",
  helper_counter: false,
  label: "Label Text",
  password_hide: '#it-password-hide',
}
let ob_input_field_valid_field5 = {
  disabled: false,
  readonly: false,
  type: 'valid',
  message: ' Message explaining the success ',
  name: 'field5',
  value: 'Lorem ipsum',
  example: false,
  show: false,
  hide: false,
  sprite_fill: "#it-check-circle",
  helper_counter: false,
  label: "Label Text",
}
let text_tarea = {
  disabled: false,
  readonly: false,
  name: 'field10',
  type: "",
  value: '',
  textarea: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
}

let text_area_disabled = {
  disabled: true,
  readonly: false,
  name: 'field11',
  type: "disabled",
  value: '',
  textarea: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
}

let text_area_readolny = {
  disabled: false,
  readonly: true,
  name: 'field12',
  type: "readonly",
  value: '',
  textarea: true,
  message: ' Testo informativo ',
  sprite_fill: "#it-info-circle",
  helper_counter: true,
  label: "Label Text",
}

let text_area_invalid = {
  disabled: false,
  readonly: false,
  type: 'invalid',
  name: 'field13',
  value: '',
  textarea: true,
  message: ' Message explaining the error ',
  sprite_fill: "#it-error-circle",
  helper_counter: false,
  label: "Label Text",
}
let text_area_valid = {
  disabled: false,
  readonly: false,
  type: 'valid',
  name: 'field14',
  value: '',
  textarea: true,
  message: ' Message explaining the success ',
  sprite_fill: "#it-check-circle",
  helper_counter: false,
  label: "Label Text",
}

let field_dropdown_type = {
  name: 'tipo',
  label: 'Tipologia',
  className: 'field-26',
  id: 'tipoLabel',
  options: [
    { value: "Lorem ipsum", label: "Lorem ipsum", hidden: true, selected: true },
    { value: "1", label: "Altro documento contabile", selected: true },
    { value: "2", label: "Atto notarile di acquisto" },
    { value: "3", label: "Bollettino postale" },
    { value: "4", label: "Busta paga (compresi oneri riflessi)" },
    { value: "5", label: "Cedolini bancari" },
    { value: "6", label: "Contratto di affitto" },
    { value: "7", label: "Contratto di mutuo" },
    { value: "8", label: "Delega F24/F23" },
    { value: "9", label: "Estratto conto bancario" },
    { value: "10", label: "Fattura" },
    { value: "11", label: "Nota rimborso chilometrico" },
    { value: "12", label: "Notula (se emittente non è sogg. a IVA)" },
    { value: "13", label: "Parcella" },
    { value: "14", label: "Quietanze assicurative" },
    { value: "15", label: "Raccomandate postali" },
    { value: "16", label: "Ricevuta fiscale" },
    { value: "17", label: "Ricevuta generica" },
    { value: "18", label: "Spese per missioni" }
  ],
  hovering: false,
};

let documento = {
  id: 'documentoLabel',
  name: 'documento',
  label: 'Identificativo documento',
  value: 'Lorem ipsum dolor',
  className: 'field-12',
  hovering: false,
};

let documentoData = {
  id: 'documentoDataLabel',
  name: 'documentoData',
  label: 'Data',
  value: '25/12/2024',
  placeholder: 'AAAA/MM/GG',
  className: 'field-12',
  isDate: true,
  hovering: false,
  calendar_sprite: "#it-calendar",
};

let documentoNote = {
  id: 'documentoNoteLabel',
  name: 'documentoNote',
  label: 'Lorem ipsum',
  value: '',
  className: 'field-wide',
  hovering: false,
};

let giustificativo = {
  id: 'giustificativoLabel',
  name: 'giustificativo',
  label: 'Giustificativo di pagamento',
  className: 'field-26',
  hasFeedback: true,
  required: true,
  options: [
    { value: "Lorem ipsum", label: "Lorem ipsum", hidden: true, selected: true },
    { value: "1", label: "Altro documento contabile" },
    { value: "2", label: "Bonifico bancario/postale", selected: true },
    { value: "3", label: "Lorem ipsum 3" },
  ],
  hovering: false,
};

let pagamento = {
  id: 'pagamentoLabel',
  name: 'pagamento',
  label: 'Identificativo pagamento',
  value: 'Lorem ipsum dolor',
  className: 'field-16',
  hasFeedback: true,
  required: true,
  hovering: false,
};

let pagamentoData = {
  id: 'pagamentoDataLabel',
  name: 'pagamentoData',
  label: 'Data',
  value: '12/05/2024',
  placeholder: 'AAAA/MM/GG',
  className: 'field-12',
  isDate: true,
  hovering: false,
  calendar_sprite: "#it-calendar",
};

let field18 = {
  id: 'field18Label',
  name: 'field18',
  label: 'Note documento di pagamento',
  value: 'Lorem ipsum dolor sit amet',
  className: 'field-wide',
  hasFeedback: true,
  required: true,
  hovering: false,
};

let field19 = {
  id: 'field19Label',
  name: 'field19',
  label: 'Label field',
  value: 'Lorem ipsum',
  placeholder: 'Placeholder field',
  required: true,
  example: true,
  show: true,
  hide: true,
  className: "",
  hovering: false,
  example_sprite: "#it-example",
  password_show_sprite: "#it-password-show",
  password_hide_sprite: "#it-password-hide",
};

let field20 = {
  id: 'field20Label',
  name: 'field20',
  label: 'Label field',
  value: 'Lorem ipsum',
  placeholder: 'Placeholder field',
  required: true,
  textarea: true,
  className: "",
  hovering: false,
};


const SnippetInput = ({ ob }) => {
  return (
    <div>
      <div className="demon-view">
        <div className="container pb-7">
          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_1} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_2} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_3} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_4} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_5} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_disabled_field1} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_disabled_field2} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_disabled_field3} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_disabled_field4} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_disabled_field5} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_readonly_field1} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_readonly_field2} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_readonly_field3} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_readonly_field4} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_readonly_field5} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_invalid_field1} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_invalid_field2} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_invalid_field3} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_invalid_field4} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_invalid_field5} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_valid_field1} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_valid_field2} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_valid_field3} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_valid_field4} />
                </div>
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={ob_input_field_valid_field5} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={text_tarea} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={text_area_disabled} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={text_area_readolny} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={text_area_invalid} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5">
              <div className="row">
                <div className="col-md-6 col-lg-3 pt-3 pt-lg-5">
                  <Input ob={text_area_valid} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 pt-lg-7">
            <div className="pt-2 pt-lg-5" demon-form="test">
              <div className="row">
                <div className="col-lg-9">
                  <div className="group-inline pt-3">
                    <Form ob={field_dropdown_type} />
                    <Form ob={documento} />
                    <Form ob={documentoData} />
                  </div>
                  <div className="group-inline">
                    <Form ob={documentoNote} />
                  </div>
                  <div className="group-inline pt-3">
                    <Form ob={giustificativo} />
                    <Form ob={pagamento} />
                    <Form ob={pagamentoData} />
                  </div>
                  <div className="group-inline">
                    <Form ob={field18} />
                    <Form ob={field19} />
                    <Form ob={field20} />
                  </div>
                  <div className="field-mandatory-nb">
                    <span>*</span> campi obbligatori
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SnippetInput;