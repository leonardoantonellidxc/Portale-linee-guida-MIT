import Accordion from "../../lib36/components/accordion/accordion";


let ob_buttons = [
  { button_action: "save", button_text: "Button text1" },
  { button_action: "draft", bg_white: true, button_text: "Button text2" },
];

const actionFunc = (buttonCase) => {
  if (buttonCase) {
    switch (buttonCase) {
      case "back":
        window.location.replace("/events/page/2");
        break;

      case "draft":
        alert("Draft action here");
        break;
      case "save":
        alert("Save action here");
        break;
      default:
        alert("no default functions for case: " + buttonCase);

    }
  }
};

let object_accordion = [
  {
    title: "Elemento Richiudibile #1",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. #1",
    buttons: ob_buttons,
    sprite: "#it-example",
  },
  {
    title: "Elemento Richiudibile #2",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. #2",
    buttons: ob_buttons,
    sprite: "#it-example",
  },
  {
    title: "Elemento Richiudibile #3",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. #3",
    buttons: ob_buttons,
    sprite: "#it-example",
  },
];

const SnippetAccordion = () => {
  return (
    <Accordion
      object_data={object_accordion}
      activeFunctions={actionFunc}
    ></Accordion>
  );
};
export default SnippetAccordion;
