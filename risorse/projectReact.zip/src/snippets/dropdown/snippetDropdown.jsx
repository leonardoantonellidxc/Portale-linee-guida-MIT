import React from 'react';
import Dropdown from "../../lib36/components/dropdown/dropdown";

const dropdown = {
    button_text: 'Dropdown button',
    dropdown_title: 'Title',
    example_sprite: '#it-example',
    show_dropdown : false,
    items: [
        {
            active: true,
            text: ' Action ',
            button_action: "draft",
        },
        {
            text: ' Another action ',
            button_action: "draft",
        },
        {
            text: ' Something else here ',
            button_action: "draft",
        }
    ]
};

const dropdown_search = {
    search: true,
    button_text: 'Dropdown button',
    input_name: 'field1',
    input_placeholder: 'Cerca',
    input_value: '',
    input_aria_label: 'Lorem ipsum dolor sit',
    example_sprite: '#it-example',
    search_sprite : "#it-search",
    show_dropdown : false,
    items: [
        {
            text: ' Action ',
            button_action: "draft",
        },
        {
            text: ' Another action ',
            button_action: "draft",
        },
        {
            text: ' Something else here ',
            button_action: "draft",
        },
        {
            text: ' Action ',
            button_action: "draft",
        },
        {
            text: ' Another action ',
            button_action: "draft",
        },
        {
            text: ' Something else here ',
            button_action: "draft",
        },
    ],
    divider: 3,
};

const dropdown_search_checkbox = {
    checkbox: true,
    search: true,
    button_text: 'Dropdown button',
    input_name: 'field1',
    input_placeholder: 'Cerca',
    input_value: '',
    input_aria_label: 'Lorem ipsum dolor sit',
    search_sprite : "#it-search",
    show_dropdown : false,
    items: [
        {
            label_checkbox: ' Label checkbox 1 ',
            name: 'options',
            id: 1,
            value: ''
        },
        {
            label_checkbox: ' Label checkbox 2',
            name: 'options',
            id: 2,
            value: ''
        },
        {
            label_checkbox: ' Label checkbox 3 ',
            name: 'options',
            id: 3,
            value: ''
        },
        {
            label_checkbox: ' Label checkbox 4 ',
            name: 'options',
            id: 4,
            value: ''
        },
        {
            label_checkbox: ' Label checkbox 5 ',
            name: 'options',
            id: 5,
            value: ''
        },
    ],
    divider: 3,
};

const actionFunc = (buttonCase) => {
    if (buttonCase) {
      switch (buttonCase) {
        case "back":
          window.location.replace("/events/page/2");
          break;
  
        case "draft":
          alert("Draft action here");
          break;
        case "save":
          alert("Save action here");
          break;
        default:
          alert("no default functions for case: " + buttonCase);
  
      }
    }
  };


const SnippetDropdown = () => {
    return (
        <div>
            <div className="demon-view">
                <div className="container pb-8">
                    <div className="pt-6">
                        <div className="h3">Dropdown</div>
                        <div className="pt-2 pt-lg-5">
                            <div className="row">
                                <div className="col-lg pt-4">
                                    <Dropdown ob={dropdown} activeFunctions={actionFunc} />
                                </div>
                                <div className="col-lg pt-4">
                                    <Dropdown ob={dropdown_search} activeFunctions={actionFunc} />
                                </div>
                                <div className="col-lg pt-4">
                                    <Dropdown ob={dropdown_search_checkbox} activeFunctions={actionFunc}/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SnippetDropdown;
