import { useState, useCallback } from 'react';
import Uploader from "../../lib36/form/uploader/uploader";
import DragDropUploader from "../../lib36/form/uploader/dragDropUploader";

const uploader_loaded_loading = {
    name: 'uploadFile2',
    input_label: 'Carica file',
    disabled: '',
    loaded: [{ name: 'Nome-file.pdf', size: '3.5 mb' }],
    loading: [
        { name: 'Nome-file.pdf', size: '3.5 mb', progress: 25 },
        { name: 'Nome-file.pdf', size: '3.5 mb', progress: 25 },
    ],
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
};

const uploader_loaded_loading_disabled = {
    name: 'uploadFile4',
    disabled: 'disabled',
    input_label: 'Carica altri documenti',
    loaded: [{ name: 'Nome-file.pdf', size: '3.5 mb' }],
    loading: [{ name: 'Nome-file.pdf', size: '3.5 mb', progress: 25 }],
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
};

const uploader_drag_drop = {
    drag_drop: true,
    type: '',
    type_over: 'over',
    type_active: 'active',
    type_loading: 'loading',
    type_success: 'success',
    type_error: 'error',
    drag_drop_type_button: '',
    sprite_type_button: '',
    drag_drop_type_class_button: '',
    button_text: '',
    drag_drop_type_button_success: 'success',
    drag_drop_type_button_loading: 'primary',
    drag_drop_type_class_button_loading: '',
    sprite_document_icon: '#it-document-text',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
};

const uploader_drag_drop_active = {
    ...uploader_drag_drop,
    type: 'active',
    sprite_document_icon: '#it-document-text',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
};

const uploader_drag_drop_disabled = {
    ...uploader_drag_drop,
    type_disabled: 'disabled',
    type: 'disabled',
    sprite_document_icon: '#it-document-text',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
};




const SnippetUploader = () => {
    const [uploadProgress, setUploadProgress] = useState(0);

    const simulateUpload = useCallback(() => {
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            setUploadProgress(progress);
            if (progress >= 100) {
                clearInterval(interval);
            }
        }, 500);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="demon-view">
            <div className="container pb-7">
                <div className="pt-3 pt-lg-7">
                    <div className="pt-2 pt-lg-5" demon-list="uploader">
                        <div className="row">
                            <div className="col-lg-6 pt-3">
                                <Uploader ob={uploader_loaded_loading} />
                            </div>
                            <div className="col-lg-6 pt-3">
                                <Uploader ob={uploader_loaded_loading_disabled} />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="pt-3 pt-lg-7">
                    <div className="pt-2 pt-lg-5">
                        <div className="row" demon-list="dragdrop">
                            <div className="col-lg-4 pt-3">
                                <DragDropUploader ob={uploader_drag_drop} simulatedFunction={simulateUpload} uploadProgress={uploadProgress} />
                            </div>
                            <div className="col-lg-4 pt-3">
                                <DragDropUploader ob={uploader_drag_drop_active} simulatedFunction={simulateUpload} uploadProgress={uploadProgress} />
                            </div>
                            <div className="col-lg-4 pt-3">
                                <DragDropUploader ob={uploader_drag_drop_disabled} simulatedFunction={simulateUpload} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SnippetUploader;