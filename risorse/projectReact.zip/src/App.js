import { BrowserRouter, Route, Routes } from "react-router-dom";
import SnippetAccordion from "./snippets/accordion/snippetAccordion";
import SnippetBottomBar from "./snippets/bottom_bar/snippetBottomBar";
import SnippetModali from "./snippets/modali/snippetModali";
import SnippetTimeline from "./snippets/timeline/snippetTimeline";
import SnippetSelect from "./snippets/select/snippetSelect";
import SnippetCard from "./snippets/card/snippetCard";
import SnippetInput from "./snippets/Input/snippetInput";
import SnippetInputSearch from "./snippets/input_search/snippetInputSearch";
import SnippetStepper from "./snippets/stepper/snippetStepper";
import SnippetSlider from "./snippets/slider/snippetSlider";
import SnippetDropdown from "./snippets/dropdown/snippetDropdown";
import SnippetDatePicker from "./snippets/date_picker/snippetDatePicker";
import SnippetTabMenu from "./snippets/tab_menu/snippetTabMenu";
import SnippetTable from "./snippets/table/snippetTable";
import SnippetUploader from "./snippets/uploader/snippetUploader";
import Footer from "./lib36/components/footer/footer";
import SnippetHeroBanner from "./snippets/hero_banner/snippetHeroBanner";
import SnippetSidebarNavigation from "./snippets/sidebar_navigation/snippetSidebarNavigation";
import Header from "./lib36/components/header/header";
import SnippetPagination from "./snippets/pagination/snippetPagination";


const styles = {
  header: {
    height: "250px",
  },
  contentWrapper: {
    paddingTop: "250px",
    minHeight: "calc(100vh - 200px)",
  },
};

function App() {
  return (
    <BrowserRouter>
      <div
        style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}
      >
        <Header style={styles.header} />
        <div style={styles.contentWrapper}>
          <Routes>
            <Route path="/" />
            <Route path="/accordion" element={<SnippetAccordion />} />
            <Route path="/bottom-bar" element={<SnippetBottomBar />} />
            <Route path="/modali" element={<SnippetModali />} />
            <Route path="/timeline" element={<SnippetTimeline />} />
            <Route path="/select" element={<SnippetSelect />} />
            <Route path="/slider" element={<SnippetSlider />} />
            <Route path="/stepper" element={<SnippetStepper />} />
            <Route path="/card" element={<SnippetCard />} />
            <Route path="/input" element={<SnippetInput />} />
            <Route path="/input-search" element={<SnippetInputSearch />} />
            <Route path="/dropdown" element={<SnippetDropdown />} />
            <Route path="/date-picker" element={<SnippetDatePicker />} />
            <Route path="/tab-menu" element={<SnippetTabMenu />} />
            <Route path="/table" element={<SnippetTable />} />
            <Route path="/uploader" element={<SnippetUploader />} />
            <Route path="/hero-banner" element={<SnippetHeroBanner />} />
            <Route path="/pagination" element={<SnippetPagination />} />
            <Route
              path="/sidebar-navigation"
              element={<SnippetSidebarNavigation />}
            />
          </Routes>
        </div>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
