import sprite from "../../static/imgs/icon/sprite.svg";
import { useState, useRef, useEffect } from "react";

const InputSearch = ({ ob, activeFunctions }) => {
    const [isHovering, setIsHovering] = useState(ob.is_hovering);
    const [isShowing, setIsShowing] = useState(ob.is_showing);
    const [showAll, setShowAll] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const dropdownRef = useRef(null);
    const inputRef = useRef(null);

    const openDropdown = () => {
        setIsShowing(true);
    };

    const closeDropdown = () => {
        setIsShowing(false);
        setShowAll(false);
    };

    const handleMouseOver = () => setIsHovering(true);
    const handleMouseOut = () => setIsHovering(false);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                closeDropdown();
            }
        };

        document.addEventListener('mousedown', handleClickOutside);

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleShowAll = () => {
        setShowAll(true);
    };

    const filteredFields = ob.field.filter(field =>
        field.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const visibleFields = showAll ? filteredFields : filteredFields.slice(0, 6);

    const dropdownItems = [];
    visibleFields.forEach((field, index) => {
        dropdownItems.push(
            <li key={field.id} onMouseOver={handleMouseOver} onMouseOut={handleMouseOut}>
                <a className="dropdown-item" href="#" onClick={() => activeFunctions(field.button_action)}>
                    <div className="text-icon">
                        <svg className="icon icon-xs">
                            <use href={`${sprite}${field.sprite_example}`}></use>
                        </svg>
                        <span>{field.name}</span>
                    </div>
                    <svg className="icon icon-xs">
                        <use href={`${sprite}${field.sprite_example}`}></use>
                    </svg>
                </a>
            </li>
        );

        if ((index + 1) % ob.divider === 0 && index !== ob.field.length - 1) {
            dropdownItems.push(<li key={`divider-${index}`}><div className="h-line"></div></li>);
        }
    });

    return (
        <div ref={dropdownRef} className={`form-group group-search dropdown ${isHovering ? 'hover' : ''} ${isShowing ? 'show' : ''} ${ob.is_disabled ? 'disabled' : ''} ${ob.is_mini ? 'mini dropdown' : ''} ${ob.is_mini_search_disabled ? 'search-mini disabled' : ''}`}>
            <div className="input-group">
                <div className="input-group-text">
                    <svg className="icon icon-xxs">
                        <use href={`${sprite}${ob.sprite_search}`}></use>
                    </svg>
                </div>
                <input
                    type="text"
                    ref={inputRef}
                    className="form-control"
                    name="field1"
                    placeholder="Cerca"
                    aria-label="Lorem ipsum dolor sit"
                    onFocus={openDropdown}
                    onBlur={() => setTimeout(closeDropdown, 200)}
                    onMouseOver={handleMouseOver}
                    onMouseOut={handleMouseOut}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="input-group-text active-option" >
                    <svg className="icon icon-xxs">
                        <use href={`${sprite}${ob.sprite_streamline}`}></use>
                    </svg>
                </div>
                <div className="input-group-text active-closer"></div>
            </div>
            <div className={`dropdown-menu ${isShowing ? 'show' : ''}`}>
                <ul className="scrollable" >
                    {dropdownItems}
                </ul>
                {!showAll && filteredFields.length > 6 && (
                    <div className="dropdown-link link-all">
                        <button
                            type="button"
                            className="btn btn-bare btn-sm"
                            onClick={handleShowAll}
                            onMouseDown={(e) => e.preventDefault()}
                        >
                            Mostra tutti i risultati
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default InputSearch;