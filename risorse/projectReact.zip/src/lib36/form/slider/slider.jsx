import React, { useState, useEffect, useCallback, useRef } from "react";
import sprite from "../../../lib36/static/imgs/icon/sprite.svg"
import sprite_fill from "../../../lib36/static/imgs/icon/sprite_fill.svg"

const Slider = ({ ob }) => {
    const [minValue, setMinValue] = useState(ob.range_field === 2 ? ob.min : ob.min);
    const [maxValue, setMaxValue] = useState(ob.range_field === 2 ? ob.max : ob.initial || ob.max);
    const [validationState, setValidationState] = useState(ob.valid || ob.invalid || "");
    const progressWrapperRef = useRef(null);
    const progressBarRef = useRef(null);

    const roundValue = (value) => {
        const range = ob.max - ob.min;
        let decimals = 0;
        if (range < 1) decimals = 2;
        else if (range < 10) decimals = 1;
        return Number(value.toFixed(decimals));
    };

    useEffect(() => {
        setMinValue(ob.range_field === 2 ? ob.min : ob.min);
        setMaxValue(ob.range_field === 2 ? ob.max : ob.initial || ob.max);
        validate(ob.range_field === 2 ? ob.min : ob.min, ob.range_field === 2 ? ob.max : ob.initial || ob.max);
    }, [ob]);

    const handleMinChange = useCallback((value) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue)) {
            const newValue = roundValue(Math.max(ob.min, Math.min(numValue, maxValue - 1)));
            setMinValue(newValue);
            validate(newValue, maxValue);
            updateProgress(newValue, maxValue);
        }
    }, [maxValue, ob.min]);

    const handleMaxChange = useCallback((value) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue)) {
            const newValue = roundValue(Math.max(minValue + 1, Math.min(numValue, ob.max)));
            setMaxValue(newValue);
            validate(minValue, newValue);
            updateProgress(minValue, newValue);
        }
    }, [minValue, ob.max]);

    const calculateLeftPosition = useCallback((value) => {
        return ((value - ob.min) / (ob.max - ob.min)) * 100;
    }, [ob.min, ob.max]);

    const updateProgress = (min, max) => {
        if (progressBarRef.current) {
            progressBarRef.current.style.width = `${calculateLeftPosition(max) - calculateLeftPosition(min)}%`;
            progressBarRef.current.style.marginLeft = `${calculateLeftPosition(min)}%`;
        }
    };

    const onMouseDown = (pin) => {
        const handleMouseMove = (event) => {
            const rangeElement = progressWrapperRef.current;
            const progressWrapperRect = rangeElement.getBoundingClientRect();
            const mouseX = event.clientX - progressWrapperRect.left;
            const progressWrapperWidth = progressWrapperRect.width;
            let percent = (mouseX / progressWrapperWidth) * 100;
            percent = Math.max(0, Math.min(percent, 100));
            const value = roundValue(ob.min + (percent / 100) * (ob.max - ob.min));

            if (pin === 'from') {
                handleMinChange(value);
            } else {
                handleMaxChange(value);
            }
        };

        const handleMouseUp = () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };

        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    };

    const handleInput = (event, type) => {
        const value = event.target.value;
        if (type === 'min') {
            handleMinChange(value);
        } else {
            handleMaxChange(value);
        }
    };

    const validate = (min, max) => {
        if (ob.toValidate) {
            if (min < ob.minValid || max > ob.maxValid) {
                setValidationState("is-invalid");
            } else {
                setValidationState("is-valid");
            }
        } else {
            setValidationState(ob.valid || ob.invalid || "");
        }
    };

    const onProgressClick = (event) => {
        const rangeElement = progressWrapperRef.current;
        const progressWrapperRect = rangeElement.getBoundingClientRect();
        const mouseX = event.clientX - progressWrapperRect.left;
        const progressWrapperWidth = progressWrapperRect.width;
        let percent = (mouseX / progressWrapperWidth) * 100;
        percent = Math.max(0, Math.min(percent, 100));
        const value = roundValue(ob.min + (percent / 100) * (ob.max - ob.min));

        if (ob.range_field === 1) {
            handleMaxChange(value);
        } else {
            const distanceToMin = Math.abs(value - minValue);
            const distanceToMax = Math.abs(value - maxValue);
            if (distanceToMin < distanceToMax) {
                handleMinChange(value);
            } else {
                handleMaxChange(value);
            }
        }
    };

    return (
        <div className={`form-group form-ranges has-feedback ${ob.range_field === 2 ? 'from-to' : ''} ${ob.disabled} ${validationState}`}>
            <label className="label-info" id={ob.id}>
                <span>{ob.label_text}</span>
                <svg className="icon">
                    <use href={`${sprite_fill}${ob.sprite_info_circle}`} />
                </svg>
            </label>

            <div className="input-range">
                <div className="range-progress">
                    <div className="range-limit text-icon">
                        <svg className="icon icon-xs">
                            <use href={`${sprite}${ob.sprite_example}`} />
                        </svg>
                        <span>{ob.min}%</span>
                    </div>
                    <div className="progress-wrapper" ref={progressWrapperRef} onClick={ob.disabled ? undefined : onProgressClick}>
                        {ob.range_field === 2 && (
                            <a
                                className="btn-pin from"
                                style={{ left: `${calculateLeftPosition(minValue)}%` }}
                                onMouseDown={() => onMouseDown('from')}
                            >
                                <div className="pin-tooltip">{minValue}</div>
                                <div className="pin"></div>
                            </a>
                        )}
                        <div
                            className="progress"
                            role="progressbar"
                            aria-label="Basic example"
                            aria-valuenow={maxValue}
                            aria-valuemin={ob.min}
                            aria-valuemax={ob.max}
                        >
                            <div
                                className="progress-bar"
                                ref={progressBarRef}
                                style={{
                                    width: `${calculateLeftPosition(maxValue) - calculateLeftPosition(minValue)}%`,
                                    marginLeft: `${calculateLeftPosition(minValue)}%`,
                                }}
                            ></div>
                        </div>
                        <a
                            className="btn-pin to"
                            style={{ left: `${calculateLeftPosition(maxValue)}%` }}
                            onMouseDown={() => onMouseDown('to')}
                        >
                            <div className="pin-tooltip">{maxValue}</div>
                            <div className="pin"></div>
                        </a>
                    </div>
                    <div className="range-limit text-icon">
                        <span>{ob.max}%</span>
                        <svg className="icon icon-xs">
                            <use href={`${sprite}${ob.sprite_example}`} />
                        </svg>
                    </div>
                </div>
                <div className="range-group">
                    {ob.range_field === 1 && (
                        <div className="range-field">
                            <input
                                type="text"
                                className="form-control"
                                name="field2-from"
                                value={maxValue}
                                onChange={(e) => handleInput(e, 'max')}
                                aria-label="Valore"
                                disabled={ob.disabled === 'disabled'}
                                onKeyUp={(e) => e.key === 'Enter' && handleInput(e, 'max')}
                            />
                        </div>
                    )}
                    {ob.range_field === 2 && (
                        <>
                            <div className="range-field">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="field1-from"
                                    value={minValue}
                                    onChange={(e) => handleInput(e, 'min')}
                                    aria-label="Valore minimo"
                                    disabled={ob.disabled === 'disabled'}
                                    onKeyUp={(e) => e.key === 'Enter' && handleInput(e, 'min')}
                                />
                                <div className="field-helper">
                                    <div className="helper-text">
                                        <span>Minimo</span>
                                    </div>
                                </div>
                            </div>
                            <div className="range-field">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="field1-to"
                                    value={maxValue}
                                    onChange={(e) => handleInput(e, 'max')}
                                    aria-label="Valore massimo"
                                    disabled={ob.disabled === 'disabled'}
                                    onKeyUp={(e) => e.key === 'Enter' && handleInput(e, 'max')}
                                />
                                <div className="field-helper">
                                    <div className="helper-text">
                                        <span>Massimo</span>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Slider;