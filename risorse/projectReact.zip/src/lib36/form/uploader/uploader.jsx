import { useState, useEffect } from 'react';
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";

const Uploader = ({ ob }) => {
    const [files, setFiles] = useState(ob.initialFiles || []);
    const [isFileNameVisible, setIsFileNameVisible] = useState({});
    const [fileStates, setFileStates] = useState({});
    const [progress, setProgress] = useState({});
    const [errorMessages, setErrorMessages] = useState({});
    const [inputLabel, setInputLabel] = useState(ob.input_label);

    useEffect(() => {
        if (files.length > 0) {
            setInputLabel('Carica altri documenti');
        }
    }, [files]);

    const handleFileChange = (e) => {
        const selectedFiles = Array.from(e.target.files);
        const newFiles = [...files, ...selectedFiles];
        setFiles(newFiles);
        
        selectedFiles.forEach(file => {
            setIsFileNameVisible(prev => ({ ...prev, [file.name]: false }));
            setFileStates(prev => ({ ...prev, [file.name]: 'loading' }));
            setProgress(prev => ({ ...prev, [file.name]: 0 }));
            simulateUpload(file.name);
        });
    };

    const simulateUpload = (fileName) => {
        let uploadProgress = 0;
        const interval = setInterval(() => {
            uploadProgress += 10;
            setProgress(prev => ({ ...prev, [fileName]: uploadProgress }));
            if (uploadProgress >= 100) {
                clearInterval(interval);
                setFileStates(prev => ({ ...prev, [fileName]: 'success' }));
            }
        }, 500);
    };

    const handleShowFile = (fileName) => {
        setIsFileNameVisible(prev => ({ ...prev, [fileName]: !prev[fileName] }));
    };

    const handleFileDelete = (fileName) => {
        setFiles(files.filter(file => file.name !== fileName));
        setIsFileNameVisible(prev => {
            const { [fileName]: _, ...rest } = prev;
            return rest;
        });
        setFileStates(prev => {
            const { [fileName]: _, ...rest } = prev;
            return rest;
        });
        setProgress(prev => {
            const { [fileName]: _, ...rest } = prev;
            return rest;
        });
        setErrorMessages(prev => {
            const { [fileName]: _, ...rest } = prev;
            return rest;
        });
    };

    const maskFileName = (fileName) => {
        return fileName.replace(/./g, '*');
    };

    const renderFileInfo = (file) => {
        const fileName = file.name;
        const fileState = fileStates[fileName] || 'idle';

        return (
            <div key={fileName} className={`file-item ${fileState === 'error' ? 'is-invalid' : ''}`}>
                <div className="file-desc">
                    <div className="file-title">
                        <svg className="icon">
                            <use href={`${sprite_fill}${fileState === 'success' ? ob.sprite_check_circle : ob.sprite_document_icon}`}></use>
                        </svg>
                        <span>
                            {isFileNameVisible[fileName] ? fileName : maskFileName(fileName)}
                            {fileState === 'success' && ` (${(file.size / 1024 / 1024).toFixed(2)} MB)`}
                        </span>
                    </div>
                    <div className="file-btn">
                        {fileState === 'success' && (
                            <>
                                <button type="button" className={`btn-close btn-view ${ob.disabled}`} onClick={() => handleShowFile(fileName)}>
                                    <svg className="icon icon-xs">
                                        <use href={`${sprite_fill}${ob.sprite_password_icon}`}></use>
                                    </svg>
                                </button>
                                <button type="button" className={`btn-close btn-delete ${ob.disabled}`} onClick={() => handleFileDelete(fileName)}>
                                    <svg className="icon icon-xs">
                                        <use href={`${sprite_fill}${ob.sprite_delete_icon}`}></use>
                                    </svg>
                                </button>
                            </>
                        )}
                        {fileState === 'loading' && (
                            <button type="button" className="btn-close btn-stop" onClick={() => handleFileDelete(fileName)}>
                                <svg className="icon icon-xs">
                                    <use href={`${sprite_fill}${ob.sprite_close}`}></use>
                                </svg>
                            </button>
                        )}
                        {fileState === 'error' && (
                            <>
                                <button type="button" className="btn-close btn-reload" onClick={() => setFileStates(prev => ({ ...prev, [fileName]: 'loading' }))}>
                                    <svg className="icon icon-xs">
                                        <use href={`${sprite_fill}${ob.sprite_refresh}`}></use>
                                    </svg>
                                </button>
                                <button type="button" className="btn-close btn-delete" onClick={() => handleFileDelete(fileName)}>
                                    <svg className="icon icon-xs">
                                        <use href={`${sprite_fill}${ob.sprite_delete_icon}`}></use>
                                    </svg>
                                </button>
                            </>
                        )}
                    </div>
                </div>
                {fileState === 'error' && (
                    <div className="invalid-feedback">
                        <span>{errorMessages[fileName] || 'Si è verificato un errore durante il caricamento.'}</span>
                    </div>
                )}
                {fileState === 'loading' && (
                    <div className="progress-wrapper">
                        <div className="progress" role="progressbar" aria-label="Basic example" aria-valuenow={progress[fileName]} aria-valuemin="0" aria-valuemax="100">
                            <div className="progress-bar" style={{ width: `${progress[fileName]}%` }}></div>
                        </div>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className={`form-group form-file ${Object.values(fileStates).includes('loading') ? 'has-feedback' : ''} ${ob.disabled}`}>
            <div className="file-label text-icon " id={`${ob.name}Label`}>
                <svg className="icon icon-sm">
                    <use href={`${sprite_fill}${ob.sprite_document_icon}`}></use>
                </svg>
                <span>{ob.title_text}</span>
            </div>

            <div className={`file-list complete ${files.length > 0 ? 'show' : ''}`}>
                {files.length > 0 && <div className="list-title">
                    {Object.values(fileStates).includes('loading') ? 'Documenti in fase di caricamento...' : 'Documenti caricati'}
                </div>}
                {files.map(renderFileInfo)}
            </div>
            <div className="file-upload">
                <input
                    type="file"
                    name={ob.name}
                    id={ob.name}
                    multiple
                    aria-labelledby={`${ob.name}Label`}
                    disabled={ob.disabled || Object.values(fileStates).includes('loading')}
                    onChange={handleFileChange}
                />
                <label htmlFor={ob.name} className={`btn btn-sm btn-primary ${ob.disabled || Object.values(fileStates).includes('loading') ? 'disabled' : ''}`}>
                    <svg className="icon icon-sm">
                        <use href={`${sprite}#it-upload`}></use>
                    </svg>
                    <span> {files.length > 0 ? 'Carica altri documenti' : ob.input_label} </span>
                </label>
            </div>
        </div>
    );
};

export default Uploader;