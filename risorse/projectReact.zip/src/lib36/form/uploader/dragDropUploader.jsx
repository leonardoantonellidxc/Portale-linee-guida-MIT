import { useState, useRef, useEffect } from 'react';
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import dragDropIcon from "../../static/imgs/icon/upload/drag-drop-icon.svg";
import dragDropIconDisabled from "../../static/imgs/icon/upload/drag-drop-icon-disabled.svg";
import dragDropIconOver from "../../static/imgs/icon/upload/drag-drop-icon-over.svg";
import dragDropIconActive from "../../static/imgs/icon/upload/drag-drop-icon-active.svg";
import dragDropIconSuccess from "../../static/imgs/icon/upload/drag-drop-icon-success.svg";
import dragDropIconFailed from "../../static/imgs/icon/upload/drag-drop-icon-failed.svg";

const DragDropUploader = ({ ob, simulatedFunction, uploadProgress }) => {

    const [dragState, setDragState] = useState(ob.type || '');
    const [file, setFile] = useState(null);
    const fileInputRef = useRef(null);
    const simulationRef = useRef(null);


    useEffect(() => {
        if (dragState === ob.type_loading) {
            simulationRef.current = simulatedFunction();
        }

        return () => {
            if (simulationRef.current) {
                simulationRef.current();
            }
        };
    }, [dragState, ob.type_loading, simulatedFunction]);

    useEffect(() => {
        if (uploadProgress >= 100) {
            if (Math.random() < 0.5) {
                setDragState(ob.type_error);
            } else {
                setDragState(ob.type_success);
            }
        }
    }, [uploadProgress, ob.type_error, ob.type_success]);


    const handleDragEnter = (e) => {
        e.preventDefault();
        if (dragState !== ob.type_disabled) {
            setDragState(ob.type_over);
        }
    };

    const handleDragLeave = (e) => {
        e.preventDefault();
        if (dragState !== ob.type_disabled) {
            setDragState('');
        }
    };

    const handleDragOver = (e) => {
        e.preventDefault();
        if (dragState !== ob.type_disabled && dragState !== ob.type_over) {
            setDragState(ob.type_over);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        if (dragState !== ob.type_disabled) {
            const droppedFile = e.dataTransfer.files[0];
            if (droppedFile) {
                handleFileSelection(droppedFile);
            }
        }
    };

    const handleFileSelection = (selectedFile) => {
        if (dragState !== ob.type_disabled) {
            setFile(selectedFile);
            setDragState(ob.type_loading);
        }
    };

    const handleFileInputChange = (e) => {
        if (dragState !== ob.type_disabled) {
            const selectedFile = e.target.files[0];
            if (selectedFile) {
                handleFileSelection(selectedFile);
            }
        }
    };

    const isHover = () => {
        if (dragState !== ob.type_disabled && dragState !== ob.type_loading &&
            dragState !== ob.type_success && dragState !== ob.type_error) {
            setDragState(ob.type_over);
        }
    };

    const resetHover = () => {
        if (dragState === ob.type_over && dragState !== ob.type_disabled) {
            setDragState(ob.type);
        }
    };

    const getIconAndAlt = () => {
        switch (dragState) {
            case ob.type_disabled:
                return { icon: dragDropIconDisabled, alt: 'Upload disabled', className: 'disabled' };
            case ob.type_over:
                return { icon: dragDropIconOver, alt: 'File over dropzone', className: 'over' };
            case ob.type_active:
                return { icon: dragDropIconActive, alt: 'Dropzone active', className: 'active' };
            case ob.type_loading:
                return { icon: null, alt: 'Loading', className: 'loading' };
            case ob.type_success:
                return { icon: dragDropIconSuccess, alt: 'Upload successful', className: 'success' };
            case ob.type_error:
                return { icon: dragDropIconFailed, alt: 'Upload failed', className: 'error' };
            default:
                return { icon: dragDropIcon, alt: 'Default upload state', className: 'default' };
        }
    };

    const renderInteractiveText = () => {
        const isDisabled = dragState === ob.type_disabled;
        return (
            <>
                <span className="mobile-hidden">
                    <strong>Trascina</strong> qui il file o{' '}
                    {isDisabled ? (
                        'seleziona il file'
                    ) : (
                        <span
                            onClick={() => fileInputRef.current && fileInputRef.current.click()}
                            style={{ cursor: 'pointer', textDecoration: 'underline' }}
                        >
                            seleziona il file
                        </span>
                    )}
                </span>
                <span className="mobile-show">
                    {isDisabled ? (
                        'Clicca qui per caricare il file'
                    ) : (
                        <span onClick={() => fileInputRef.current && fileInputRef.current.click()} style={{ cursor: 'pointer', textDecoration: 'underline' }}>
                            Clicca qui per caricare il file
                        </span>
                    )}
                </span>
            </>
        );
    };

    const renderButtons = () => {
        switch (dragState) {
            case ob.type_loading:
                return (
                    <div className={`dragdrop-btn ${ob.drag_drop_type_class_button_loading}`}>
                        <button type="button" className={`btn btn-sm btn-${ob.drag_drop_type_button_loading}`} onClick={() => setDragState('')}>
                            <span>Interrompi</span>
                            <svg className="icon icon-xs">
                                <use href={`${sprite_fill}${ob.sprite_close}`}></use>
                            </svg>
                        </button>
                    </div>
                );
            case ob.type_success:
                return (
                    <div className={`dragdrop-btn ${ob.drag_drop_type_class_button}`}>
                        <button type="button" className={`btn btn-sm btn-${ob.drag_drop_type_button_success}`}>
                            <span>Caricamento completato</span>
                            <svg className="icon icon-xs">
                                <use href={`${sprite_fill}${ob.sprite_check_circle}`}></use>
                            </svg>
                        </button>
                    </div>
                );
            case ob.type_error:
                return (
                    <div className="dragdrop-btn error">
                        <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => setDragState('')}>
                            <span>Elimina</span>
                            <svg className="icon icon-xs">
                                <use href={`${sprite_fill}${ob.sprite_close}`}></use>
                            </svg>
                        </button>
                        <button type="button" className="btn btn-sm btn-danger" onClick={() => setDragState(ob.type_loading)}>
                            <span>Carica nuovamente</span>
                            <svg className="icon icon-xs">
                                <use href={`${sprite_fill}${ob.sprite_refresh}`}></use>
                            </svg>
                        </button>
                    </div>
                );
            default:
                return null;
        }
    };

    const { icon, alt, className } = getIconAndAlt();

    return (
        <div
            className={`form-dragdrop ${dragState}`}
            onDragEnter={handleDragEnter}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onMouseEnter={isHover}
            onMouseLeave={resetHover}
        >
            <div className="dragdrop-icon">
                {dragState !== ob.type_loading ? (
                    <div className={className}>
                        <img className="img-fluid" src={icon} alt={alt} />
                    </div>
                ) : (
                    <div className="loading">
                        <div className="loader-pecent">
                            {uploadProgress}%
                        </div>
                        <svg viewBox="0 0 90 90">
                            <path className="loader-bg" d="M45 10 a 35 35 0 0 1 0 70 a 35 35 0 0 1 0 -70"></path>
                            <path className="loader-circle" strokeDasharray="160, 220" d="M45 10 a 35 35 0 0 1 0 70 a 35 35 0 0 1 0 -70"></path>
                        </svg>
                    </div>
                )}
            </div>
            <div className="dragdrop-text">
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileInputChange}
                    style={{ display: 'none' }}
                    disabled={dragState === ob.type_disabled}
                />

                <div className="dragdrop-title default">
                    {renderInteractiveText()}
                </div>

                {dragState !== '' && dragState !== ob.type_disabled && file && (
                    <span className="dragdrop-desc uploading">
                        <span className="dragdrop-file text-icon">
                            <svg className="icon icon-xs">
                                <use href={`${sprite_fill}${ob.sprite_document_icon}`}></use>
                            </svg>
                            <span>{file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                        </span>
                        <div className="dragdrop-title">{file.name}</div>
                    </span>
                )}

                <div className="dragdrop-info">
                    {dragState === ob.type_loading && <div className="loading">Caricamento in corso...</div>}
                    {dragState === ob.type_success && <div className="success">Caricamento con successo</div>}
                    {dragState === ob.type_error && <div className="error">Caricamento non riuscito</div>}
                </div>

                {renderButtons()}
            </div>
        </div>
    );
};

export default DragDropUploader;