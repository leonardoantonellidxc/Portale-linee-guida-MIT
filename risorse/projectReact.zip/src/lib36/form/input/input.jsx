import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";

export const Input = ({ ob }) => {

    const commonProps = {
        className: "form-control",
        name: ob.name,
        placeholder: ob.placeholder,
        defaultValue: ob.value,
        'aria-labelledby': `${ob.name}Label`,
        disabled: ob.disabled,
        readOnly: ob.readonly
    };

    return (
        <div className={`form-group has-feedback ${ob.type}`}>
            <label id={`${ob.name}Label`}>{ob.label}</label>
            <div className="input-group">
                {ob.example && (
                    <div className="input-group-text">
                        <svg className="icon icon-sm">
                            <use href={`${sprite_fill}${ob.example_sprite}`} />
                        </svg>
                    </div>
                )}
                {ob.textarea ? (
                    <textarea {...commonProps}></textarea>
                ) : (
                    <input type="text" {...commonProps} />
                )}
                {ob.show && (
                    <a className="input-group-text" href="#">
                        <svg className="icon icon-sm">
                            <use href={`${sprite}#it-password-show`} />
                        </svg>
                    </a>
                )}
                {ob.hide && (
                    <a className="input-group-text" href="#">
                        <svg className="icon icon-sm">
                            <use href={`${sprite}#it-password-hide`} />
                        </svg>
                    </a>
                )}
            </div>
            <div className="field-helper">
                <div className="helper-text">
                    <svg className="icon">
                        <use href={`${sprite_fill}${ob.sprite_fill}`} />
                    </svg>
                    <span>{ob.message}</span>
                </div>
                {ob.helper_counter && (
                    <div className="helper-counter">0/20</div>
                )}
            </div>
        </div>
    );
};


export default Input;
