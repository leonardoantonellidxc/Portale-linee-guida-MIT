import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";
import { useState } from "react";

const Form = ({ ob }) => {

    const [isHovering, setIsHovering] = useState(ob.hovering);

    const handleMouseOver = () => setIsHovering(true);
    const handleMouseOut = () => setIsHovering(false);

    return (
        <div className={`form-group ${ob.className || ''} ${ob.type ? 'has-feedback' : ''}${isHovering ? 'hover' : ''}`} onMouseOver={handleMouseOver}
            onMouseOut={handleMouseOut}>
            <label id={`${ob.name}Label`}>
                {ob.label}
                {ob.required && <span className="field-mandatory">*</span>}
            </label>
            <div className="input-group">
                {ob.example && (
                    <div className="input-group-text">
                        <svg className="icon icon-sm">
                        <use href={`${sprite_fill}${ob.example_sprite}`} />
                        </svg>
                    </div>
                )}
                {ob.textarea ? (
                    <textarea
                        className="form-control"
                        name={ob.name}
                        placeholder={ob.placeholder}
                        defaultValue={ob.value}
                        aria-labelledby={`${ob.name}Label`}
                        disabled={ob.disabled}
                        readOnly={ob.readonly}
                    ></textarea>
                ) : ob.options ? (
                    <select
                        className="form-select"
                        name={ob.name}
                        aria-labelledby={`${ob.name}Label`}
                        disabled={ob.disabled}
                        readOnly={ob.readonly}
                    >
                        {ob.options.map((option, index) => (
                            <option key={index} value={option.value} hidden={option.hidden} >
                                {option.label}
                            </option>
                        ))}
                    </select>
                ) : (
                    <input
                        type={ob.type || "text"}
                        className="form-control"
                        name={ob.name}
                        placeholder={ob.placeholder}
                        defaultValue={ob.value}
                        aria-labelledby={`${ob.name}Label`}
                        disabled={ob.disabled}
                        readOnly={ob.readonly}
                    />
                )}
                {ob.show && (
                    <a className="input-group-text" href="#">
                        <svg className="icon icon-sm">
                            <use href={`${sprite}${ob.password_show_sprite}`} />
                        </svg>
                    </a>
                )}
                {ob.hide && (
                    <a className="input-group-text" href="#">
                        <svg className="icon icon-sm">
                            <use href={`${sprite}${ob.is_password_hide_sprite}`} />
                        </svg>
                    </a>
                )}
                {ob.isDate && (
                    <span className="input-group-text">
                        <svg className="icon icon-sm">
                            <use href={`${sprite}${ob.calendar_sprite}`} />
                        </svg>
                    </span>
                )}
            </div>
            {(ob.message || ob.helper_counter) && (
                <div className="field-helper">
                    <div className="helper-text">
                        <svg className="icon">
                            <use href={`${sprite_fill}${ob.sprite_fill}`} />
                        </svg>
                        <span>{ob.message}</span>
                    </div>
                    {ob.helper_counter && (
                        <div className="helper-counter">0/20</div>
                    )}
                </div>
            )}
        </div>
    );
};

export default Form;