import React, { useState, useEffect, useRef } from 'react';
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";

const DatePicker = ({ ob }) => {
  const [value, setValue] = useState(ob.value || '');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [dateValue, setDateValue] = useState(ob.value);
  const [dateType, setDateType] = useState(ob.type);
  const dropdownRef = useRef(null);
  const inputRef = useRef(null);


  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (value) {
      const [day, month, year] = value.split('/').map(Number);
      setCurrentDate(new Date(year, month - 1, day));
    }
  }, [value]);

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target) && !inputRef.current.contains(event.target)) {
      setIsDropdownOpen(false);
    }
  };

  const toggleDropdown = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleDateClick = (day) => {
    const selectedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    const formattedDate = formatDate(selectedDate);
    setValue(formattedDate);
    setIsDropdownOpen(false);
  };

  const handleInputChange = (e) => {
    setValue(e.target.value);
    const [day, month, year] = e.target.value.split('/').map(Number);
    if (day && month && year) {
      setCurrentDate(new Date(year, month - 1, day));
    }
  };

  const handleInputClick = (e) => {
    e.stopPropagation();
    setIsDropdownOpen(true);
  };

  const handleMonthChange = (monthIndex) => {
    setCurrentDate(prevDate => new Date(prevDate.getFullYear(), monthIndex, prevDate.getDate()));
  };

  const handleYearChange = (year) => {
    setCurrentDate(prevDate => new Date(year, prevDate.getMonth(), prevDate.getDate()));
  };

  const formatDate = (date) => {
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
  };

  const renderCalendar = () => {
    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
    const days = [];

    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="day empty"></div>);
    }

    for (let i = 1; i <= daysInMonth; i++) {
      days.push(
        <div key={i} className="day" onClick={() => handleDateClick(i)}>
          {i}
        </div>
      );
    }

    return days;
  };

  useEffect(() => {
    if (ob.toValidate) {
      validateInput();
    }
  }, [dateValue]);

  const validateInput = () => {
    if (!ob.toValidate) {
      return;
    }
    const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const match = dateValue.match(datePattern);
    if (!match) {
      setDateType('is-invalid');
      return;
    }

    const day = parseInt(match[1], 10);
    const month = parseInt(match[2], 10) - 1;
    const year = parseInt(match[3], 10);

    const date = new Date(year, month, day);

    if (date.getDate() !== day || date.getMonth() !== month || date.getFullYear() !== year) {
      setDateType('is-invalid');
      return;
    }

    if (year < ob.years[0] || year > ob.years[ob.years.length - 1]) {
      setDateType('is-invalid');
      return;
    }

    setDateType('is-valid');
  };

  const handleDateChange = (e) => {
    setDateValue(e.target.value);
  };

 

  return (
    <div className="group-inline" ref={dropdownRef}>
      <div className={`form-group datepicker dropdown has-feedback field-14 ${ob.type}`}>
        <label id={`${ob.name}Label`}>{ob.title}</label>
        <div className="input-group">
          <div className="input-group-text">
            <svg className="icon icon-sm">
              <use href={`${sprite_fill}${ob.calendar_sprite}`}></use>
            </svg>
          </div>
          <div className="input-group-text divider"></div>
          <input
            ref={inputRef}
            type="text"
            className="form-control"
            name={ob.name}
            aria-labelledby={`${ob.name}Label`}
            placeholder="gg/mm/aaaa"
            value={value}
            onChange={handleDateChange}
            onClick={handleInputClick}
          />
          <button
            className="input-group-text dropdown-toggle"
            type="button"
            aria-expanded={isDropdownOpen ? 'true' : 'false'}
            onClick={toggleDropdown}
          >
            <svg className="icon icon-sm">
              <use href={`${sprite}${ob.expand_sprite}`}></use>
            </svg>
          </button>
          {isDropdownOpen && (
            <div className="dropdown-menu show">
              <div className="date-header">
                <div className="form-group">
                  <select
                    className="form-select"
                    value={currentDate.getMonth()}
                    onChange={(e) => handleMonthChange(parseInt(e.target.value))}
                  >
                    {ob.months.map((month, index) => (
                      <option key={index} value={index}>{month}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <select
                    className="form-select"
                    value={currentDate.getFullYear()}
                    onChange={(e) => handleYearChange(parseInt(e.target.value))}
                  >
                    {ob.years.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="date-body">
                <div className="month-head">
                  <div className="day">Lun</div>
                  <div className="day">Mar</div>
                  <div className="day">Mer</div>
                  <div className="day">Gio</div>
                  <div className="day">Ven</div>
                  <div className="day">Sab</div>
                  <div className="day">Dom</div>
                </div>
                <div className="month-days">
                  {renderCalendar()}
                </div>
              </div>
            </div>
          )}
        </div>
        {ob.div_type && (
          <div className={`${ob.div_type}-feedback`}>
            <svg className="icon">
              <use href={`${sprite_fill}${ob.sprite_image}`}></use>
            </svg>
            <span>{ob.message}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default DatePicker;