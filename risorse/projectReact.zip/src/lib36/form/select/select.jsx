import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { useState } from 'react';

const Select = ({ ob }) => {

  const [isHovering, setIsHovering] = useState(false);

  const handleMouseOver = () => setIsHovering(true);

  const handleMouseOut = () => setIsHovering(false);

  return (
    <div className={`form-group has-feedback ${isHovering ? "hover" : ''} ${ob.type}`}>
      <label id={ob.id}>Label field</label>
      <div className="input-group">
        {ob.is_icon && (
          <>
            <div className="input-group-text">
              <svg className={ob.is_icon ? "icon icon-sm" : ""}>
                <use href={`${sprite_fill}${ob.sprite_example}`} />
              </svg>
            </div>
            <div className="input-group-text divider" />
          </>
        )}
        <select
          className="form-select"
          name={ob.id}
          placeholder="Placeholder field"
          defaultValue="Lorem ipsum"
          aria-labelledby={ob.id}
          onMouseOver={handleMouseOver}
          onMouseOut={handleMouseOut}
          disabled={ob.type === 'disabled' || ob.type === 'readonly'}
        >
          {ob.options && ob.options.map((option, index) => (
            <option key={index} value={option.value}>
              {option.text}
            </option>
          ))}
        </select>
      </div>
      <div className="field-helper">
        <div className="helper-text">
          <svg className="icon">
            <use href={`${sprite_fill}${ob.sprite_fill}`} />
          </svg>
          <span>{ob.message}</span>
        </div>
      </div>
    </div>
  );
};

export default Select;