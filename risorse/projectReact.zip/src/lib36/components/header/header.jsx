import { useState } from 'react';
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";
import flag_it from "../../static/imgs/icon/flag/it.svg";
import flag_fr from "../../static/imgs/icon/flag/fr.svg";
import flag_esp from "../../static/imgs/icon/flag/es.svg";
import header_logo from "../../static/imgs/header/logo.svg";
import { Link } from 'react-router-dom';

const Header = () => {
    const [loggedIn, setLoggedIn] = useState(false);
    const [activeItems, setActiveItems] = useState({});


    const navLeftMenu = [
        { name: 'Home', link: '/', is_disabled: false },
        { name: 'Servizi', link: '/servizi', is_disabled: false },
        { name: 'Contatti', link: '/contatti', is_disabled: false },
        { name: 'Recapiti', link: '/Recapiti', is_disabled: false },
        { name: 'Mail', link: '/mail', is_disabled: false },
        { name: 'Testi', link: '/testi', is_disabled: false },
    ];

    const portalName = {
        line1: 'Portale',
        line2: 'Servizi',
    };

    const inputSearch = {
        placeholder: 'Cerca nel sito...',
        value: '',
        aria_label: 'Cerca nel sito',
    };

    const menuItems = [
        {
            title: 'Home',
            link: '/',
            is_dropdown: false,
            mega_menu: false,
            is_active: false,
            is_disabled: false,
            demon_menu_key: 'mega-menu1',
            demon_menu_nav: true,
            has_svg: true,
            expand: true,
        },
        {
            title: 'Componenti A-B',
            mega_menu: false,
            is_active: false,
            is_disabled: false,
            demon_menu_key: 'mega-menu2',
            demon_menu_nav: true,
            has_svg: true,
            expand: true,
            is_dropdown: true,
            dd_menu_items: [
                { name: 'Accordion', link: '/accordion' },
                { name: 'Bottom bar', link: '/bottom-bar' },
            ],
        },
        {
            title: 'Componenti C-D',
            is_dropdown: true,
            mega_menu: false,
            is_active: false,
            is_disabled: false,
            demon_menu_key: 'mega-menu3',
            demon_menu_nav: true,
            has_svg: true,
            expand: true,
            dd_menu_items: [
                { name: 'Card', link: '/card' },
                { name: 'Dropdown', link: '/dropdown' },
                { name: 'Hero Banner', link: '/hero-banner' },
            ],
        },
        {
            title: 'Componenti E-Z',
            is_dropdown: true,
            mega_menu: false,
            is_active: false,
            is_disabled: false,
            demon_menu_key: 'mega-menu4',
            demon_menu_nav: true,
            has_svg: true,
            expand: true,
            dd_menu_items: [
                { name: 'Modali', link: '/modali' },
                { name: 'Stepper', link: '/stepper' },
                { name: 'Time line', link: '/timeline' },
                { name: 'Tab', link: '/tab-menu' },
                { name: 'Table', link: '/table' },
                { name: 'Sidebar Navigation', link: '/sidebar-navigation' },
                { name: 'Pagination', link: '/pagination' },
            ],
        },
        {
            title: 'Form',
            is_dropdown: true,
            mega_menu: false,
            is_active: false,
            is_disabled: false,
            demon_menu_key: 'mega-menu5',
            demon_menu_nav: true,
            has_svg: true,
            expand: true,
            dd_menu_items: [
                { name: 'Date Picker', link: '/date-picker' },
                { name: 'Input', link: '/input' },
                { name: 'Input Search', link: '/input-search' },
                { name: 'Select', link: '/select' },
                { name: 'Slider', link: '/slider' },
                { name: 'Uploader', link: '/uploader' },
            ],
        },
        {
            title: 'Mega Menu',
            is_dropdown: true,
            mega_menu: true,
            is_active: false,
            is_disabled: false,
            demon_menu_key: 'mega-menu6',
            demon_menu_nav: true,
            has_svg: true,
            expand: true,
            dd_menu_cards: [
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit... ',
                    label_text: 'Label Text',
                },
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit... ',
                    label_text: 'Label Text',
                },
            ],
            dd_menu_most_used: [
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do elit consectetur. ',
                    label: 'Nuovo',
                    label_text: 'Label text',
                },
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do elit consectetur. ',
                    label: 'In evidenza',
                    label_text: 'Label text',
                },
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do elit consectetur. ',
                    label: 'In evidenza',
                    label_text: 'Label text',
                },
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do elit consectetur. ',
                    label: 'In evidenza',
                    label_text: 'Label text',
                },
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do elit consectetur. ',
                    label: 'In evidenza',
                    label_text: 'Label text',
                },
                {
                    title: 'Servizio/Voce di menù',
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do elit consectetur. ',
                    label: 'In evidenza',
                    label_text: 'Label text',
                },
            ],
        },
    ];

    const addClassToBody = () => {
        document.body.classList.add('menu-show');
    };

    const removeClassToBody = () => {
        document.body.classList.remove('menu-show');
    };

    const login = () => {
        setLoggedIn(true);
    };

    const logout = () => {
        setLoggedIn(false);
    };

    const handleActive = (index) => {
        setActiveItems(prev => ({
            ...prev,
            [index]: !prev[index]
        }));
    };

    return (
        <header className="navbar navbar-dark fixed-top">
            <a className="visually-hidden-focusable skip-to-content" href="#PageV">
                Salta direttamente al contenuto
            </a>

            <div className="header-top">
                <div className="container">
                    <div className="nav-left">
                        <nav className="nav-menu" aria-label="Menu superiore">
                            <ul className="nav navbar-nav">
                                {navLeftMenu.map((item, index) => (
                                    <li key={index} className="nav-item">
                                        <a
                                            className={`nav-link ${item.is_disabled ? 'disabled' : ''}`}
                                            href={item.link}
                                        >
                                            {item.name}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>

            <div className="header-middle">
                <div className="container">
                    <div className="nav-left">
                        <a className="mobile-handle" href="#">
                            <div className="hamburger" onClick={addClassToBody}>
                                <svg className="icon icon-sm" aria-hidden="true">
                                    <use href={`${sprite}#it-burger`}></use>
                                </svg>
                            </div>
                            <div className="menu-close" onClick={removeClassToBody}>
                                <svg className="icon icon-sm" aria-hidden="true">
                                    <use href={`${sprite}#it-close-big`}></use>
                                </svg>
                            </div>
                        </a>

                        <a
                            className="navbar-brand"
                            title="LOGO"
                            href="#"
                            data-demon-nav="home"
                            data-demon-ev="true"
                        >
                            <img className="brand-logo" src={header_logo} alt="Logo" />
                            <div className="brand-text">
                                {portalName.line1} <br />
                                {portalName.line2}
                            </div>
                        </a>
                    </div>

                    <div className="nav-right">
                        <div className="search-wrapper">
                            <div className="form-group">
                                <div className="input-group">
                                    <div className="input-group-text">
                                        <svg className="icon icon-xs">
                                            <use href={`${sprite}#it-search`}></use>
                                        </svg>
                                    </div>
                                    <input
                                        type="text"
                                        className="form-control"
                                        name="main-search"
                                        placeholder={inputSearch.placeholder}
                                        defaultValue={inputSearch.value}
                                        aria-label={inputSearch.aria_label}
                                    />
                                </div>
                            </div>

                            <button type="button" className="btn btn-white">
                                <svg className="icon icon-xs">
                                    <use href={`${sprite}#it-search`}></use>
                                </svg>
                            </button>
                        </div>

                        <div className="lang-wrapper dropdown">
                            <a
                                className="lang-toggle"
                                href="#"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                            >
                                <img
                                    src={flag_it}
                                    aria-hidden="true"
                                    alt="Italian flag"
                                />
                                <span> ITA </span>
                                <svg className="icon icon-xs dropdown-icon" aria-hidden="true">
                                    <use href={`${sprite}#it-expand`}></use>
                                </svg>
                            </a>
                            <ul className="dropdown-menu">
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <img
                                            src={flag_it}
                                            aria-hidden="true"
                                            alt="Italian flag"
                                        />
                                        <span> ITA </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <img
                                            src={flag_fr}
                                            aria-hidden="true"
                                            alt="French flag"
                                        />
                                        <span> FRA </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <img
                                            src={flag_esp}
                                            aria-hidden="true"
                                            alt="Spanish flag"
                                        />
                                        <span> ESP </span>
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <div className="v-line"></div>

                        {!loggedIn ? (
                            <div className="login-wrapper">
                                <button type="button" className="btn btn-sm btn btn-white demon-unlogged" onClick={login}>
                                    <svg className="icon icon-sm" aria-hidden="true">
                                        <use href={`${sprite}#it-user`}></use>
                                    </svg>
                                    <span className="mobile-hidden-lg"> Accedi al portale </span>
                                </button>
                            </div>
                        ) : (
                            <div className="profile-wrapper dropdown demon-logged">
                                <a
                                    className="btn btn-sm btn-white"
                                    href="#"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                >
                                    <div className="avatar avatar-sm avatar-primary">
                                        <svg className="icon">
                                            <use href={`${sprite_fill}#it-user`}></use>
                                        </svg>
                                    </div>
                                    <span className="mobile-hidden-lg"> Carla Rossi </span>
                                    <svg className="icon icon-xs dropdown-icon" aria-hidden="true">
                                        <use href={`${sprite}#it-expand`}></use>
                                    </svg>
                                </a>
                                <ul className="dropdown-menu" data-demon-menu="top-right"></ul>
                            </div>
                        )}

                        <button type="button" className="btn btn-sm btn btn-outline-white">
                            <svg className="icon icon-sm" aria-hidden="true">
                                <use href={`${sprite}#it-more-actions`}></use>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <div className="header-bottom">
                <div className="container">
                    <div className="nav-left">
                        <nav className="nav-menu" aria-label="Menu principale">
                            <ul className="nav navbar-nav" data-demon-menu="bottom-left">
                                {menuItems.map((item, index) => (
                                    <li
                                        key={index}
                                        className={`nav-item ${item.is_dropdown ? 'dropdown' : ''} ${item.mega_menu ? 'mega-menu' : ''} ${item.is_active ? 'active' : ''} ${item.is_disabled ? 'disabled' : ''}`}
                                        data-demon-menu-key={item.demon_menu_key}
                                        data-demon-menu-nav={item.demon_menu_nav}
                                    >
                                        <Link
                                            to={item.link || '#'}
                                            className={`nav-link ${item.is_active ? 'active' : ''} ${item.is_disabled ? 'disabled' : ''}`}
                                            role="button"
                                            aria-expanded="false"
                                            data-bs-toggle={item.is_dropdown ? 'dropdown' : undefined}
                                        >
                                            <span className="text-icon">
                                                {item.has_svg && (
                                                    <svg className="icon icon-xs">
                                                        <use href={`${sprite}#it-example`}></use>
                                                    </svg>
                                                )}
                                                <span>{item.title}</span>
                                            </span>
                                            {item.expand && (
                                                <svg className="icon icon-xs dropdown-icon">
                                                    <use href={`${sprite}#it-expand`}></use>
                                                </svg>
                                            )}
                                        </Link>
                                        {item.dd_menu_items && (
                                            <div className="dd-menu">
                                                <span className="dropdown-menu" style={{ display: 'none' }}></span>
                                                <ul className="nav navbar-nav">
                                                    {item.dd_menu_items.map((subItem, subIndex) => (
                                                        <li
                                                            key={subIndex}
                                                            className="nav-item"
                                                            data-demon-menu-key={item.demon_menu_key}
                                                            data-demon-menu-nav={item.demon_menu_nav}
                                                        >
                                                            <a href={subItem.link} className="nav-link">
                                                                {subItem.name}
                                                            </a>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                        {item.mega_menu && (
                                            <div className="dd-menu">
                                                <div className="container">
                                                    <div className="card">
                                                        <div className="card-body">
                                                            <div className="row">
                                                                {item.dd_menu_cards.map((card, cardIndex) => (
                                                                    <div key={cardIndex} className="col-lg-6 mega-col">
                                                                        <span className="dropdown-menu" style={{ display: 'none' }}></span>
                                                                        <div className="card-title h5">{card.title}</div>
                                                                        <div className="card-text">{card.text}</div>
                                                                        <div className="btn-toolbar">
                                                                            <div className="btn-group-left">
                                                                                <button type="button" className="btn btn-sm btn-primary">
                                                                                    <span>{card.label_text}</span>
                                                                                    <svg className="icon">
                                                                                        <use href={`${sprite}#it-chevron-right`}></use>
                                                                                    </svg>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="h6 pt-4">Servizi più usati</div>
                                                    <div className="row">
                                                        {item.dd_menu_most_used.map((megaItem, megaIndex) => (
                                                            <div key={megaIndex} className="col-lg-4 pt-4">
                                                                <div className="mega-item">
                                                                    <div className="title-bar">
                                                                        <div>
                                                                            <div className="h6">{megaItem.title}</div>
                                                                            <div className="item-text">{megaItem.text}</div>
                                                                        </div>
                                                                        <div className="badge badge-primary">{megaItem.label}</div>
                                                                    </div>
                                                                    <div className="btn-toolbar">
                                                                        <div className="btn-group-left">
                                                                            <button type="button" className="btn btn-sm btn-bare bare-white">
                                                                                <span>{megaItem.label_text}</span>
                                                                                <svg className="icon">
                                                                                    <use href={`${sprite}#it-chevron-right`}></use>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        </nav>
                    </div>

                    <div className="nav-right">
                        <nav className="nav-menu" aria-label="Menu secondario">
                            <ul className="nav navbar-nav" data-demon-menu="bottom-right"></ul>
                        </nav>
                    </div>
                </div>
            </div>

            <div className="nav-mobile">
                <div className="mobile-wrapper">
                    <div className="mobile-header h5">Menù</div>
                    <nav className="mobile-inner" aria-label="Navigazione principale mobile">
                        <ul className="nav navbar-nav nav-top">
                            {menuItems.map((item, index) => (
                                <li
                                    key={index}
                                    className={`nav-item ${item.is_dropdown ? 'dropdown' : ''} ${item.mega_menu ? 'mega-menu' : ''} ${item.is_active ? 'active' : ''} ${item.is_disabled ? 'disabled' : ''}`}
                                    data-demon-menu-key={item.demon_menu_key}
                                    data-demon-menu-nav={item.demon_menu_nav}
                                >
                                    <a
                                        href="#"
                                        className={`nav-link ${item.is_active ? 'active' : ''} ${item.is_disabled ? 'disabled' : ''}`}
                                        role="button"
                                        aria-expanded="false"
                                        data-toggle={item.is_dropdown ? 'dropdown' : undefined}
                                        data-bs-toggle={item.is_dropdown ? 'dropdown' : undefined}
                                    >
                                        <span className="text-icon">
                                            {item.has_svg && (
                                                <svg className="icon icon-xs">
                                                    <use href={`${sprite}#it-example`}></use>
                                                </svg>
                                            )}
                                            <span>{item.title}</span>
                                        </span>
                                        {item.expand && (
                                            <svg className="icon icon-xs dropdown-icon">
                                                <use href={`${sprite}#it-expand`}></use>
                                            </svg>
                                        )}
                                    </a>
                                    {item.dd_menu_items && (
                                        <div className="dropdown-menu">
                                            <ul className="nav navbar-nav">
                                                {item.dd_menu_items.map((subItem, subIndex) => (
                                                    <li
                                                        key={subIndex}
                                                        className="nav-item"
                                                        data-demon-menu-key={subItem.demon_menu_key}
                                                        data-demon-menu-nav={subItem.demon_menu_nav}
                                                    >
                                                        <a href={subItem.link} className="nav-link">
                                                            {subItem.name}
                                                        </a>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                    {item.mega_menu && (
                                        <div className="dropdown-menu">
                                            <div className="mega-area">
                                                <div className="container">
                                                    <div className="card">
                                                        <div className="card-body">
                                                            <div className="row">
                                                                {item.dd_menu_cards.map((card, cardIndex) => (
                                                                    <div key={cardIndex} className="col-lg-6 mega-col">
                                                                        <div className="card-title h5">{card.title}</div>
                                                                        <div className="card-text">{card.text}</div>
                                                                        <div className="btn-toolbar">
                                                                            <div className="btn-group-left">
                                                                                <button type="button" className="btn btn-sm btn-primary">
                                                                                    <span>{card.label_text}</span>
                                                                                    <svg className="icon">
                                                                                        <use href={`${sprite}#it-chevron-right`}></use>
                                                                                    </svg>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="h6 pt-4">Servizi più usati</div>
                                                    <div className="row">
                                                        {item.dd_menu_most_used.map((megaItem, megaIndex) => (
                                                            <div key={megaIndex} className="col-lg-4 pt-4">
                                                                <div className="mega-item">
                                                                    <div className="title-bar">
                                                                        <div>
                                                                            <div className="h6">{megaItem.title}</div>
                                                                            <div className="item-text">{megaItem.text}</div>
                                                                        </div>
                                                                        <div className="badge badge-primary">{megaItem.label}</div>
                                                                    </div>
                                                                    <div className="btn-toolbar">
                                                                        <div className="btn-group-left">
                                                                            <button type="button" className="btn btn-sm btn-bare bare-white">
                                                                                <span>{megaItem.label_text}</span>
                                                                                <svg className="icon">
                                                                                    <use href={`${sprite}#it-chevron-right`}></use>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </li>
                            ))}
                        </ul>

                        <ul className="nav navbar-nav nav-bottom">
                            {navLeftMenu.map((item, index) => (
                                <li key={index} className="nav-item">
                                    <a
                                        className={`nav-link ${item.is_disabled ? 'disabled' : ''}`}
                                        href={item.link}
                                    >
                                        {item.name}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </nav>
                    <div className="mobile-footer">
                        <button type="button" className="btn btn-sm btn-outline-white">
                            <span> Torna al portale </span>
                            <svg className="icon icon-xs" aria-hidden="true">
                                <use href={`${sprite}#it-external-link`}></use>
                            </svg>
                        </button>

                        <div className="lang-wrapper dropup">
                            <a
                                className="lang-toggle"
                                href="#"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                            >
                                <img
                                    src={flag_it}
                                    aria-hidden="true"
                                    alt="Italian flag"
                                />
                                <span> ITA </span>
                                <svg className="icon icon-xs dropdown-icon" aria-hidden="true">
                                    <use href={`${sprite}#it-expand`}></use>
                                </svg>
                            </a>
                            <ul className="dropdown-menu">
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <img
                                            src={flag_it}
                                            aria-hidden="true"
                                            alt="Italian flag"
                                        />
                                        <span> ITA </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <img
                                            src={flag_fr}
                                            aria-hidden="true"
                                            alt="French flag"
                                        />
                                        <span> FRA </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <img
                                            src={flag_esp}
                                            aria-hidden="true"
                                            alt="Spanish flag"
                                        />
                                        <span> ESP </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div className="search-mobile">
                <div className="mobile-wrapper">
                    <div className="mobile-header">
                        <div className="form-group">
                            <div className="input-group">
                                <div className="input-group-text">
                                    <svg className="icon icon-xs">
                                        <use href={`${sprite}#it-search`}></use>
                                    </svg>
                                </div>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="main-search-mobile"
                                    placeholder="Search"
                                    defaultValue=""
                                    aria-label="Lorem ipsum dolor sit"
                                />
                                <div className="input-group-text active-option">
                                    <svg className="icon icon-xxs">
                                        <use href={`${sprite}#it-streamline`}></use>
                                    </svg>
                                </div>
                                <div className="input-group-text active-option">
                                    <svg className="icon icon-xxs">
                                        <use href={`${sprite_fill}#it-close-circle`}></use>
                                    </svg>
                                </div>
                                <div className="input-group-text active-closer"></div>
                            </div>
                        </div>
                    </div>
                    <div className="mobile-inner">
                        <div className="dropdown-menu show">
                            <ul className="scrollable">
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <span> Label text </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <span> Label text </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <span> Label text </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <span> Label text </span>
                                    </a>
                                </li>
                                <li>
                                    <a className="dropdown-item" href="#">
                                        <span> Label text </span>
                                    </a>
                                </li>
                            </ul>

                            <div className="dropdown-link">
                                <a type="button" className="btn btn-bare btn-sm" href="#">
                                    Mostra tutti i risultati
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
