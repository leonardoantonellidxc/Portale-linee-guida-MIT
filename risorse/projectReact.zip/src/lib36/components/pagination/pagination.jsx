import { useCallback } from 'react';
import sprite from "../../static/imgs/icon/sprite.svg";

const Pagination = ({ ob, setActive }) => {
  const pages = Array(ob.lastPage).fill(0).map((_, i) => i + 1);

  const goToPreviousPage = useCallback((event) => {
    event.preventDefault();
    if (ob.active !== 1) {
      setActive(ob.active - 1);
    }
  }, [ob.active, setActive]);

  const goToNextPage = useCallback((event) => {
    event.preventDefault();
    if (ob.active !== ob.lastPage) {
      setActive(ob.active + 1);
    }
  }, [ob.active, ob.lastPage, setActive]);

  const changePage = useCallback((n, event) => {
    event.preventDefault();
    setActive(n);
  }, [setActive]);

  const preventDefault = useCallback((event) => {
    event.preventDefault();
  }, []);

  return (
    <nav className="pagination-wrapper" aria-label="Page navigation example">
      <ul className="pagination">
        {ob.arrows && (
          <>
            <li className={`page-item item-icon ${ob.active === 1 ? 'disabled' : ''}`}>
              <a className="page-link" aria-label="Prima pagina" href="#" onClick={(e) => changePage(1, e)}>
                <svg className="icon icon-xs" aria-hidden="true">
                  <use href={`${sprite}${ob.double_arrow_left}`}></use>
                </svg>
              </a>
            </li>
            <li className={`page-item item-icon ${ob.active === 1 ? 'disabled' : ''}`}>
              <a className="page-link" aria-label="Precedente" href="#" onClick={goToPreviousPage}>
                <svg className="icon icon-xs" aria-hidden="true">
                  <use href={`${sprite}${ob.chevron_left}`}></use> 
                </svg>
              </a>
            </li>
          </>
        )}
        {ob.text && (
          <li className={`page-item item-text ${ob.active === 1 ? 'disabled' : ''}`}>
            <a className="page-link" aria-label="Precedente" href="#" onClick={goToPreviousPage}>
              <span>Precedente</span>
            </a>
          </li>
        )}
        {pages.map((j) => {
          if (j === 1) {
            return (
              <li key={j} className={`page-item item-number ${ob.active === j ? 'active' : ''}`}>
                <a
                  className="page-link"
                  href="#"
                  onClick={(e) => changePage(j, e)}
                  aria-current={ob.active === j ? 'page' : undefined}
                >
                  {j}
                </a>
              </li>
            );
          }
          if (j === ob.lastPage || (j >= ob.active - ob.range && j <= ob.active + ob.range)) {
            return (
              <li key={j} className={`page-item item-number ${ob.active === j ? 'active' : ''}`}>
                <a
                  className="page-link"
                  href="#"
                  onClick={(e) => changePage(j, e)}
                  aria-current={ob.active === j ? 'page' : undefined}
                >
                  {j}
                </a>
              </li>
            );
          }
          if ((j === 2 && ob.active - ob.range > 2) || (j === ob.lastPage - 1 && ob.active + ob.range < ob.lastPage - 1)) {
            return (
              <li key={`ellipsis-${j}`} className="page-item item-icon">
                <a className="page-link" href="#" onClick={preventDefault}>...</a>
              </li>
            );
          }
          return null;
        })}
        {ob.text && (
          <li className={`page-item item-text ${ob.active === ob.lastPage ? 'disabled' : ''}`}>
            <a className="page-link" href="#" onClick={goToNextPage}>
              <span>Successiva</span>
            </a>
          </li>
        )}
        {ob.arrows && (
          <>
            <li className={`page-item item-icon ${ob.active === ob.lastPage ? 'disabled' : ''}`}>
              <a className="page-link" aria-label="Successiva" href="#" onClick={goToNextPage}>
                <svg className="icon icon-xs" aria-hidden="true">
                  <use href={`${sprite}${ob.chevron_right}`}></use>
                </svg>
              </a>
            </li>
            <li className={`page-item item-icon ${ob.active === ob.lastPage ? 'disabled' : ''}`}>
              <a className="page-link" href="#" aria-label="Ultima" onClick={(e) => changePage(ob.lastPage, e)}>
                <svg className="icon icon-xs" aria-hidden="true">
                  <use href={`${sprite}${ob.double_arrow_right}`}></use>
                </svg>
              </a>
            </li>
          </>
        )}
      </ul>
      {ob.skip_page && !ob.dropdown && (
        <div className="pagination-skip">
          <div className="form-group">
            <span id={ob.input_id}>Vai a pagina</span>
            <input
              type="text"
              className="form-control"
              name={ob.input_name}
              defaultValue={ob.input_value}
              aria-labelledby={ob.input_id}
              maxLength="3"
            />
            <button
              type="button"
              className="btn btn-primary"
              onClick={(e) => changePage(parseInt(ob.input_value, 10), e)}
            >
              <span>Vai</span>
            </button>
          </div>
        </div>
      )}
      {ob.dropdown && (
        <div className="pagination-skip">
          <div className="form-group">
            <span id={`${ob.select.name}Label`}>Vai a pagina</span>
            <select
              className="form-select"
              name={ob.select.name}
              value={ob.select.value}
              aria-labelledby={`${ob.select.name}Label`}
              onChange={(e) => setActive(parseInt(e.target.value, 10))}
            >
              {ob.select.options.map((option) => (
                <option
                  key={option.value}
                  value={option.value}
                >
                  {option.value}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Pagination;