import { useState, useEffect } from "react";
import sprite from "../../static/imgs/icon/sprite.svg";

const SidebarNavigation = ({ ob, activeFunctions }) => {
    const [activeItem, setActiveItem] = useState(null);
    const [activeSubItem, setActiveSubItem] = useState(null);

    const handleActive = (index, item) => {
        setActiveItem(activeItem === index ? null : index);
        setActiveSubItem(null);
        if (item && item.button_action) {
            activeFunctions(item.button_action)
        }
    };

    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);


    const handleSubItemActive = (index, subIndex, subItem) => {
        setActiveSubItem(activeSubItem === `${index}-${subIndex}` ? null : `${index}-${subIndex}`);
        setActiveItem(null);
        if (subItem && subItem.button_action) {
            activeFunctions(subItem.button_action)
        }
    };


    return (
        <div className="container-frame container" data-demon-cf="menuSide" data-demon-cf-id="menu">
            <div className="frame-nav" data-demon-include="menu">
                <div className="sidebar-wrapper">
                    <div className="card sidebar">
                        <div className="card-header">
                            <div className="h6">{ob.title}</div>
                        </div>
                        <div className="sidebar-scroll">
                            <ul className="sidebar-list">
                                {ob.items.map((item, index) => (
                                    <li key={index} className={item.isDropdown ? 'list-dropdown' : ''}>
                                        {!item.isDropdown ? (
                                            <a
                                                className={`list-link ${activeItem === index ? 'active' : ''}`}
                                                href={item.link}
                                                onClick={() => handleActive(index, item)}
                                            >
                                                <div className={`list-item ${activeItem === index ? 'active' : ''}`}>
                                                    <span>{item.text}</span>
                                                </div>
                                            </a>
                                        ) : (
                                            <>
                                                <a
                                                    className={`list-link collapsed ${activeItem === index ? 'active' : ''}`}
                                                    href={`#collapse${index}`}
                                                    role="button"
                                                    data-bs-toggle="collapse"
                                                    aria-expanded="false"
                                                    aria-controls={`collapse${index}`}
                                                    onClick={() => handleActive(index)}
                                                >
                                                    <div className={`list-item ${activeItem === index ? 'active' : ''}`}>
                                                        <span>{item.text}</span>
                                                        <svg className="icon icon-sm dropdown-icon" aria-hidden="true">
                                                            <use href={`${sprite}${item.sprite_expand}`}></use>
                                                        </svg>
                                                    </div>
                                                </a>
                                                {item.isDropdown && (
                                                    <ul className="sidebar-list collapse" id={`collapse${index}`}>
                                                        {item.sub_items.map((subItem, subIndex) => (
                                                            <li key={subIndex}>
                                                                <a
                                                                    className={`list-link ${activeSubItem === `${index}-${subIndex}` ? 'active' : ''}`}
                                                                    href="#"
                                                                    onClick={() => handleSubItemActive(index,subIndex,subItem)}
                                                                >
                                                                    <div className={`list-item ${activeSubItem === `${index}-${subIndex}` ? 'active' : ''}`}>
                                                                        <span>{subItem.text}</span>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                )}
                                            </>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div className="frame-body"></div>
        </div>
    );
};

export default SidebarNavigation;