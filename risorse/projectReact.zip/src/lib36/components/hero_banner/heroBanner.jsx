import sprite from "../../static/imgs/icon/sprite.svg";
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { useState, useEffect } from "react";


const HeroBanner = ({ ob, activeFunctions }) => {

    const [searchValue, setSearchValue] = useState(ob.inputSearch.value || '');

    const handleSearchChange = (event) => {
        setSearchValue(event.target.value);
    };

    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);

    return (
        <div className={`page-hero ${ob.level === 1 ? 'hero-l1' : 'hero-l2'}`}>
            <div className="container">
                <div className="container-hero">
                    {ob.level === 2 && (
                        <nav className="breadcrumb-container" aria-label="Percorso di navigazione">
                            <ol className="breadcrumb">
                                {ob.breadcrumb.map((item, index) => (
                                    <li
                                        key={index}
                                        className={`breadcrumb-item ${item.active ? 'active' : ''}`}
                                        aria-current={item.active ? 'page' : undefined}
                                    >
                                        {!item.active ? (
                                            <a className="link" href={item.link}>
                                                <span>{item.pageTitle}</span>
                                            </a>
                                        ) : (
                                            <div className="text-icon">
                                                <span>{item.pageTitle}</span>
                                            </div>
                                        )}
                                    </li>
                                ))}
                            </ol>
                        </nav>
                    )}
                    <div className="hero-content">
                        <h1 className="h1">
                            {ob.title}
                        </h1>
                        <h2 className="h2 pt-2">
                            {ob.subtitle}
                        </h2>
                        <div className="body-lg pt-2 pt-lg-5">
                            {ob.body_text}
                        </div>
                    </div>
                    <div className="hero-search">
                        <div className="form-group">
                            <div className="input-group">
                                <div className="input-group-text">
                                    <svg className="icon icon-xxs">
                                        <use href={`${sprite}${ob.inputSearch.is_search_sprite}`}></use>
                                    </svg>
                                </div>
                                <input type="text" className="form-control" name={ob.input_search_name} placeholder={ob.inputSearch.placeholder} value={searchValue} onChange={handleSearchChange} />
                                <button className="btn btn-primary" type="button" id="button-1" onClick={() => activeFunctions(ob.button_action)}>
                                    Avvia ricerca
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="hero-chip chip-list">
                        {ob.chips && ob.chips.map((item, index) => (
                            <span key={index} className="chip chip-lg" onClick={() => activeFunctions(item.button_action)}>
                                <svg className="icon" >
                                    <use href={`${sprite}${item.is_example_sprite}`}></use>
                                </svg>
                                <span>{item.chip}</span>
                            </span>
                        ))}
                    </div>
                    {ob.level === 1 &&
                        <div className="row">
                            {ob.cards.map((items, index) => (
                                <div key={index} className="col-lg-4 pt-6">
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="card-title">
                                                <div className="text-icon h3">
                                                    <div className="icon-rounded rounded-lg bg-primary10">
                                                        <svg className="icon icon-lg icon-dark">
                                                            <use href={`${sprite_fill}${items.is_example_sprite}`}></use>
                                                        </svg>
                                                    </div>
                                                    <span>
                                                        {items.title}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="card-text">
                                                <div className="pt-2 body-lg">
                                                    {items.text}
                                                </div>
                                            </div>
                                            <div className="btn-toolbar">
                                                <div className="btn-group-left">
                                                    <button type="button" className="btn btn-bare btn-sm" onClick={() => activeFunctions(items.button_action)}>
                                                        <span>
                                                            {items.buttonText}
                                                        </span>
                                                        <svg className="icon">
                                                            <use href={`${sprite}${items.is_arrow_sprite}`}></use>
                                                        </svg>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>))}
                        </div>}
                </div>
                {ob.level === 2 &&
                    <div className="container-image">
                        <img className="img-fluid" src={ob.image.src} alt={ob.image.alt} />
                    </div>}
            </div>
        </div >
    )
}

export default HeroBanner; 