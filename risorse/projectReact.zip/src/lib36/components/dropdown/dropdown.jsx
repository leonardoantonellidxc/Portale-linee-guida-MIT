import React, { useState, useEffect } from 'react';
import sprite from "../../static/imgs/icon/sprite.svg";

const Dropdown = ({ ob, activeFunctions}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredItems, setFilteredItems] = useState(ob.items);
  const [showAll, setShowAll] = useState(false);
  const [checkedItems, setCheckedItems] = useState({});
  const [showDropdown, setShowDropdown] = useState(ob.showDropdown);


  useEffect(() => {
    activeFunctions();
}, [activeFunctions]);

  useEffect(() => {
    if (ob.search) {
      const filtered = ob.items.filter(item => {
        if (ob.checkbox) {
          return item.label_checkbox && item.label_checkbox.toLowerCase().includes(searchTerm.toLowerCase());
        }
        return item.text && item.text.toLowerCase().includes(searchTerm.toLowerCase());
      });
      setFilteredItems(filtered);
    }
  }, [searchTerm, ob.items, ob.search, ob.checkbox]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleShowAll = () => {
    setShowAll(!showAll);
    setFilteredItems(showAll ?
      ob.items.filter(item => item.text && item.text.toLowerCase().includes(searchTerm.toLowerCase())) :
      ob.items
    );
  };

  const handleCheckboxChange = (e) => {
    setCheckedItems({
      ...checkedItems,
      [e.target.id]: e.target.checked
    });
  };

  const handleShowDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const renderDropdownItems = () => {
    let dropdownItems = [];
    const visibleItems = showAll ? filteredItems : filteredItems.slice(0, 6);

    visibleItems.forEach((item, index) => {
      if (!item.h_line) {
        if (!ob.checkbox) {
          dropdownItems.push(
            <li key={index}>
              <a
                className={`dropdown-item ${item.active ? 'active' : ''}`}
                href={item.href}
                onClick={() => activeFunctions(item.button_action)}
              >
                <div className="text-icon">
                  <svg className="icon icon-xs">
                    <use href={`${sprite}${ob.example_sprite}`}></use>
                  </svg>
                  <span>{item.text}</span>
                </div>
                <svg className="icon icon-xs">
                  <use href={`${sprite}${ob.example_sprite}`}></use>
                </svg>
              </a>
            </li>
          );
        } else {
          dropdownItems.push(
            <li key={index} className="dropdown-control">
                <div className="form-group">
                  <div className="form-checkbox">
                    <div className="checkbox">
                      <input
                        type="checkbox"
                        name={item.name}
                        id={`option-${item.id}`}
                        value={item.value}
                        checked={checkedItems[`option-${item.id}`] || false}
                        onChange={handleCheckboxChange}
                      />
                      <label htmlFor={`option-${item.id}`} onClick={() => activeFunctions(item.button_action)} >
                        {item.label_checkbox}
                      </label>
                    </div>
                  </div>
                </div>
            </li>
          );
        }
      }

      if ((index + 1) % ob.divider === 0 && index !== visibleItems.length - 1) {
        dropdownItems.push(<li key={`divider-${index}`}><div className="h-line"></div></li>);
      }
    });

    return dropdownItems;
  };

  return (
    <div className={`dropdown ${showDropdown ? 'show' : ''}`}>
      <button
        className="btn btn-primary dropdown-toggle"
        type="button"
        data-bs-toggle="dropdown"
        aria-expanded={ob.checkbox ? 'false' : null}
        data-bs-auto-close={ob.checkbox ? 'outside' : undefined}
        data-demon-bt={ob.checkbox ? 'dropdown' : undefined}
        onClick={handleShowDropdown}
      >
        {ob.button_text}
      </button>
      {!ob.search ? (
        <ul className={`dropdown-menu ${showDropdown ? 'show' : ''}`}>
          <li className="dropdown-title">{ob.dropdown_title}</li>
          {renderDropdownItems()}
        </ul>
      ) : (
        <div className={`dropdown-menu ${showDropdown ? 'show' : ''}`}>
          <div className="search-wrapper">
            <div className="form-group">
              <div className="input-group">
                <div className="input-group-text">
                  <svg className="icon icon-xxs">
                    <use href={`${sprite}${ob.search_sprite}`}></use>
                  </svg>
                </div>
                <input
                  type="text"
                  className="form-control"
                  name={ob.input_name}
                  placeholder={ob.input_placeholder}
                  value={searchTerm}
                  onChange={handleSearchChange}
                  aria-label={ob.input_aria_label}
                />
              </div>
            </div>
          </div>
          <ul className="scrollable">
            {renderDropdownItems()}
          </ul>
          {filteredItems.length > 3 && (
            <div className="dropdown-link">
              <a
                type="button"
                className="btn btn-bare btn-sm"
                href="#"
                onClick={handleShowAll}
              >
                {showAll ? 'Nascondi risultati' : 'Mostra tutti i risultati'}
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Dropdown;