import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { useEffect } from "react";

const TabMenu = ({ ob, activeFunctions }) => {

    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);

    return (

        <li className="nav-item">
            <a
                className={`nav-link ${ob.type || ''}`}
                aria-current="page"
                href={ob.link}
                data-bs-toggle="tab"
                data-bs-target={`#${ob.id}`}
                type="button"
                role="tab"
                aria-controls={ob.id}
                aria-selected="false"
                onClick= {() => activeFunctions(ob.button_action)}
            >
                <svg className="icon icon-sm" aria-hidden="true">
                    <use href={`${sprite_fill}${ob.sprite_example}`}></use>
                </svg>
                <span>{ob.text}</span>
                <svg className="icon icon-sm" aria-hidden="true">
                    <use href={`${sprite_fill}${ob.sprite_example}`}></use>
                </svg>
            </a>
        </li>

    );
}

export default TabMenu;