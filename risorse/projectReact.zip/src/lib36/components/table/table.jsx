import React, { useState, useEffect } from 'react';
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";

const Table = ({ ob, activeFunctions }) => {
    const [tableData, setTableData] = useState(ob);
    const [allChecked, setAllChecked] = useState(false);

    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);

    useEffect(() => {
        setTableData(ob);
    }, [ob]);

    if (!tableData || !tableData.t_head || !tableData.t_rows) {
        return <div>Dati della tabella non validi</div>;
    }

    const sortFunction = (e) => {
        e.preventDefault();
    };

    const checkFunction = (e) => {
        const isChecked = e.target.checked;
        setAllChecked(isChecked);

        const updatedTableData = {
            ...tableData,
            t_rows_states: tableData.t_rows_states.map(state => ({ ...state, active: isChecked }))
        };

        setTableData(updatedTableData);
    };

    const handleRowCheckboxChange = (rowIndex) => {
        const updatedTableData = {
            ...tableData,
            t_rows_states: tableData.t_rows_states.map((state, index) =>
                index === rowIndex ? { ...state, active: !state.active } : state
            )
        };

        setTableData(updatedTableData);

        const allChecked = updatedTableData.t_rows_states.every(state => state.active);
        setAllChecked(allChecked);
    };

    return (
        <div className={`list-table table-responsive table-${tableData.size || 'default'} table-even`}>
            <table>
                <thead>
                    <tr>
                        {tableData.t_head.map((item, index) => (
                            <th
                                key={index}
                                className={`${item.type === 'checkbox' ? 'colf-form colf-check' : ''}`}
                            >
                                {item.type !== 'checkbox' && item.type !== 'more' && (
                                    <a className="sortable" href="#" onClick={sortFunction}>
                                        <span>{item.span_title}</span>
                                        <div className="sort-icon">
                                            <svg className="icon icon-sm" aria-hidden="true">
                                                <use href={`${sprite}${item.sprite_sort}`}></use>
                                            </svg>
                                        </div>
                                    </a>
                                )}
                                {item.type === 'checkbox' && (
                                    <div className="form-group">
                                        <div className="form-checkbox">
                                            <div className="checkbox">
                                                <input
                                                    type="checkbox"
                                                    name={item.check_name}
                                                    id={item.check_name}
                                                    value={item.check_value}
                                                    aria-label={item.aria_label}
                                                    checked={allChecked}
                                                    onChange={checkFunction}
                                                />
                                                <label htmlFor={item.check_name}></label>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {tableData.t_rows.map((t_row, rowIndex) => (
                        <tr
                            key={rowIndex}
                            className={tableData.t_rows_states[rowIndex].active ? 'active' : ''}
                        >
                            {t_row.map((t_data, cellIndex) => (
                                <td
                                    key={cellIndex}
                                    className={[
                                        tableData.t_head[cellIndex].type === 'checkbox' ? 'colf-form colf-check' : '',
                                        tableData.t_head[cellIndex].type === 'date' ? 'cold-date' : '',
                                        tableData.t_head[cellIndex].type === 'button' ? 'colf-cmd' : '',
                                        tableData.t_head[cellIndex].type === 'more' ? 'colf-icon' : ''
                                    ].join(' ')}
                                    data-label={
                                        tableData.t_head[cellIndex].type === 'checkbox'
                                            ? 'Selezione'
                                            : tableData.t_head[cellIndex].type !== 'more'
                                                ? 'Title'
                                                : ''
                                    }
                                >
                                    {tableData.t_head[cellIndex].type === 'checkbox' && (
                                        <div className="form-group">
                                            <div className="form-checkbox">
                                                <div className="checkbox">
                                                    <input
                                                        type="checkbox"
                                                        name={t_data.check_name}
                                                        id={t_data.check_name}
                                                        value={t_data.check_value}
                                                        aria-label={t_data.aria_label}
                                                        checked={tableData.t_rows_states[rowIndex].active}
                                                        onChange={() => handleRowCheckboxChange(rowIndex)}
                                                    />
                                                    <label htmlFor={t_data.check_name}></label>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    {tableData.t_head[cellIndex].type === 'text' && (
                                        <div data-label="Title">{t_data.text}</div>
                                    )}
                                    {tableData.t_head[cellIndex].type === 'badge' && (
                                        <div>
                                            <span>{t_data.text}</span>
                                            <div className="badge bg-primary badge-sm">
                                                <span>{t_data.badge_text}</span>
                                            </div>
                                        </div>
                                    )}
                                    {tableData.t_head[cellIndex].type === 'date' && (
                                        <div>{t_data.date}</div>
                                    )}
                                    {tableData.t_head[cellIndex].type === 'button' && (
                                        <div>
                                            <button className="btn btn-primary btn-sm" onClick={() => activeFunctions(t_data.button_action)}>
                                                <svg className="icon icon-sm">
                                                    <use href={`${sprite_fill}${t_data.sprite_example}`}></use>
                                                </svg>
                                                <span>{t_data.button_text}</span>
                                                <svg className="icon icon-sm">
                                                    <use href={`${sprite_fill}${t_data.sprite_example}`}></use>
                                                </svg>
                                            </button>
                                        </div>
                                    )}
                                    {tableData.t_head[cellIndex].type === 'more' && (
                                        <div>
                                            <a className="link text-icon" href="#">
                                                <svg className="icon icon-sm" aria-hidden="true">
                                                    <use href={`${sprite}${tableData.sprite_more}`}></use>
                                                </svg>
                                            </a>
                                        </div>
                                    )}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Table;