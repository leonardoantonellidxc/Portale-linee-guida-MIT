import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { useEffect } from "react";

const Timeline = ({ ob, activeFunctions }) => {

  useEffect(() => {
    activeFunctions();
  }, [activeFunctions]);

  return (
    <div className="timeline">
      <div className={`timeline-item item-${ob.subtype}`}>
        <div className="tl-icon">
          <div className="icon-rounded rounded-lg">
            <svg className="icon icon-lg">
              <use href={`${sprite_fill}${ob.sprite_icon}`}></use>
            </svg>
          </div>
        </div>
        <div className="tl-content">
          <div className="tl-header">
            <div className="title-bar">
              <div className="date">{ob?.date}</div>
              <div className={`badge badge-lg badge-${ob?.type}`}>
                <span>{ob?.state}</span>
              </div>
            </div>
            <span className="h5">{ob?.title}</span>
          </div>
          <div className="tl-body">{ob?.body}</div>
          <div className="tl-footer">
            <button
              type="button"
              className={`btn btn-${ob?.type}`}
              data-focus-mouse="false"
              onClick= {() =>activeFunctions(ob.button_action)}
            >
              {ob?.firstButtonText}
            </button>
            <button type="button" className={`btn btn-outline-${ob?.type}`} onClick= {() =>activeFunctions(ob.button_action)}>
              {ob?.secondButtonText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;
