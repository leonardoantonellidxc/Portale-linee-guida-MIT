import React, { useState, useEffect } from "react";
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { Modal } from "bootstrap";

const Modali = ({ ob }) => {
  const [modalSize, setModalSize] = useState(null);
  const [inputValues, setInputValues] = useState({});
  const [textAreaValue, setTextAreaValue] = useState("");

  useEffect(() => {
    const initialInputValues = ob.labeled_inputs.reduce((acc, input) => {
      acc[input.name] = input.value || "";
      return acc;
    }, {});
    setInputValues(initialInputValues);
    setTextAreaValue(ob.text_area.value || "");
  }, [ob]);

  const onClick = (size) => {
    setModalSize(size);

    const myModal = new Modal(document.getElementById(`modal${ob.ID}`));
    myModal.show();
  };

  const closeModal = () => {
    const modalElement = document.getElementById(`modal${ob.ID}`);
    const modalInstance = Modal.getInstance(modalElement);
    modalInstance.hide();

    const backdrop = document.querySelector(".modal-backdrop");
    if (backdrop) {
      backdrop.parentNode.removeChild(backdrop);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setInputValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleTextAreaChange = (e) => {
    setTextAreaValue(e.target.value);
  };

  return (
    <>
      <div className="col-lg-3 pt-3">
        <button
          type="button"
          className="btn btn-primary"
          data-bs-toggle="modal"
          data-bs-target={`#modal${ob.ID}`}
          onClick={() => onClick(ob.size)}
          data-demon-size={`modal-${ob.size}`}
        >
          {ob.open_button_text}
        </button>
      </div>

      <div
        className={`modal modal-${ob.size}`}
        id={`modal${ob.ID}`}
        tabIndex="-1"
        role="dialog"
        aria-labelledby={`modal${ob.ID}Title`}
        aria-describedby="modal1Description"
      >
        <div className="modal-dialog" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h2 className="modal-title" id={`modal${ob.ID}Title`}>
                <div className="text-icon">
                  <svg className="icon icon-lg">
                    <use href={`${sprite_fill}${ob.example_sprite}`}></use>
                  </svg>
                  <span className={ob.size === "sm" ? "h4" : "h2"}>
                    {ob.heading}
                  </span>
                </div>
              </h2>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Chiudi finestra modale"
                onClick={closeModal}
              >
                <svg className="icon icon-md icon-primary">
                  <use
                    href={`${sprite_fill}${ob.close_circle_sprite}`}
                  ></use>
                </svg>
              </button>
            </div>
            <div className="modal-body">
              <div>
                <div className="h5">{ob.state_message_description}</div>
                <div className="pt-3">{ob.state_message}</div>

                <div className="row">
                  {ob.labeled_inputs.map((input, index) => (
                    <div
                      key={index}
                      className={`${
                        modalSize === "sm" ? "col-12" : "col-lg-6"
                      } pt-3`}
                    >
                      <div className="form-group has-feedback">
                        <label id={`field${input.id}Label`}>
                          {" "}
                          {input.label_text}{" "}
                        </label>
                        <div className="input-group">
                          <div className="input-group-text">
                            <svg className="icon icon-sm">
                              <use
                                href={`${sprite_fill}${input.example_sprite}`}
                              ></use>
                            </svg>
                          </div>
                          <div className="input-group-text divider"></div>
                          <input
                            type="text"
                            className="form-control"
                            name={input.name}
                            placeholder={input.placeholder}
                            value={inputValues[input.name] || ""}
                            onChange={handleInputChange}
                            aria-labelledby={`field${input.id}Label`}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="col-12 pt-3">
                    <div className="form-group has-feedback">
                      <label id={`field${ob.text_area.id}Label`}>
                        {ob.text_area.label_text}
                      </label>
                      <textarea
                        className="form-control"
                        name={ob.text_area.name}
                        placeholder={ob.text_area.placeholder}
                        value={textAreaValue}
                        onChange={handleTextAreaChange}
                        aria-labelledby={`field${ob.text_area.id}Label`}
                        rows={ob.text_area.rows}
                      ></textarea>
                    </div>
                  </div>
                </div>

                {ob.alert && (
                  <div className="pt-6">
                    <div className="alert alert-info alert-dismissible fade show">
                      <div className="alert-body">
                        <div className="alert-heading h5">{ob.alert.title}</div>
                        <div className="alert-text">{ob.alert.text}</div>
                      </div>
                      <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Chiudi"
                      >
                        <svg className="icon">
                          <use
                            href={`${sprite_fill}${ob.alert.close_circle_sprite}`}
                          ></use>
                        </svg>
                      </button>
                    </div>
                  </div>
                )}

                <div className="h5 pt-6">Altro subtitle</div>

                {ob.radio_elements && (
                  <div className="row">
                    {ob.radio_elements.map((radio, index) => (
                      <div
                        key={index}
                        className={`${
                          modalSize === "sm"
                            ? "col-12"
                            : modalSize !== "md"
                            ? "col-lg-4"
                            : "col-6"
                        } pt-3`}
                      >
                        <div className="form-group">
                          <label id={`field${radio.id}Label`}>
                            {" "}
                            Lorem ipsum{" "}
                          </label>
                          <div className="form-radio">
                            <div className="radio">
                              <input
                                type="radio"
                                name={radio.name}
                                id={`field${radio.id}-1`}
                                value="1"
                                aria-labelledby={`field${radio.id}Label`}
                              />
                              <label htmlFor={`field${radio.id}-1`}>
                                <div>
                                  <div className="text-b">
                                    {radio.label_radio}
                                  </div>
                                  <div className="body-sm">{radio.text}</div>
                                </div>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="modal-footer">
              <div className="btn-group-left">
                <button
                  type="button"
                  className="btn btn-bare"
                  data-bs-dismiss="modal"
                >
                  <svg className="icon icon-xs">
                    <use href={`${sprite_fill}${ob.info_sprite}`}></use>
                  </svg>
                  <span> Hai bisogno di aiuto? </span>
                </button>
              </div>
              <div className="btn-group-right">
                <button
                  type="button"
                  className="btn btn-danger"
                  data-bs-dismiss="modal"
                  onClick={closeModal}
                >
                  Azione 2
                </button>
                <button type="button" className="btn btn-primary" disabled>
                  Azione 1
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Modali;
