import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { useState } from "react";

const Stepper = ({ ob }) => {

    const [stepperWrapperShow, setStepperWrapperShow] = useState(false);

    const onMobileItemClick = () => {
        setStepperWrapperShow(true);
    }

    const onMobileHandleClick = () => {
        setStepperWrapperShow(false);
    }
    return (

        <>
            <div className={`modal-backdrop ${stepperWrapperShow ? 'show' : 'd-none'}`}></div>
            <div className={`stepper-wrapper ${stepperWrapperShow ? 'show' : ''}`}>
                <div className="mobile-handle" onClick={onMobileHandleClick}></div>
                <div className="mobile-title h6">
                    <div className="text-icon">
                        <svg className="icon icon-sm" aria-hidden="true">
                            <use href={`${sprite_fill}${ob.sprite_example}`}></use>
                        </svg>
                        <span>{ob.title}</span>
                    </div>
                    <svg className="icon icon-sm" aria-hidden="true">
                        <use href={`${sprite_fill}${ob.sprite_example}`}></use>
                    </svg>
                </div>
                <div className="mobile-progress">
                    <div className="progress-wrapper">
                        <div className="progress-label">
                            <span className="label-title"> {ob.mobile_progress.label_title} </span>
                            <span className="label-percent"> {ob.mobile_progress.label_percent} </span>
                        </div>
                        <div
                            className="progress"
                            role="progressbar"
                            aria-label="Lorem ipsum"
                            aria-valuenow="0"
                            aria-valuemin="0"
                            aria-valuemax="100"
                        >
                            <div
                                className="progress-bar"
                                style={{ width: ob.mobile_progress.label_percent }}
                            ></div>
                        </div>
                    </div>
                </div>

                <div className="stepper">
                    {ob.item.map((item, index) => (
                        <div key={index} className={`step-item ${item.type}`}>
                            <div className="step">
                                <div className="step-icon">
                                    {item.step_icon_span && (
                                        <span>{item.step_icon_span}</span>
                                    )}
                                    {item.step_sprite && (
                                        <svg className="icon" aria-hidden="true">
                                            <use href={`${sprite_fill}${item.step_sprite}`}></use>
                                        </svg>
                                    )}
                                </div>
                            </div>
                            <div className="step-info">
                                <div className="step-title">{item.step_info_title}</div>
                                <div className="step-text">{item.step_info_text}</div>
                            </div>
                        </div>
                    ))}
                </div>
                {ob.mobile_item && ob.mobile_item.map((item, index) => (
                    <a
                        key={index}
                        className={`step-item mobile-item ${item.type}`}
                        href="#"
                        onClick={onMobileItemClick}
                    >
                        <div className="step">
                            <div className="step-icon">
                                {item.step_icon_span && (
                                    <span>{item.step_icon_span}</span>
                                )}
                                {item.step_sprite && (
                                    <svg className="icon" aria-hidden="true">
                                        <use href={`${sprite_fill}${item.step_sprite}`}></use>
                                    </svg>
                                )}
                            </div>
                        </div>
                        <div className="step-info">
                            <div className="step-title">{item.step_info_title}</div>
                            <div className="step-text">{item.step_info_text}</div>
                        </div>
                        <svg className="icon icon-sm" aria-hidden="true">
                            <use href={`${sprite_fill}${item.step_maximize_sprite}`}></use>
                        </svg>
                    </a>
                ))}
            </div>
        </>
    );
};

export default Stepper;

