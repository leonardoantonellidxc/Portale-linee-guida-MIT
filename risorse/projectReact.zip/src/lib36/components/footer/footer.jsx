import sprite from "../../static/imgs/icon/sprite.svg";
import ministero from "../../static/imgs/icon/ministero.svg";
import logoexample from "../../static/imgs/TMP/footer/logo-example.svg";

let social_items =
    [
        { href: "#", classNameAnchor: "link link-light", classNameSvg: "icon icon-xs", idSvg: "#it-example" },
        { href: "#", classNameAnchor: "link link-light", classNameSvg: "icon icon-xs", idSvg: "#it-example" },
        { href: "#", classNameAnchor: "link link-light", classNameSvg: "icon icon-xs", idSvg: "#it-example" },
        { href: "#", classNameAnchor: "link link-light", classNameSvg: "icon icon-xs", idSvg: "#it-example" },
    ];

let LabelText = (
    <ul className="nav">
        <li className="nav-item"><a className="nav-link" href="#">Label text</a></li>
        <li className="nav-item"><a className="nav-link" href="#">Label text</a></li>
        <li className="nav-item"><a className="nav-link" href="#">Label text</a></li>
        <li className="nav-item"><a className="nav-link" href="#">Label text</a></li>
    </ul>
);

let logo_items =
    [
        { icon: "icon icon-xl", text1: "Label text", text2: "Label text", titletext: "progetto finanziato da" },
        { icon: "icon icon-xl", text1: "Label text", text2: "Label text", titletext: "progetto finanziato da" },
        { icon: "icon icon-xl", text1: "Label text", text2: "Label text", titletext: "progetto finanziato da" },
        { icon: "icon icon-xl", text1: "Label text", text2: "Label text", titletext: "progetto finanziato da" },
    ];

let link_items =
    [
        { classNameAnchor: "link link-light body-lg", text1: "Link1", href: "#" },
        { classNameAnchor: "link link-light body-lg", text1: "Link2", href: "#" },
        { classNameAnchor: "link link-light body-lg", text1: "link3", href: "#" },
        { classNameAnchor: "link link-light body-lg", text1: "Link4", href: "#" },
    ];

let AllRightsReserved =
    (
        <div className="text-icon">
            <svg className="icon icon-sm" aria-hidden="true">
                <use href="#"></use>
            </svg>
            <span>Tutti i diritti riservati</span>
        </div>
    );

let bottom_footer_links =
    [
        { href: "#", text: "Media Policy" },
        { href: "#", text: "Note legali" },
        { href: "#", text: "Privacy Policy" },
        { href: "#", text: "Mappa del sito" },
        { href: "#", text: "Dichiarazioni di accessibilità" },
    ];

const Footer = () => {
    return (
        <footer>
            <div className="footer-top">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3">
                            <div className="body-lg text-w6">Label text</div>
                            {LabelText}
                        </div>
                        <div className="col-lg-3 pt-4 pt-lg-0">
                            <div className="body-lg text-w6">Label text</div>
                            {LabelText}
                        </div>
                        <div className="col-lg-3 pt-4 pt-lg-0">
                            <div className="body-lg text-w6">Label text</div>
                            {LabelText}
                        </div>
                        <div className="col-lg-3 pt-4 pt-lg-0">
                            <div className="body-lg text-w6">Title description</div>
                            <div className="pt-3">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
                            </div>
                            <div className="pt-3">
                                {link_items.map((items, index) => (
                                    <a key={index} className={items.classNameAnchor} href={items.href}>{items.text1}</a>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div className="pt-6">
                        <div className="text-w6">Seguici sui social</div>
                        <div className="pt-4">
                            {social_items.map((item, index) => (
                                <a key={index} className={item.classNameAnchor} href={item.href}>
                                    <svg className={`${item.classNameSvg}`} aria-hidden="true">
                                        <use href={`${sprite}${item.idSvg}`}></use>
                                    </svg>
                                </a>))}
                        </div>
                    </div>
                </div>
            </div>
            <div className="footer-middle">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-4">
                            <div className="body-sm">progetto di</div>
                            <div className="navbar-brand pt-3">
                                <svg className="icon icon-xl" aria-hidden="true">
                                    <use href={`${ministero}#ministero`}></use>
                                </svg>
                                <div className="ps-3">
                                    <div className="body-lg text-w6">Ministero delle infrastrutture e dei trasporti</div>
                                    <div className="pt-2">Dipartimento per i trasporti terrestri</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-8 brand-list">
                            {logo_items.map((item, index) => (
                                <div key={index} className="brand-item">
                                    <div className="body-sm">{item.titletext}</div>
                                    <div className="navbar-brand pt-3">
                                        <img className={item.icon} src={logoexample} aria-hidden="true" alt="Logo" />
                                        <div className="ps-3">
                                            <div className="body-lg text-w6">{item.text1}</div>
                                            <div className="pt-2">{item.text2}</div>
                                        </div>
                                    </div>
                                </div>))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="footer-bottom">
                <div className="container">
                    <ul className="nav">
                        {bottom_footer_links.map((item, index) => (
                            <li key={index} className="nav-item"><a className="nav-link" href={item.href}>{item.text}</a></li>
                        ))}
                    </ul>
                    {AllRightsReserved}
                </div>
            </div>

            <div className="footer-credits">
                <div className="container">
                    <div className="navbar-brand">
                        <svg className="icon icon-lg" aria-hidden="true">
                            <use href={`${ministero}#ministero`}></use>
                        </svg>
                        <div className="body-lg text-w6 ps-3">
                            www.mit.gov.it  - Ministero delle infrastrutture e dei trasporti.
                        </div>
                    </div>
                    {AllRightsReserved}
                </div>
            </div>
        </footer>
    );
};

export default Footer;


