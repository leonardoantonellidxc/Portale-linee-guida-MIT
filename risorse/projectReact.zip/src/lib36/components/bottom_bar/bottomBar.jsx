import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import { useEffect } from "react";

const BottomBar = ({ ob, activeFunctions }) => {

    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);

    return (
        <div className={`bottom-bar ${ob.type_bottom_bar}`}>
            <div className="btn-toolbar">
                <div className="btn-group-left">
                    {ob?.left_group.map((button, j) => (
                        <button type="button" key={j} className={`btn btn-${button.type} ${button.size}`} onClick={() => activeFunctions(button.button_action)}>
                            <span>
                                {button.text}
                            </span>
                        </button>
                    ))}
                </div>
                <div className="btn-group-right">
                    {ob?.right_group.map((button, i) => (
                        button.subtype === "icon" ? (
                            <button type="button" key={i} className={`btn btn-${button.type} ${button.size}`} onClick={() => activeFunctions(button.button_action)}>
                                <span>
                                    {button.text}
                                </span>
                                <svg className="icon icon-sm">
                                    <use href={`${sprite_fill}${button.sprite}`}></use>
                                </svg>
                            </button>
                        ) : (
                            <button type="button" className={`btn btn-${button.type} ${button.size}`} onClick={() => activeFunctions(button.button_action)}>
                                <span>
                                    {button.text}
                                </span>
                            </button>
                        )
                    ))}
                </div>
            </div>
        </div>
    )
}

export default BottomBar
