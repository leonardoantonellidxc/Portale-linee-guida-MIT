import React from 'react';
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";
import sprite from "../../static/imgs/icon/sprite.svg";
import { useEffect } from 'react';

const Card = ({ ob, activeFunctions }) => {


    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);

    if (!ob) return null;

    return (
        !ob.wrapper ? (
            <div className={`card ${ob.hover ? 'hover' : ''} ${ob.card_img_back ? 'card-img-back' : ''}`}
                style={ob.card_img_back ? { backgroundImage: `url(${ob.card_img_back})` } : {}}>
                {!ob.card_img_back && (
                    <div className="card-img">
                        <img className="img-fluid" src={ob.card_img} alt="" />
                        <div className="card-date">
                            <div className="badge badge-primary bg-white badge-sm">
                                <svg className="icon">
                                    <use href={`${sprite_fill}${ob.clock_sprite}`}></use>
                                </svg>
                                <span>{ob.clock_text}</span>
                            </div>
                            <span>{ob.img_text}</span>
                        </div>
                    </div>
                )}
                {!ob.card_img_back && (
                    <div className="card-body">
                        <div className="card-bar">
                            <div className="bar-group">
                                <div className="badge badge-sm badge-primary">
                                    <span>{ob.label_text_1}</span>
                                </div>
                                <div className="badge badge-sm badge-primary">
                                    <span>{ob.label_text_2}</span>
                                </div>
                                <div className="badge badge-sm badge-primary">
                                    <span>{ob.label_text_3}</span>
                                </div>
                            </div>
                        </div>
                        <div className="card-title">
                            <div className="text-icon h3">
                                <div className="icon-rounded rounded-xl bg-primary10">
                                    <svg className="icon icon-lg icon-primary">
                                        <use href={`${sprite_fill}${ob.sprite}`}></use>
                                    </svg>
                                </div>
                                <svg className={`icon icon-md ${ob.card_img_back ? 'icon-dark' : ''}`}>
                                    <use href={`${sprite_fill}${ob.sprite}`}></use>
                                </svg>
                                <span>{ob.title}</span>
                            </div>
                        </div>
                        <div className="card-text">
                            <div className="h5">{ob.sub_title}</div>
                            <div className="pt-2 body-lg">
                                {ob.card_text}
                            </div>
                            <div className="alert alert-warning mb-0 mt-4">
                                <div className="alert-body">
                                    <div className="alert-heading h5">{ob.title_alert_warning}</div>
                                </div>
                            </div>
                        </div>
                        <div className="btn-toolbar">
                            <div className="btn-group-left">
                                <button type="button" className="btn btn-primary btn-sm" onClick={() => activeFunctions(ob.button_action)}>
                                    <span>{ob.button_text1}</span>
                                    <svg className="icon">
                                        <use href={`${sprite_fill}${ob.sprite}`}></use>
                                    </svg>
                                </button>
                                <button type="button" className="btn btn-bare btn-sm" onClick={() => activeFunctions(ob.button_action)}>
                                    <span>{ob.button_text2}</span>
                                    <svg className="icon">
                                        <use href={`${sprite}${ob.arrow_sprite}`}></use>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                )}
                {ob.card_img_back && (
                    <div className="back-hover">
                        <div className="card-img">
                            <div className="card-bar">
                                <div className="bar-group">
                                    <div className="badge badge-primary bg-white">
                                        <span>{ob.span_text_1}</span>
                                    </div>
                                    <div className="badge badge-primary bg-white">
                                        <span>{ob.span_text_2}</span>
                                    </div>
                                    <div className="badge badge-primary bg-white">
                                        <span>{ob.span_text_3}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card-body">
                            <div className="card-title">
                                <div className="text-icon h3">
                                    <svg className="icon icon-md icon-dark">
                                        <use href={`${sprite_fill}${ob.sprite}`}></use>
                                    </svg>
                                    <span>{ob.title}</span>
                                </div>
                            </div>
                            <div className="card-text">
                                <div className="body-lg">
                                    {ob.card_text}
                                </div>
                            </div>
                            <div className="btn-toolbar">
                                <div className="btn-group-left">
                                    <button type="button" className="btn btn-primary btn-sm" onClick={() => activeFunctions(ob.button_action)}>
                                        <span>{ob.button_text1}</span>
                                        <svg className="icon">
                                            <use href={`${sprite_fill}${ob.sprite}`}></use>
                                        </svg>
                                    </button>
                                    <button type="button" className="btn btn-bare btn-sm" onClick={() => activeFunctions(ob.button_action)}>
                                        <span>{ob.button_text2}</span>
                                        <svg className="icon">
                                            <use href={`${sprite}${ob.arrow_sprite}`}></use>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        ) : (
            <div className="card-wrapper">
                <div className={`card ${ob.border}`}>
                    <div className="card-body">
                        <div className="card-bar">
                            <div className="bar-group">
                                <div className={`badge badge-sm ${ob.badge_type}`}>
                                    <span>{ob.label_text}</span>
                                </div>
                            </div>
                            <div className="bar-group">
                                <svg className={`icon icon-sm icon-${ob.type}`}>
                                    <use href={`${sprite_fill}${ob.sprite}`}></use>
                                </svg>
                            </div>
                        </div>
                        <div className="card-title">
                            <div className="text-icon h2 text-dark">
                                <span>{ob.title}</span>
                            </div>
                        </div>
                        <div className="card-text">
                            <div className="body-lg">{ob.card_text}</div>
                        </div>
                        <div className="btn-toolbar">
                            <div className="btn-group-wide">
                                <button
                                    type="button"
                                    className={`btn btn-outline-${ob.type !== 'disabled' ? ob.type : 'success'}`}
                                    disabled={ob.type === 'disabled'}
                                    onClick={() => activeFunctions(ob.button_action)}
                                >
                                    <span>{ob.button_text1}</span>
                                    <svg className="icon">
                                        <use href={`${sprite_fill}${ob.sprite}`}></use>
                                    </svg>
                                </button>
                                <button
                                    type="button"
                                    className={`btn btn-${ob.type !== 'disabled' ? ob.type : 'success'}`}
                                    disabled={ob.type === 'disabled'}
                                    onClick={() => activeFunctions(ob.button_action)}
                                >
                                    <span>{ob.button_text2}</span>
                                    <svg className="icon">
                                        <use href={`${sprite_fill}${ob.sprite}`}></use>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    );
};

export default Card;