import React, { useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import sprite_fill from "../../static/imgs/icon/sprite_fill.svg";

const Accordions = ({ object_data, activeFunctions }) => {
    useEffect(() => {
        activeFunctions();
    }, [activeFunctions]);

    const { t } = useTranslation()

    return (
        <div className="container pb-8" id="demonView2-200-1">
            <div className="pt-6">
                <div className="accordion-header" id="heading1c">
                    <div className="accordion" id="collapseExample">
                        {object_data?.map((item, index) => (
                            <div className="accordion-item item-ticon" key={`accordion-${index}`}>
                                <div className="accordion-item">
                                    <div className="accordion-header" id={`heading${index}c`}>
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={`#collapse${index}c`} aria-expanded="false" aria-controls={`collapse${index}c`}>
                                            <div className="text-icon">
                                                <svg className="icon icon-sm">
                                                    <use href={`${sprite_fill}${item.sprite}`}></use>
                                                </svg>
                                                <span>
                                                    {item.title}
                                                </span>
                                            </div>
                                        </button>
                                    </div>
                                    <div id={`collapse${index}c`} className="accordion-collapse collapse" role="region" aria-labelledby={`heading${index}c`}>
                                        <div className="accordion-body">
                                            <div>
                                                {item.text}
                                            </div>
                                            <div className="btn-toolbar">
                                                {item?.buttons?.map((item_buttons, buttonIndex) => (
                                                    <button 
                                                        type="button" 
                                                        className={item_buttons?.bg_white ? "btn btn-outline-primary" : "btn btn-primary"}
                                                        key={`button-${index}-${buttonIndex}`}
                                                        onClick={() => activeFunctions(item_buttons?.button_action)}
                                                    >
                                                        {item_buttons?.button_text}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Accordions