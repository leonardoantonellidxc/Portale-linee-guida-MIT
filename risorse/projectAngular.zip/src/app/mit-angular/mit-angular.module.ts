import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class MitAngularModule { }

import { NgModule } from '@angular/core';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { StepperComponent } from './components/stepper/stepper.component';
import { FormsModule } from '@angular/forms';

import { TimelineComponent } from './components/timeline/timeline.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { BottomBarComponent } from './components/bottom-bar/bottom-bar.component';
import { ModaliComponent } from './components/modali/modali.component';
import { CardComponent } from './components/card/card.component';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { TabComponent } from './components/tab/tab.component';
import { TableComponent } from './components/table/table.component';
import { DatePickerComponent } from './components/form/date-picker/date-picker.component';
import { InputComponent } from './components/form/input/input.component';
import { InputSearchComponent } from './components/form/input-search/input-search.component';
import { SelectComponent } from './components/form/select/select.component';
import { SliderComponent } from './components/form/slider/slider.component';
import { UploaderComponent } from './components/form/uploader/uploader.component';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeroBannerComponent } from './components/hero-banner/hero-banner.component';
import { SidebarNavigationComponent } from './components/sidebar-navigation/sidebar-navigation.component';

@NgModule({
  declarations: [
    TimelineComponent,
    AccordionComponent,
    BottomBarComponent,
    ModaliComponent,
    CardComponent,
    DropdownComponent,
    PaginationComponent,
    StepperComponent,
    TabComponent,
    TableComponent,
    DatePickerComponent,
    InputComponent,
    InputSearchComponent,
    SelectComponent,
    SliderComponent,
    UploaderComponent,
    HeaderComponent,
    FooterComponent,
    HeroBannerComponent,
    SidebarNavigationComponent,
  ],
  imports: [
    BrowserModule,
    NgbModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


