import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  @Input('ob') ob: any = {};
  @Input() activeFunctions: (buttonCase: string) => void = () => {};
}
