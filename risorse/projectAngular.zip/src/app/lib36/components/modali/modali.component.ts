import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-modali',
  templateUrl: './modali.component.html'
})
export class ModaliComponent implements OnInit {
  @Input() ob: any;
  modalSize: string | null = null;
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg'
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';

  ngOnInit(): void { }

  onClick(size: string): void {
    this.modalSize = size;
  }
}

