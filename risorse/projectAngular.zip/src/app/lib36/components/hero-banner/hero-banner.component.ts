import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-hero-banner',
  templateUrl: './hero-banner.component.html',
  styleUrls: ['./hero-banner.component.scss']
})
export class HeroBannerComponent {
  @Input() ob: any;
  @Input() activeFunctions: (buttonCase: string) => void = () => {};
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg'
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
}
