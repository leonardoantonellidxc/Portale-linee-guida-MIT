import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  @Input('object_data') object_data: any = {};
  @Input('activeFunctions') activeFunctions: any = {};
}
