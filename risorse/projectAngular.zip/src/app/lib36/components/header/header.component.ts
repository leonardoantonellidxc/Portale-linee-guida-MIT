import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  @Input('ob') ob: any = {};

  logged_in = false;

  addClassToBody() {
    document.body.classList.add('menu-show');
  }

  removeClassToBody() {
    document.body.classList.remove('menu-show');
  }

  login() {
    this.logged_in = true;
  }

  logout() {
    this.logged_in = false;
  }

}
