import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent {
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  @Input('ob') ob: any = {};
  @Input() activeFunctions: (buttonCase: string) => void = () => {};
}
