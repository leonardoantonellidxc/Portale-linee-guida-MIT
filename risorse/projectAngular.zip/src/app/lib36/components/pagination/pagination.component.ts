import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent {

  sprite = 'app/lib36/static/imgs/icon/sprite.svg';

  @Input('ob') ob: any = {};

  @Input('setActive') setActive: any;

  get pages() {
    return Array(this.ob.lastPage).fill(0).map((x, i) => i + 1);
  }

  goToPreviousPage(event: Event) {
    event.preventDefault();
    if (this.ob.active !== 1) {
      this.setActive(this.ob.active - 1);
    }
  }

  goToNextPage(event: Event) {
    event.preventDefault()
    if (this.ob.active != this.ob.lastPage) {
      this.setActive(this.ob.active + 1)
    }
  }

  changePage(n: number, event: Event) {
    event.preventDefault();
    this.setActive(n);
  }

  onSelectChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.setActive(parseInt(target.value, 10));
  }


  preventDefault(event: Event) {
    event.preventDefault();
  }
}
