import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss']
})
export class StepperComponent {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';

  @Input('ob') ob: any = {};

  stepper_wrapper_show = false;
  onMobileItemClick() {
    this.stepper_wrapper_show = true;
  }
  onMobileHandleClick() {
    this.stepper_wrapper_show = false;
  }
}
