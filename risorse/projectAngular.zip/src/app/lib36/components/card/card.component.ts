import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent {
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  @Input('ob') ob: any = {};
  @Input() activeFunctions: (buttonCase: string) => void = () => {};
}
