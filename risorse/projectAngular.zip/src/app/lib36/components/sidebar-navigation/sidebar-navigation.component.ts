import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-sidebar-navigation',
  templateUrl: './sidebar-navigation.component.html',
  styleUrls: ['./sidebar-navigation.component.scss']
})
export class SidebarNavigationComponent {
  @Input() ob: any;
  @Input() activeFunctions: (buttonCase: string) => void = () => { };
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg'
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';

  activeItem: number | null = null;
  activeSubItem: string | null = null;

  handleActive(index: number) {
    this.activeItem = this.activeItem === index ? null : index;
    this.activeSubItem = null;
  }

  handleSubItemActive(i: number, j: number) {
    this.activeSubItem = this.activeSubItem === `${i}-${j}` ? null : `${i}-${j}`;
  }

  combinedFunction(buttonAction: string, i: number, j?: number) {
    if (this.activeFunctions) {
      this.activeFunctions(buttonAction);
    }

    if (j !== undefined) {
      this.handleSubItemActive(i, j);
    } else {
      this.handleActive(i);
    }
  }

}



