import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.scss']
})
export class TabComponent {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  @Input('ob') ob: any = {};
  @Input() activeFunctions: (buttonCase: string) => void = () => { };
}
