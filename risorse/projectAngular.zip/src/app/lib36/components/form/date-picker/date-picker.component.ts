import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss']
})
export class DatePickerComponent implements OnInit {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  @Input('ob') ob: any = {};

  hover = false
  dropdown_show = false;
  selectedYear: number;
  months: string[] = [];
  selectedMonth;
  daysInMonth: ({ day: number; prop: string; } | { day: number; prop?: undefined; } | null)[] = [];
  weekDays: string[] = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];
  selectedDay: number | undefined;
  firstYear: number = 0;
  lastYear: number = 0;
  constructor() {
    this.months = this.getMonths();
    const today = new Date();
    this.selectedYear = today.getFullYear();
    this.selectedDay = new Date().getDate();
    this.selectedMonth = this.months[new Date().getMonth()];
    this.daysInMonth = this.getDaysInMonth(this.selectedYear, this.months.indexOf(this.selectedMonth));
  }

  ngOnInit() {
    this.ob.years.sort((a: number, b: number) => a - b);
    this.firstYear = this.ob.years[0];
    this.lastYear = this.ob.years[this.ob.years.length - 1];
  }


  onMouseOver() {
    this.hover = true;
  }

  onMouseOut() {
    this.hover = false;
  }

  toggleDropdown() {
    this.dropdown_show = !this.dropdown_show;
  }

  onSelectYear(year: number) {
    this.selectedYear = year;
    this.selectedDay = undefined;
    if (this.selectedMonth !== null)
      this.daysInMonth = this.getDaysInMonth(this.selectedYear, this.months.indexOf(this.selectedMonth));
  }

  getMonths(): string[] {
    return [
      'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno',
      'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'
    ];
  }

  selectMonth(month: string) {
    this.selectedMonth = month;
    this.selectedDay = undefined;
    this.daysInMonth = this.getDaysInMonth(this.selectedYear, this.months.indexOf(month));
  }

  getDaysInMonth(year: number, monthIndex: number) {
    const days = [];
    const firstDayOfMonth = new Date(year, monthIndex, 1).getDay();
    const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
    const prevMonthDays = new Date(year, monthIndex, 0).getDate();


    const offset = (firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1);

    for (let i = offset; i > 0; i--) {
      days.push({ day: prevMonthDays - i + 1, prop: 'empty' });
    }

    for (let day = 1; day <= daysInMonth; day++) {
      days.push({ day: day });
    }

    const totalDays = days.length;
    const totalCells = Math.ceil(totalDays / 7) * 7;
    for (let i = totalDays; i < totalCells; i++) {
      days.push({ day: i - totalDays + 1, prop: 'empty' });
    }
    return days;
  }

  onSelectDay(day: number | undefined, prop: string | undefined
  ) {
    if (prop != 'empty') {
      let month: number = this.months.indexOf(this.selectedMonth);
      let pre_day = day != undefined && day < 10 ? '0' : '';
      let pre_month = (month + 1) < 10 ? '0' : '';
      this.ob.value = pre_day + day + '/' + pre_month + (month + 1) + '/' + this.selectedYear;
      this.selectedDay = day;
      this.dropdown_show = false;
      this.validateInput();
    }
  }

  validateInput() {
    if (!this.ob.toValidate) {
      return;
    }
    const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const match = this.ob.value.match(datePattern);
    if (!match) {
      this.ob.type = 'is-invalid';
    } else {
      this.ob.type = 'is-valid';
    }
    const day = parseInt(match[1], 10);
    const month = parseInt(match[2], 10) - 1;
    const year = parseInt(match[3], 10);

    const date = new Date(year, month, day);

    if (date.getDate() !== day || date.getMonth() !== month || date.getFullYear() !== year) {
      this.ob.type = 'is-invalid';
    }

    if (year < this.firstYear || year > this.lastYear) {
      this.ob.type = 'is-invalid';
    }
  }
}
