import { Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-input-search',
  templateUrl: './input-search.component.html',
  styleUrls: ['./input-search.component.scss']
})
export class InputSearchComponent implements OnInit {
  @Input() ob: any;
  @Input() activeFunctions: (buttonCase: string) => void = () => {};
  @ViewChild('dropdownRef', { static: true }) dropdownRef!: ElementRef;
  @ViewChild('inputRef', { static: true }) inputRef!: ElementRef;

  isHovering = false;
  isShowing = false;
  showAll = false;
  searchTerm = '';
  visibleFields: any[] = [];
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';

  constructor() { }

  ngOnInit() {
    console.log('ob:', this.ob);
    this.isHovering = this.ob.is_hovering;
    this.isShowing = this.ob.is_showing;
    this.updateVisibleFields();
    console.log('visibleFields:', this.visibleFields);
  }

  @HostListener('document:mousedown', ['$event'])
  onClickOutside(event: Event) {
    if (!this.dropdownRef.nativeElement.contains(event.target)) {
      this.closeDropdown();
    }
  }

  openDropdown() {
    console.log('openDropdown called');
    this.isShowing = true;
  }

  closeDropdown() {
    console.log('closeDropdown called');
    setTimeout(() => {
      this.isShowing = false;
      this.showAll = false;
    }, 200);
  }

  handleMouseOver() {
    this.isHovering = true;
  }

  handleMouseOut() {
    this.isHovering = false;
  }

  handleShowAll(event: Event) {
    event.preventDefault();
    this.showAll = true;
    this.updateVisibleFields();
  }

  updateVisibleFields() {
    console.log('updateVisibleFields called');
    const filteredFields = this.ob.field.filter((field: any) =>
      field.name.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.visibleFields = this.showAll ? filteredFields : filteredFields.slice(0, 6);
    console.log('visibleFields updated:', this.visibleFields);
  }

  onSearchChange() {
    this.updateVisibleFields();
  }

  get showMoreResultsButton(): boolean {
    return !this.showAll && this.ob.field.length > 6 && this.visibleFields.length < this.ob.field.length;
  }
}