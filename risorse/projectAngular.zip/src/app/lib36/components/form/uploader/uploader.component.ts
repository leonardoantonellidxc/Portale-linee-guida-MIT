import { Component, Input, OnInit, OnChanges, SimpleChanges, ViewChild, ElementRef } from '@angular/core';

interface FileUpload {
  file: File;
  state: 'idle' | 'loading' | 'success' | 'error';
  progress: number;
  errorMessage: string;
  isNameVisible: boolean;
}

@Component({
  selector: 'app-uploader',
  templateUrl: './uploader.component.html',
  styleUrls: ['./uploader.component.scss']
})
export class UploaderComponent implements OnInit, OnChanges {
  @Input() ob: any;
  @ViewChild('fileInput') fileInput!: ElementRef;

  standardFiles: FileUpload[] = [];
  file: File | null = null;
  isFileNameVisible = false;
  fileState: 'idle' | 'loading' | 'success' | 'error' = 'idle';
  progress = 0;
  errorMessage = '';
  inputLabel = '';
  dragState = '';
  uploadProgress = 0;

  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  dragDropIcon = 'app/lib36/static/imgs/icon/upload/drag-drop-icon.svg';
  dragDropIconDisabled = 'app/lib36/static/imgs/icon/upload/drag-drop-icon-disabled.svg';
  dragDropIconOver = 'app/lib36/static/imgs/icon/upload/drag-drop-icon-over.svg';
  dragDropIconActive = 'app/lib36/static/imgs/icon/upload/drag-drop-icon-active.svg';
  dragDropIconSuccess = 'app/lib36/static/imgs/icon/upload/drag-drop-icon-success.svg';
  dragDropIconFailed = 'app/lib36/static/imgs/icon/upload/drag-drop-icon-failed.svg';

  ngOnInit() {
    this.inputLabel = this.ob.input_label;
    if (this.ob.initialFile) {
      this.file = this.ob.initialFile;
      this.fileState = 'success';
    }
    if (this.ob.is_drag_drop) {
      this.dragState = this.ob.type || '';
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['ob'] && changes['ob'].currentValue) {
      this.inputLabel = changes['ob'].currentValue.input_label;
    }
  }

  handleStandardFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      Array.from(input.files).forEach(file => {
        this.addStandardFile(file);
      });
    }
  }

  addStandardFile(file: File) {
    const newFile: FileUpload = {
      file,
      state: 'loading',
      progress: 0,
      errorMessage: '',
      isNameVisible: false
    };
    this.standardFiles.push(newFile);
    this.simulateStandardUpload(this.standardFiles.length - 1);
  }

  simulateStandardUpload(index: number) {
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      this.standardFiles[index].progress = progress;
      if (progress >= 100) {
        clearInterval(interval);
        if (Math.random() < 0.5) {
          this.standardFiles[index].state = 'error';
          this.standardFiles[index].errorMessage = 'Si è verificato un errore durante il caricamento.';
        } else {
          this.standardFiles[index].state = 'success';
        }
      }
    }, 500);
  }

  handleShowFile(index: number) {
    this.standardFiles[index].isNameVisible = !this.standardFiles[index].isNameVisible;
  }

  handleFileDelete(index: number) {
    this.standardFiles.splice(index, 1);
  }

  retryUpload(index: number) {
    this.standardFiles[index].state = 'loading';
    this.standardFiles[index].progress = 0;
    this.standardFiles[index].errorMessage = '';
    this.simulateStandardUpload(index);
  }

  maskFileName(): string {
    return '**********';
  }

  hasLoadingFiles(): boolean {
    return this.standardFiles.some(file => file.state === 'loading');
  }

  handleFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.file = input.files[0];
      this.isFileNameVisible = false;
      this.fileState = 'loading';
      this.simulateUpload();
    }
  }

  simulateUpload() {
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      this.progress = progress;
      this.uploadProgress = progress;
      if (progress >= 100) {
        clearInterval(interval);
        if (Math.random() < 0.5) {
          this.setDragState(this.ob.type_error);
          this.fileState = 'error';
        } else {
          this.setDragState(this.ob.type_success);
          this.fileState = 'success';
        }
      }
    }, 500);
  }

  handleDragEnter(e: DragEvent): void {
    e.preventDefault();
    if (this.dragState !== this.ob.type_disabled) {
      this.setDragState(this.ob.type_over);
    }
  }

  handleDragLeave(e: DragEvent): void {
    e.preventDefault();
    if (this.dragState !== this.ob.type_disabled) {
      this.setDragState('');
    }
  }

  handleDragOver(e: DragEvent): void {
    e.preventDefault();
    if (this.dragState !== this.ob.type_disabled && this.dragState !== this.ob.type_over) {
      this.setDragState(this.ob.type_over);
    }
  }

  handleDrop(e: DragEvent): void {
    e.preventDefault();
    if (this.dragState !== this.ob.type_disabled) {
      const droppedFile = e.dataTransfer?.files[0];
      if (droppedFile) {
        this.handleFileSelection(droppedFile);
      }
    }
  }

  handleFileSelection(selectedFile: File): void {
    if (this.dragState !== this.ob.type_disabled) {
      this.file = selectedFile;
      this.setDragState(this.ob.type_loading);
      this.simulateUpload();
    }
  }

  handleFileInputChange(e: Event): void {
    if (this.dragState !== this.ob.type_disabled) {
      const target = e.target as HTMLInputElement;
      const selectedFile = target.files?.[0];
      if (selectedFile) {
        this.handleFileSelection(selectedFile);
      }
    }
  }

  isHover(): void {
    if (this.dragState !== this.ob.type_disabled && this.dragState !== this.ob.type_loading &&
      this.dragState !== this.ob.type_success && this.dragState !== this.ob.type_error) {
      this.setDragState(this.ob.type_over);
    }
  }

  resetHover(): void {
    if (this.dragState === this.ob.type_over && this.dragState !== this.ob.type_disabled) {
      this.setDragState(this.ob.type);
    }
  }

  getIconAndAlt(): { icon: string; alt: string; className: string } {
    switch (this.dragState) {
      case this.ob.type_disabled:
        return { icon: this.dragDropIconDisabled, alt: 'Upload disabled', className: 'disabled' };
      case this.ob.type_over:
        return { icon: this.dragDropIconOver, alt: 'File over dropzone', className: 'over' };
      case this.ob.type_active:
        return { icon: this.dragDropIconActive, alt: 'Dropzone active', className: 'active' };
      case this.ob.type_loading:
        return { icon: '', alt: 'Loading', className: 'loading' };
      case this.ob.type_success:
        return { icon: this.dragDropIconSuccess, alt: 'Upload successful', className: 'success' };
      case this.ob.type_error:
        return { icon: this.dragDropIconFailed, alt: 'Upload failed', className: 'error' };
      default:
        return { icon: this.dragDropIcon, alt: 'Default upload state', className: 'default' };
    }
  }

  setDragState(state: string): void {
    this.dragState = state;
    if (state === this.ob.type_loading) {
      this.simulateUpload();
    }
  }
}