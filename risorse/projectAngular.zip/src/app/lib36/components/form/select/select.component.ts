import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';

  @Input('ob') ob: any = {};

  isHovering = false;

  onMouseOver() {
    this.isHovering = true;
  }

  onMouseOut() {
    this.isHovering = false;
  }


}
