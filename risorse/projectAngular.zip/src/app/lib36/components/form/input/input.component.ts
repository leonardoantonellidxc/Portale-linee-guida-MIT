import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent {
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  @Input('ob') ob: any = {};
}
