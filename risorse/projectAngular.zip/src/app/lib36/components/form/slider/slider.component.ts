import { Component, ElementRef, HostListener, Input, ViewChild, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {
  @ViewChild('progressWrapper') progressWrapper!: ElementRef<HTMLElement>;
  @ViewChild('progressBar') progressBar!: ElementRef<HTMLElement>;
  
  @Input() ob: any = {};
  
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';
  sprite_fill = 'app/lib36/static/imgs/icon/sprite_fill.svg';
  
  minValue: number = 0;
  maxValue: number = 100;
  validationState: string = '';

  ngOnInit() {
    this.minValue = this.ob.range_field === 2 ? this.ob.min : this.ob.min;
    this.maxValue = this.ob.range_field === 2 ? this.ob.max : this.ob.initial || this.ob.max;
    this.validate();
    this.updateProgress();
  }

  roundValue(value: number): number {
    const range = this.ob.max - this.ob.min;
    let decimals = 0;
    if (range < 1) decimals = 2;
    else if (range < 10) decimals = 1;
    return Number(value.toFixed(decimals));
  }

  handleMinChange(value: string | number) {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    if (!isNaN(numValue)) {
      const newValue = this.roundValue(Math.max(this.ob.min, Math.min(numValue, this.maxValue - 1)));
      if (newValue !== this.minValue) {
        this.minValue = newValue;
        this.validate();
        this.updateProgress();
      }
    }
  }

  handleMaxChange(value: string | number) {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    if (!isNaN(numValue)) {
      const newValue = this.roundValue(Math.max(this.minValue + 1, Math.min(numValue, this.ob.max)));
      if (newValue !== this.maxValue) {
        this.maxValue = newValue;
        this.validate();
        this.updateProgress();
      }
    }
  }

  calculateLeftPosition(value: number): number {
    return ((value - this.ob.min) / (this.ob.max - this.ob.min)) * 100;
  }

  updateProgress() {
    if (this.progressBar) {
      const width = this.calculateLeftPosition(this.maxValue) - this.calculateLeftPosition(this.minValue);
      const marginLeft = this.calculateLeftPosition(this.minValue);
      this.progressBar.nativeElement.style.width = `${width}%`;
      this.progressBar.nativeElement.style.marginLeft = `${marginLeft}%`;
    }
  }

  @HostListener('mousedown', ['$event'])
  onMouseDown(event: MouseEvent, pin: 'from' | 'to') {
    if (this.ob.disabled) return;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const rangeElement = this.progressWrapper.nativeElement;
      const progressWrapperRect = rangeElement.getBoundingClientRect();
      const mouseX = moveEvent.clientX - progressWrapperRect.left;
      const progressWrapperWidth = progressWrapperRect.width;
      let percent = (mouseX / progressWrapperWidth) * 100;
      percent = Math.max(0, Math.min(percent, 100));
      const value = this.roundValue(this.ob.min + (percent / 100) * (this.ob.max - this.ob.min));

      if (pin === 'from') {
        this.handleMinChange(value);
      } else {
        this.handleMaxChange(value);
      }
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }

  handleInput(event: Event, type: 'min' | 'max') {
    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
  
    if (!/^-?\d*\.?\d*$/.test(value)) {
      inputElement.value = type === 'min' ? this.minValue.toString() : this.maxValue.toString();
      return;
    }

    if (type === 'min') {
      this.handleMinChange(value);
    } else {
      this.handleMaxChange(value);
    }
  }

  validate() {
    if (this.ob.toValidate) {
      if (this.minValue < this.ob.minValid || this.maxValue > this.ob.maxValid) {
        this.validationState = "is-invalid";
      } else {
        this.validationState = "is-valid";
      }
    } else {
      this.validationState = this.ob.valid ? "is-valid" : (this.ob.invalid ? "is-invalid" : "");
    }
  }

  onProgressClick(event: MouseEvent) {
    if (this.ob.disabled) return;

    const rangeElement = this.progressWrapper.nativeElement;
    const progressWrapperRect = rangeElement.getBoundingClientRect();
    const mouseX = event.clientX - progressWrapperRect.left;
    const progressWrapperWidth = progressWrapperRect.width;
    let percent = (mouseX / progressWrapperWidth) * 100;
    percent = Math.max(0, Math.min(percent, 100));
    const value = this.roundValue(this.ob.min + (percent / 100) * (this.ob.max - this.ob.min));

    if (this.ob.range_field === 1) {
      this.handleMaxChange(value);
    } else {
      const distanceToMin = Math.abs(value - this.minValue);
      const distanceToMax = Math.abs(value - this.maxValue);
      if (distanceToMin < distanceToMax) {
        this.handleMinChange(value);
      } else {
        this.handleMaxChange(value);
      }
    }
  }
}