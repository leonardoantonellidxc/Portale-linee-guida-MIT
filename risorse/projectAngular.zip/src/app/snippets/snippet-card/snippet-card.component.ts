import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-card',
  templateUrl: './snippet-card.component.html',
  styleUrls: ['./snippet-card.component.scss']
})
export class SnippetCardComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  card = {
    is_hover: false,
    card_img: 'app/lib36/static/imgs/TMP/card/example-01.jpg',
    clock_text: 'Lorem ipsum',
    img_text: '10 Dicembre 2023',
    labels: ['Label Text', 'Label Text', 'Label Text'],
    title: 'Titolo della card',
    sub_title: 'Sottotitolo della card',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    title_alert_warning: 'Titolo alert warning',
    button_text1: 'Button text',
    link_button1: '#',
    button_text2: 'Button text',
    link_button2: '#',
    clock_sprite: "#it-clock",
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "save",
  };

  card_hover = {
    is_hover: true,
    card_img: 'app/lib36/static/imgs/TMP/card/example-01.jpg',
    clock_text: 'Lorem ipsum',
    img_text: '10 Dicembre 2023',
    labels: ['Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum'],
    title: 'Titolo della card',
    sub_title: 'Sottotitolo della card',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    title_alert_warning: 'Titolo alert warning',
    button_text1: 'Button text',
    link_button1: '#',
    button_text2: 'Button text',
    link_button2: '#',
    clock_sprite: "#it-clock",
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "draft",
  };

  card_img_back = {
    is_hover: false,
    card_img_back: 'app/lib36/static/imgs/TMP/card/example-back-01.jpg',
    spans: ['Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum'],
    title: 'Titolo della card',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    button_text1: 'Button text',
    link_button1: '#',
    button_text2: 'Button text',
    link_button2: '#',
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "save",

  };

  card_img_back_hover = {
    is_hover: true,
    card_img_back: 'app/lib36/static/imgs/TMP/card/example-back-01.jpg',
    spans: ['Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum'],
    title: 'Titolo della card',
    card_text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit aliquam
        pretium porta dolor mauris. Amet ut duis in non.`,
    button_text1: 'Button text',
    link_button1: '#',
    button_text2: 'Button text',
    link_button2: '#',
    sprite: "#it-example",
    arrow_sprite: "#it-chevron-right",
    button_action: "draft",
  };

  card_wrapper_primary = {
    wrapper: true,
    type: 'primary',
    label_text: 'Label Text',
    title: 'Titolo della card',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: 'Altre opzioni',
    link_button1: '#',
    button_text2: 'Avvia verifica',
    link_button2: '#',
    sprite_type: '#it-locked',
    border: '',
    badge_type: 'badge-primary',
    sprite: "#it-example",
    button_action: "save",
  };

  card_wrapper_danger = {
    wrapper: true,
    type: 'danger',
    label_text: 'Label Text',
    title: 'Titolo della card',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: 'Button text',
    link_button1: '#',
    button_text2: 'Button text',
    link_button2: '#',
    sprite_type: '#it-error-circle',
    border: '',
    badge_type: 'badge-danger',
    sprite: "#it-example",
    button_action: "save",
  };

  card_wrapper_success = {
    wrapper: true,
    type: 'success',
    label_text: 'Label Text',
    title: 'Titolo della card',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: 'Altre opzioni',
    link_button1: '#',
    button_text2: 'Avvia verifica',
    link_button2: '#',
    sprite_type: '#it-check-circle',
    border: '',
    badge_type: 'badge-success',
    sprite: "#it-example",
    button_action: "save",
  };

  card_wrapper_warning = {
    wrapper: true,
    type: 'warning',
    label_text: 'Label Text',
    title: 'Titolo della card',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: 'Altre opzioni',
    link_button1: '#',
    button_text2: 'Avvia verifica',
    link_button2: '#',
    sprite_type: '#it-unlocked',
    border: '',
    badge_type: 'badge-warning',
    sprite: "#it-example",
    button_action: "save",
  };

  card_wrapper_disabled = {
    wrapper: true,
    type: 'disabled',
    label_text: 'Label Text',
    title: 'Titolo della card',
    card_text: `Ciao questo è un testo di prova`,
    button_text1: 'Altre opzioni',
    link_button1: '#',
    button_text2: 'Avvia verifica',
    link_button2: '#',
    sprite_type: '#it-primary',
    border: 'disabled',
    badge_type: 'disabled',
    sprite: "#it-example",
    button_action: "save",
  };
}
