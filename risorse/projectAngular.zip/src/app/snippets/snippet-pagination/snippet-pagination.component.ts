import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-pagination',
  templateUrl: './snippet-pagination.component.html',
  styleUrls: ['./snippet-pagination.component.scss']
})
export class SnippetPaginationComponent {

  paginationFuncion = (n: number) => {
    if (n) {
      window.location.replace('/pagination/#p' + n)
    }
  }

  pagination_arrows = {
    arrows: true,
    active: 1,
    lastPage: 100,
    range: 4,
    double_arrow_left: "#it-double-arrow-left",
    chevron_left: "#it-chevron-left",
    chevron_right: "#it-chevron-right",
    double_arrow_right: "#it-double-arrow-right",
  }

  pagination_text = {
    text: true,
    active: 1,
    lastPage: 100,
    range: 4,
  }

  pagination_select_page = {
    arrows: true,
    text: true,
    skip_page: true,
    active: 5,
    lastPage: 15,
    range: 4,
    input_name: 'fieldSkip1',
    input_value: '',
    input_id: 'fieldSkip1Label',
    double_arrow_left: "#it-double-arrow-left",
    chevron_left: "#it-chevron-left",
    chevron_right: "#it-chevron-right",
    double_arrow_right: "#it-double-arrow-right",
  }

  pagination_select_page_dropdown = {
    arrows: true,
    text: true,
    skip_page: true,
    dropdown: true,
    active: 1,
    lastPage: 100,
    range: 4,
    double_arrow_left: "#it-double-arrow-left",
    chevron_left: "#it-chevron-left",
    chevron_right: "#it-chevron-right",
    double_arrow_right: "#it-double-arrow-right",
    select: {
      name: 'fieldSkip2',
      value: '',
      options: [
        { value: '1', selected: true },
        { value: '2' },
        { value: '3' },
        { value: '4' },
        { value: '5' },
        { value: '6' },
      ]
    }
  }

}
