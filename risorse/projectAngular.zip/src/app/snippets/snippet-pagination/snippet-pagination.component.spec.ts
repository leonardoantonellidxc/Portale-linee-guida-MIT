import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetPaginationComponent } from './snippet-pagination.component';

describe('SnippetPaginationComponent', () => {
  let component: SnippetPaginationComponent;
  let fixture: ComponentFixture<SnippetPaginationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetPaginationComponent]
    });
    fixture = TestBed.createComponent(SnippetPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
