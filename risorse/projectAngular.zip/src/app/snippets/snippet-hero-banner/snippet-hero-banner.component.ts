import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-hero-banner',
  templateUrl: './snippet-hero-banner.component.html',
  styleUrls: ['./snippet-hero-banner.component.scss']
})
export class SnippetHeroBannerComponent {
  
  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  hero_banner_l1 = {
    level: 1,
    title: 'Titolo',
    subtitle: 'Inserisci qui il sottotitolo',
    body_text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididuntLorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor`,
    input_search_name: 'field1',
    input_search_placeholder: 'Cerca tra tutti i servizi...',
    input_search_value: '',
    search_sprite: '#it-search',
    chips: [
      { chip: 'Lorem ipsum', example_sprite: "#it-example", },
      { chip: 'Lorem ipsum', example_sprite: "#it-example", },
      { chip: 'Lorem ipsum', example_sprite: "#it-example", },
    ],
    cards: [
      {
        title: 'Titolo della card',
        text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit
                  aliquam pretium porta dolor mauris. Amet ut duis in non.`,
        button_text: 'Button text',
        example_sprite: "#it-example",
        arrow_sprite: "#it-arrow-right",
        button_action: "save",
      },
      {
        title: 'Titolo della card',
        text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit
                  aliquam pretium porta dolor mauris. Amet ut duis in non.`,
        button_text: 'Button text',
        example_sprite: "#it-example",
        arrow_sprite: "#it-arrow-right",
        button_action: "draft",
      },
      {
        title: 'Titolo della card',
        text: `Lorem ipsum dolor sit amet consectetur. Non sit ut et sit
                  aliquam pretium porta dolor mauris. Amet ut duis in non.`,
        button_text: 'Button text',
        example_sprite: "#it-example",
        arrow_sprite: "#it-arrow-right",
        button_action: "save",
      },
    ]
  }

  hero_banner_l2 = {
    level: 2,
    title: 'Titolo',
    subtitle: 'Inserisci qui il sottotitolo',
    body_text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididuntLorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor`,
    input_search_name: 'field1',
    input_search_placeholder: 'Cerca tra tutti i servizi...',
    input_search_value: '',
    search_sprite: '#it-search',
    button_action: "draft",
    chips: [
      { chip: 'Lorem ipsum', example_sprite: "#it-example", },
      { chip: 'Lorem ipsum', example_sprite: "#it-example", },
      { chip: 'Lorem ipsum', example_sprite: "#it-example", },
    ],
    breadcrumb: [
      {
        link: '#',
        page_title: 'Page',
        active: false
      },
      {
        link: '#',
        page_title: 'Page',
        active: false
      },
      {
        link: '#',
        page_title: 'Page',
        active: false
      },
      {
        page_title: 'Page',
        active: true
      },
    ],
    image: {
      src: 'app/lib36/static/imgs/TMP/hero_banner/header-01.jpg',
      alt: 'Lorem ipsum'
    }
  }
}
