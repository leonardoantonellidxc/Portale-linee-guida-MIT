import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetHeroBannerComponent } from './snippet-hero-banner.component';

describe('SnippetHeroBannerComponent', () => {
  let component: SnippetHeroBannerComponent;
  let fixture: ComponentFixture<SnippetHeroBannerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetHeroBannerComponent]
    });
    fixture = TestBed.createComponent(SnippetHeroBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
