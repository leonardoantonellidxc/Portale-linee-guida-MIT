import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetUploaderComponent } from './snippet-uploader.component';

describe('SnippetUploaderComponent', () => {
  let component: SnippetUploaderComponent;
  let fixture: ComponentFixture<SnippetUploaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetUploaderComponent]
    });
    fixture = TestBed.createComponent(SnippetUploaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
