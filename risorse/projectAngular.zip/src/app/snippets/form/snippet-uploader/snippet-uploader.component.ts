import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-uploader',
  templateUrl: './snippet-uploader.component.html',
  styleUrls: ['./snippet-uploader.component.scss']
})
export class SnippetUploaderComponent {


  uploader_loaded_loading = {

    is_drag_drop: false,
    name: 'uploadFile2',
    input_label: 'Carica file',
    disabled: '',
    loaded: [{ name: 'Nome-file.pdf', size: '3.5 mb' }],
    loading: [
      { name: 'Nome-file.pdf', size: '3.5 mb', progress: 25 },
      { name: 'Nome-file.pdf', size: '3.5 mb', progress: 25 },
    ],
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
    sprite_upload: '#it-upload',
  };

  uploader_loaded_loading_disabled = {

    is_drag_drop: false,
    name: 'uploadFile4',
    disabled: 'disabled',
    input_label: 'Carica altri documenti',
    loaded: [{ name: 'Nome-file.pdf', size: '3.5 mb' }],
    loading: [{ name: 'Nome-file.pdf', size: '3.5 mb', progress: 25 }],
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
    sprite_upload: '#it-upload',
  };

  uploader_drag_drop = {
    is_drag_drop: true,
    type: '',
    type_over: 'over',
    type_active: 'active',
    type_loading: 'loading',
    type_success: 'success',
    type_error: 'error',
    is_alt: 'Default',
    is_class_name: 'default',
    drag_drop_type_button: '',
    sprite_type_button: '',
    drag_drop_type_class_button: '',
    button_text: '',
    drag_drop_type_button_success: 'success',
    drag_drop_type_button_loading: 'primary',
    drag_drop_type_class_button_loading: '',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
    sprite_upload: '#it-upload',
  };

  uploader_drag_drop_active = {
    is_drag_drop: true,
    type_over: 'over',
    type_active: 'active',
    type_loading: 'loading',
    type_success: 'success',
    type_error: 'error',
    drag_drop_type_button: '',
    sprite_type_button: '',
    drag_drop_type_class_button: '',
    button_text: '',
    drag_drop_type_button_success: 'success',
    drag_drop_type_button_loading: 'primary',
    drag_drop_type_class_button_loading: '',
    type: 'active',
    is_alt: 'Active',
    is_class_name: 'active',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
    sprite_upload: '#it-upload',
  };

  uploader_drag_drop_disabled = {
    is_drag_drop: true,
    type_over: 'over',
    type_active: 'active',
    type_loading: 'loading',
    type_success: 'success',
    type_error: 'error',
    drag_drop_type_button: '',
    sprite_type_button: '',
    drag_drop_type_class_button: '',
    button_text: '',
    drag_drop_type_button_success: 'success',
    drag_drop_type_button_loading: 'primary',
    drag_drop_type_class_button_loading: '',
    type_disabled: 'disabled',
    type: 'disabled',
    is_alt: 'Default',
    is_class_name: 'disabled',
    sprite_password_icon: '#it-password-visible',
    sprite_delete_icon: '#it-delete',
    title_text: 'Seleziona uno o più documenti da caricare',
    sprite_document_icon: '#it-document-text',
    sprite_check_circle: '#it-check-circle',
    sprite_close: '#it-close-circle',
    sprite_refresh: '#it-refresh',
    sprite_upload: '#it-upload',
  }
};