import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-date-picker',
  templateUrl: './snippet-date-picker.component.html',
  styleUrls: ['./snippet-date-picker.component.scss']
})
export class SnippetDatePickerComponent {

  date_picker = {
    title: 'Label field',
    name: 'field1',
    value: '',
    years: [2020, 2021, 2022, 2023, 2024],
    is_calendar_sprite: '#it-calendar',
    is_expand_sprite: '#it-expand',
    message: '',
    sprite_image: '',
  }
  date_picker_disabled = {
    type: 'disabled',
    title: 'Label field',
    name: 'field2',
    value: '28/07/2024',
    years: [2020, 2021, 2022, 2023, 2024],
    is_calendar_sprite: '#it-calendar',
    is_expand_sprite: '#it-expand',
    message: '',
    sprite_image: '',
  }
  date_picker_read_only = {
    type: 'readonly',
    title: 'Label field',
    name: 'field3',
    value: '28/07/2024',
    years: [2020, 2021, 2022, 2023, 2024],
    is_calendar_sprite: '#it-calendar',
    is_expand_sprite: '#it-expand',
    message: '',
    sprite_image: '',
  }
  date_picker_valid = {
    type: 'is-valid',
    title: 'Label field',
    name: 'field4',
    value: '28/07/2024',
    valid_message: 'Message explaining the success',
    invalid_message: 'Message explaining the error',
    years: [2020, 2021, 2022, 2023, 2024],
    toValidate: true,
    is_calendar_sprite: '#it-calendar',
    is_expand_sprite: '#it-expand',
    message: 'Message explaining the success',
    sprite_image: '#it-check-circle',
  }
  date_picker_invalid = {
    type: 'is-invalid',
    title: 'Label field',
    name: 'field5',
    value: '28/07/2024',
    valid_message: 'Message explaining the success',
    invalid_message: 'Message explaining the error',
    years: [2020, 2021, 2022, 2023, 2024],
    toValidate: true,
    is_calendar_sprite: '#it-calendar',
    is_expand_sprite: '#it-expand',
    message: 'Message explaining the error',
    sprite_image: '#it-error-circle',
  }
}
