import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetDatePickerComponent } from './snippet-date-picker.component';

describe('SnippetDatePickerComponent', () => {
  let component: SnippetDatePickerComponent;
  let fixture: ComponentFixture<SnippetDatePickerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetDatePickerComponent]
    });
    fixture = TestBed.createComponent(SnippetDatePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
