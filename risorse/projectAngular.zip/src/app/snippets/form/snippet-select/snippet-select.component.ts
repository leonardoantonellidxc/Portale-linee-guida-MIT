import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-select',
  templateUrl: './snippet-select.component.html',
  styleUrls: ['./snippet-select.component.scss']
})
export class SnippetSelectComponent {

  select_field = {
    name: 'field1',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    info_text: ' Testo informativo ',
    is_message: "Testo informativo",
    sprite_fill: "#it-info-circle",
    sprite_example: "#it-example",
  }

  select_field_no_icon = {
    name: 'field5',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    info_text: ' Testo informativo ',
    no_icon: true,
    sprite_fill: "#it-info-circle",
    sprite_example: "#it-example",
  }

  select_field_disabled = {
    disabled: true,
    name: 'field1',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    sprite_example: "#it-example",
  }

  select_field_disabled_no_icon = {
    disabled: true,
    name: 'field5',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    info_text: ' Testo informativo ',
    no_icon: true,
    sprite_fill: "#it-info-circle",
    sprite_example: "#it-example",
  }
  select_field_readonly = {
    readonly: true,
    name: 'field1',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    sprite_example: "#it-example",
  }

  select_field_readonly_no_icon = {
    readonly: true,
    name: 'field5',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    info_text: ' Testo informativo ',
    no_icon: true,
    sprite_fill: "#it-info-circle",
    sprite_example: "#it-example",
  }
  select_field_invalid = {
    type: 'invalid',
    name: 'field1',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    message: ' Message explaining the error ',
    sprite_fill: "#it-error",
    sprite_example: "#it-example",
  }

  select_field_invalid_no_icon = {
    type: 'invalid',
    name: 'field1',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    message: ' Message explaining the error ',
    no_icon: true,
    sprite_fill: "#it-error",
    sprite_example: "#it-example",
  }
  select_field_valid = {
    type: 'valid',
    name: 'field1',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    message: ' Message explaining the success ',
    sprite_fill: "#it-check-circle",
    sprite_example: "#it-example",
  }

  select_field_valid_no_icon = {
    type: 'valid',
    name: 'field5',
    label_text: ' Label field ',
    placeholder: 'Placeholder field',
    value: 'Lorem ipsum',
    options: [
      {
        value: '0', text: ''
      },
      {
        value: '1',
        text: 'Lorem ipsum 1',
      },
      {
        value: '2',
        text: 'Lorem ipsum 2'
      }
    ],
    message: ' Message explaining the success ',
    no_icon: true,
    sprite_fill: "#it-check-circle",
    sprite_example: "#it-example",
  }
}
