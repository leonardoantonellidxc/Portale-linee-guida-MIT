import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetSelectComponent } from './snippet-select.component';

describe('SnippetSelectComponent', () => {
  let component: SnippetSelectComponent;
  let fixture: ComponentFixture<SnippetSelectComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetSelectComponent]
    });
    fixture = TestBed.createComponent(SnippetSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
