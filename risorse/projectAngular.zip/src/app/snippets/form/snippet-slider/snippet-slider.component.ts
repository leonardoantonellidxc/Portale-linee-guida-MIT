import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-slider',
  templateUrl: './snippet-slider.component.html',
  styleUrls: ['./snippet-slider.component.scss']
})
export class SnippetSliderComponent {

  slider_2_range_field = {
    id: 'field1Label',
    label_text: 'Label field',
    range_field: 2,
    min: 20,
    max: 60,
    sprite_info_circle: '#it-info-circle',
    sprite_example : '#it-example',
  }
  slider_1_range_field = {
    id: 'field2Label',
    label_text: 'Label field',
    range_field: 1,
    min: 0,
    max: 60,
    sprite_info_circle: '#it-info-circle',
    sprite_example : '#it-example',
  }
  slider_2_range_field_disabled = {
    id: 'field10Label',
    label_text: 'Label field',
    range_field: 2,
    min: 20,
    max: 60,
    disabled: true,
    sprite_info_circle: '#it-info-circle',
    sprite_example : '#it-example',
  }
  slider_1_range_field_disabled = {
    id: 'field1Label',
    label_text: 'Label field',
    range_field: 1,
    min: 0,
    max: 60,
    disabled: true,
    sprite_info_circle: '#it-info-circle',
    sprite_example : '#it-example',
  }
  slider_2_range_field_invalid = {
    id: 'field20Label',
    label_text: 'Label field',
    range_field: 2,
    min: 20,
    max: 60,
    minValid: 20,
    maxValid: 50,
    invalid: true,
    valid: false,
    toValidate: true,
    sprite_info_circle: '#it-info-circle',
    sprite_example : '#it-example',
  }
  slider_2_range_field_valid = {
    id: 'field30Label',
    label_text: 'Label field',
    range_field: 2,
    min: 20,
    max: 60,
    minValid: 20,
    maxValid: 60,
    valid: true,
    invalid: false,
    toValidate: true,
    sprite_info_circle: '#it-info-circle',
    sprite_example : '#it-example',
  }
}
