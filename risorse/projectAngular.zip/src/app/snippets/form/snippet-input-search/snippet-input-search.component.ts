import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-input-search',
  templateUrl: './snippet-input-search.component.html',
  styleUrls: ['./snippet-input-search.component.scss']
})
export class SnippetInputSearchComponent {
  sprite = 'app/lib36/static/imgs/icon/sprite.svg';


  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }
  ob_input_search_disabled = {
    is_disabled: true,
    is_showing: false,
    divider: 3,
    sprite_streamline: '#it-streamline',
    sprite_search: '#it-search',
    field: [
      {
        id: "example1",
        name: "Label Text 1",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example2",
        name: "Label Text 2",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example3",
        name: "Label Text 3",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example4",
        name: "Label Text 4",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example5",
        name: "Label Text 5",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example6",
        name: "Label Text 6",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example7",
        name: "Label Text 7",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      }
    ]
  };
  ob_input_mini_search = {
    is_mini: true,
    divider: 3,
    sprite_streamline: '#it-streamline',
    sprite_search: '#it-search',
    field: [
      {
        id: "example1",
        name: "Label Text 1",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example2",
        name: "Label Text 2",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example3",
        name: "Label Text 3",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example4",
        name: "Label Text 4",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example5",
        name: "Label Text 5",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example6",
        name: "Label Text 6",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example7",
        name: "Label Text 7",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      }
    ]
  };

  ob_input_mini_search_disabled = {

    is_mini_search_disabled : true, 
    is_showing: false,
    divider: 3,
    sprite_streamline: '#it-streamline',
    sprite_search: '#it-search',
    field: [
      {
        id: "example1",
        name: "Label Text 1",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example2",
        name: "Label Text 2",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example3",
        name: "Label Text 3",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example4",
        name: "Label Text 4",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example5",
        name: "Label Text 5",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example6",
        name: "Label Text 6",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example7",
        name: "Label Text 7",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      }
    ]
  };


  ob_input_search = {
    divider: 3,
    sprite_streamline: '#it-streamline',
    sprite_search: '#it-search',
    field: [
      {
        id: "example1",
        name: "Label Text 1",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example2",
        name: "Label Text 2",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example3",
        name: "Label Text 3",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example4",
        name: "Label Text 4",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example5",
        name: "Label Text 5",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example6",
        name: "Label Text 6",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      },
      {
        id: "example7",
        name: "Label Text 7",
        placeholder: "Search",
        type: "text",
        value: "",
        sprite_example: "#it-example",
        button_action: "save",
      }
    ]
  };
}

