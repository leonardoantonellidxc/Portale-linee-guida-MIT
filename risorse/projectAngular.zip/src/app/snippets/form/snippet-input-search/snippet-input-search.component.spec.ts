import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetInputSearchComponent } from './snippet-input-search.component';

describe('SnippetInputSearchComponent', () => {
  let component: SnippetInputSearchComponent;
  let fixture: ComponentFixture<SnippetInputSearchComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetInputSearchComponent]
    });
    fixture = TestBed.createComponent(SnippetInputSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
