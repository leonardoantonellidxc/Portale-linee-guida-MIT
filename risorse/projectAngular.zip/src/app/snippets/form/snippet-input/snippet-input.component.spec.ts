import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetInputComponent } from './snippet-input.component';

describe('SnippetInputComponent', () => {
  let component: SnippetInputComponent;
  let fixture: ComponentFixture<SnippetInputComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetInputComponent]
    });
    fixture = TestBed.createComponent(SnippetInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
