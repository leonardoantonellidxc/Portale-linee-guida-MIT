import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-input',
  templateUrl: './snippet-input.component.html',
  styleUrls: ['./snippet-input.component.scss']
})
export class SnippetInputComponent {

  example_show_hide = {
    disabled: false,
    readonly: false,
    name: 'field1',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: true,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    example_sprite: "#it-example",
  }

  example_no_show_hide = {
    disabled: false,
    readonly: false,
    name: 'field2',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: false,
    hide: false,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    example_sprite: "#it-example",
  }

  no_example_show_hide = {
    disabled: false,
    readonly: false,
    name: 'field3',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: true,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    
  }

  no_example_hide = {
    disabled: false,
    readonly: false,
    name: 'field4',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }
  no_example_no_show_hide = {
    disabled: false,
    readonly: false,
    name: 'field5',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: false,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }

  example_show_hide_disabled = {
    disabled: true,
    readonly: false,
    name: 'field1',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: true,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    example_sprite: "#it-example",
  }

  example_no_show_hide_disabled = {
    disabled: true,
    readonly: false,
    name: 'field2',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: false,
    hide: false,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    example_sprite: "#it-example",
  }

  no_example_show_hide_disabled = {
    disabled: true,
    readonly: false,
    name: 'field3',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: true,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }

  no_example_hide_disabled = {
    disabled: true,
    readonly: false,
    name: 'field4',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }
  no_example_no_show_hide_disabled = {
    disabled: true,
    readonly: false,
    name: 'field5',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: false,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }
  example_show_hide_readonly = {
    disabled: false,
    readonly: true,
    name: 'field1',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: true,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    example_sprite: "#it-example",
  }

  example_no_show_hide_readonly = {
    disabled: false,
    readonly: true,
    name: 'field2',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: false,
    hide: false,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
    example_sprite: "#it-example",
  }

  no_example_show_hide_readonly = {
    disabled: false,
    readonly: true,
    name: 'field3',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: true,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }

  no_example_hide_readonly = {
    disabled: false,
    readonly: true,
    name: 'field4',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }
  no_example_no_show_hide_readonly = {
    disabled: false,
    readonly: true,
    message: null,
    name: 'field5',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: false,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }
  example_show_hide_invalid = {
    disabled: false,
    readonly: false,
    type: 'invalid',
    message: ' Message explaining the error ',
    name: 'field1',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: true,
    hide: true,
    sprite_fill: "#it-error-circle",
    example_sprite: "#it-example",
  }

  example_no_show_hide_invalid = {
    disabled: false,
    readonly: false,
    type: 'invalid',
    message: ' Message explaining the error ',
    name: 'field2',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: false,
    hide: false,
    sprite_fill: "#it-error-circle",
    example_sprite: "#it-example",
  }

  no_example_show_hide_invalid = {
    disabled: false,
    readonly: false,
    type: 'invalid',
    message: ' Message explaining the error ',
    name: 'field3',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: true,
    hide: true,
    sprite_fill: "#it-error-circle",
  }

  no_example_hide_invalid = {
    disabled: false,
    readonly: false,
    type: 'invalid',
    message: ' Message explaining the error ',
    name: 'field4',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: true,
    sprite_fill: "#it-error-circle",
  }
  no_example_no_show_hide_invalid = {
    disabled: false,
    readonly: false,
    type: 'invalid',
    message: ' Message explaining the error ',
    name: 'field5',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: false,
    sprite_fill: "#it-error-circle",
  }
  example_show_hide_valid = {
    disabled: false,
    readonly: false,
    type: 'valid',
    message: ' Message explaining the success ',
    name: 'field1',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: true,
    hide: true,
    sprite_fill: "#it-check-circle",
    example_sprite: "#it-example",
  }

  example_no_show_hide_valid = {
    disabled: false,
    readonly: false,
    type: 'valid',
    message: ' Message explaining the success ',
    name: 'field2',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: true,
    show: false,
    hide: false,
    sprite_fill: "#it-check-circle",
    example_sprite: "#it-example",
  }

  no_example_show_hide_valid = {
    disabled: false,
    readonly: false,
    type: 'valid',
    message: ' Message explaining the success ',
    name: 'field3',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: true,
    hide: true,
    sprite_fill: "#it-check-circle",
  }

  no_example_hide_valid = {
    disabled: false,
    readonly: false,
    type: 'valid',
    message: ' Message explaining the success ',
    name: 'field4',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: true,
    sprite_fill: "#it-check-circle",
  }
  no_example_no_show_hide_valid = {
    disabled: false,
    readonly: false,
    type: 'valid',
    message: ' Message explaining the success ',
    name: 'field5',
    label: ' Label field ',
    value: 'Lorem ipsum',
    placeholder: 'Placeholder field',
    example: false,
    show: false,
    hide: false,
    sprite_fill: "#it-check-circle",
  }
  text_tarea = {
    disabled: false,
    readonly: false,
    name: 'field10',
    label: ' Label field ',
    value: '',
    placeholder: 'Placeholder field',
    textarea: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }

  text_area_disabled = {
    disabled: true,
    readonly: false,
    message: ' Message explaining the success ',
    name: 'field11',
    label: ' Label field ',
    value: '',
    placeholder: 'Placeholder field',
    textarea: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }

  text_area_readolny = {
    disabled: false,
    readonly: true,
    message: ' Message explaining the success ',
    name: 'field12',
    label: ' Label field ',
    value: '',
    placeholder: 'Placeholder field',
    textarea: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-info-circle",
  }

  text_area_invalid = {
    disabled: false,
    readonly: false,
    type: 'invalid',
    message: ' Message explaining the error ',
    name: 'field13',
    label: ' Label field ',
    value: '',
    placeholder: 'Placeholder field',
    textarea: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-error-circle",
  }
  text_area_valid = {
    disabled: false,
    readonly: false,
    type: 'valid',
    message: ' Message explaining the success ',
    name: 'field14',
    label: ' Label field ',
    value: '',
    placeholder: 'Placeholder field',
    textarea: true,
    info_text: ' Testo informativo ',
    sprite_fill: "#it-check-circle",
  }
}
