import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-bottom-bar',
  templateUrl: './snippet-bottom-bar.component.html',
  styleUrls: ['./snippet-bottom-bar.component.scss'],
})
export class SnippetBottomBarComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  ob_light = {
    type_bottom_bar: "",
    left_group: [
      {
        type: "danger",
        subtype: "",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "link",
        subtype: "",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      }
    ],
    right_group: [
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      }
    ]
  };

  ob_dark = {
    type_bottom_bar: " bar-dark",
    left_group: [
      {
        type: "danger",
        subtype: "",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "btn-link",
        subtype: "",
        class: "btn-outline-white",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "draft",
      }
    ],
    right_group: [
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      },
      {
        type: "primary",
        subtype: "icon",
        class: "",
        text: "Button text",
        link: "#",
        sprite: "#it-example",
        button_action: "save",
      }
    ]
  };
}



