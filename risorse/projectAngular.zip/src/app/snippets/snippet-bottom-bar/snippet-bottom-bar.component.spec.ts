import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetBottomBarComponent } from './snippet-bottom-bar.component';

describe('SnippetBottomBarComponent', () => {
  let component: SnippetBottomBarComponent;
  let fixture: ComponentFixture<SnippetBottomBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnippetBottomBarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SnippetBottomBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
