import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-table',
  templateUrl: './snippet-table.component.html',
  styleUrls: ['./snippet-table.component.scss']
})
export class SnippetTableComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  sortFunction = (e: Event) => {
    e.preventDefault();
  }
  checkFunction = (ob: any, e: Event) => {
    ob.t_rows_states.forEach((elem: { active: boolean }) => {
      elem.active = (e.target as HTMLInputElement).checked;
    });
  }

  table_lg = {
    size: 'lg',
    sprite_more: '#it-more',

    t_head: [
      {
        type: 'checkbox',
        check_name: 'field-0',
        check_value: '',
        aria_label: 'Lorem ipsum',
        checked: false,
        sprite_sort: '#it-arrow-vertical',
        action: this.checkFunction
      },
      {
        type: 'text',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'text',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'badge',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'date',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'button',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      { type: 'more' }
    ],
    t_rows: [
      [
        {
          check_name: 'field-1',
          check_value: '',
          aria_label: 'Lorem ipsum',
        },
        {
          text: 'Label text',

        },
        {
          text: 'Label text'
        },
        {
          text: 'Label text',
          badge_text: 'Badge'
        },
        {
          date: '01/01/2020'
        },
        {
          button_text: 'Button text',
          link: '#',
          sprite_example: '#it-example',
          button_action: "save",
        },
        {
          type: 'more', sprite_more: '#it-more-actions'
        }]
      ,
      [{
        check_name: 'field-2',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-3',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-4',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-5',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-6',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-7',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-8',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-9',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-10',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-11',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]

    ],
    t_rows_states: [
      { active: false },
      { active: true },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
    ]
  }
  table_md = {
    size: 'md',
    sprite_more: '#it-more',

    t_head: [
      {
        type: 'checkbox',
        check_name: 'field-12',
        check_value: '',
        aria_label: 'Lorem ipsum',
        checked: false,
        sprite_sort: '#it-arrow-vertical',
        action: this.checkFunction
      },
      {
        type: 'text',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'text',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'badge',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'date',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'button',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      { type: 'more' }
    ],
    t_rows: [
      [
        {
          check_name: 'field-13',
          check_value: '',
          aria_label: 'Lorem ipsum',
        },
        {
          text: 'Label text'
        },
        {
          text: 'Label text'
        },
        {
          text: 'Label text',
          badge_text: 'Badge'
        },
        {
          date: '01/01/2020'
        },
        {
          button_text: 'Button text',
          link: '#',
          sprite_example: '#it-example',
        },
        {
        }]
      ,
      [{
        check_name: 'field-14',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-15',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-16',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-17',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-18',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-19',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-20',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-21',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-22',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-23',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
    ],
    t_rows_states: [
      { active: false },
      { active: true },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
    ]
  }
  table_sm = {
    size: 'sm',
    sprite_more: '#it-more',
    t_head: [
      {
        type: 'checkbox',
        check_name: 'field-24',
        check_value: '',
        aria_label: 'Lorem ipsum',
        checked: false,
        sprite_sort: '#it-arrow-vertical',
        action: this.checkFunction
      },
      {
        type: 'text',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'text',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'badge',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'date',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      {
        type: 'button',
        span_title: 'Title',
        sprite_sort: '#it-arrow-vertical',
        action: this.sortFunction
      },
      { type: 'more' }
    ],
    t_rows: [
      [
        {
          check_name: 'field-25',
          check_value: '',
          aria_label: 'Lorem ipsum',
        },
        {
          text: 'Label text'
        },
        {
          text: 'Label text'
        },
        {
          text: 'Label text',
          badge_text: 'Badge'
        },
        {
          date: '01/01/2020'
        },
        {
          button_text: 'Button text',
          link: '#',
          sprite_example: '#it-example',
        },
        {
        }]
      ,
      [{
        check_name: 'field-26',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-27',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-28',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-29',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-30',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-31',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-32',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#'
      },
      {
      }]
      ,
      [{
        check_name: 'field-33',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-34',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
      [{
        check_name: 'field-35',
        check_value: '',
        aria_label: 'Lorem ipsum',
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text'
      },
      {
        text: 'Label text',
        badge_text: 'Badge'
      },
      {
        date: '01/01/2020'
      },
      {
        button_text: 'Button text',
        link: '#',
        button_action: "save",
        sprite_example: '#it-example',
      },
      {
      }]
      ,
    ],
    t_rows_states: [
      { active: false },
      { active: true },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
      { active: false },
    ]
  }

}
