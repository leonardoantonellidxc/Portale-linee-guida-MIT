import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-dropdown',
  templateUrl: './snippet-dropdown.component.html',
  styleUrls: ['./snippet-dropdown.component.scss']
})
export class SnippetDropdownComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  dropdown = {
    button_text: 'Dropdown button',
    dropdown_title: 'Title',
    example_sprite: '#it-example',
    items: [
      {
        active: true,
        text: ' Action ',
        href: '#',
        button_action: "draft",
      },
      {
        text: ' Another action ',
        href: '#',
        button_action: "save",
      },
      {
        text: ' Something else here ',
        href: '#',
        button_action: "draft",
      }
    ]
  }
  dropdown_search = {
    search: true,
    button_text: 'Dropdown button',
    input_name: 'field1',
    input_placeholder: 'Cerca',
    input_value: '',
    input_aria_label: 'Lorem ipsum dolor sit',
    example_sprite: '#it-example',
    search_sprite: "#it-search", 
    items: [
      {
        text: ' Action ',
        href: '#',
        button_action: "save",
      },
      {
        text: ' Another action ',
        href: '#',
        button_action: "save",
      },
      {
        text: ' Something else here ',
        href: '#',
        button_action: "save",
      },
      {
        h_line: true
      },
      {
        text: ' Action ',
        href: '#',
        button_action: "save",
      },
      {
        text: ' Another action ',
        href: '#',
        button_action: "save",
      },
      {
        text: ' Something else here ',
        href: '#',
        button_action: "save",
      },

    ]
  }
  dropdown_search_checkbox = {
    checkbox: true,
    search: true,
    button_text: 'Dropdown button',
    input_name: 'field1',
    input_placeholder: 'Cerca',
    input_value: '',
    input_aria_label: 'Lorem ipsum dolor sit',
    search_sprite: "#it-search",
    items: [
      {
        label_checkbox: ' Label checkbox ',
        name: 'options',
        id: 1,
        value: '',
        button_action: "save",
      },
      {
        label_checkbox: ' Label checkbox ',
        name: 'options',
        id: 2,
        value: '',
        button_action: "draft",
      },
      {
        label_checkbox: ' Label checkbox ',
        name: 'options',
        id: 3,
        value: '',
        button_action: "save",
      },
      {
        h_line: true
      },
      {
        label_checkbox: ' Label checkbox ',
        name: 'options',
        id: 4,
        value: '',
        button_action: "draft",
      },
      {
        label_checkbox: ' Label checkbox ',
        name: 'options',
        id: 5,
        value: '',
        button_action: "draft",
      },

    ]
  }
}
