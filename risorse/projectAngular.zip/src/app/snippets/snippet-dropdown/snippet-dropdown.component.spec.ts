import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetDropdownComponent } from './snippet-dropdown.component';

describe('SnippetDropdownComponent', () => {
  let component: SnippetDropdownComponent;
  let fixture: ComponentFixture<SnippetDropdownComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetDropdownComponent]
    });
    fixture = TestBed.createComponent(SnippetDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
