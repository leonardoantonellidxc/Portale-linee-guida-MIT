import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-stepper',
  templateUrl: './snippet-stepper.component.html',
  styleUrls: ['./snippet-stepper.component.scss']
})
export class SnippetStepperComponent {
  stepper = {
    title: ' Titolo del flusso ',
    mobile_progress: {
      label_title: 'Step 3/6',
      label_percent: '50%'
    },
    sprite_example: "#it-example",
    items: [
      {
        step_icon_span: '1',
        step_info_title: 'Testo - in corso segnaposto',
        step_info_text: 'Lorem ipsum',
        step_sprite: '',
      },
      {
        step_icon_span: '2',
        step_info_title: 'Testo - in corso segnaposto',
        step_info_text: 'Lorem ipsum',
        step_sprite: '',
      },
      {
        type: 'success',
        step_info_title: 'Testo - in corso segnaposto',
        step_info_text: 'Completato',
        step_sprite: '#it-check-circle',
      },
      {
        type: 'active',
        step_icon_span: '4',
        step_info_title: 'Testo - in corso segnaposto',
        step_info_text: 'In corso',
        step_sprite: '',
      },
      {
        type: 'danger',
        step_info_title: 'Testo - in corso segnaposto',
        step_info_text: 'In errore',
        step_sprite: '#it-error-circle',
      },
    ],
    mobile_item: {
      step_icon_span: '0',
      step_info_title: 'Testo - in corso segnaposto',
      step_info_text: 'In corso',
      step_maximize_sprite: '#it-maximize',
    }
  }
}
