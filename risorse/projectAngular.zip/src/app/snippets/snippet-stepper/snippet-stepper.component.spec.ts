import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetStepperComponent } from './snippet-stepper.component';

describe('SnippetStepperComponent', () => {
  let component: SnippetStepperComponent;
  let fixture: ComponentFixture<SnippetStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetStepperComponent]
    });
    fixture = TestBed.createComponent(SnippetStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
