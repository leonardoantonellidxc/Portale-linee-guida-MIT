import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-sidebar-navigation',
  templateUrl: './snippet-sidebar-navigation.component.html',
  styleUrls: ['./snippet-sidebar-navigation.component.scss']
})
export class SnippetSidebarNavigationComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  navigation = {
    title: 'Sidebar Navigation',
    items: [
      {
        isDropdown: false,
        link: '/sidebar_navigation/#1',
        text: 'Lorem ipsum',
        sprite_expand : '#it-expand',
        button_action: "draft",
      },
      {
        isDropdown: true,
        link: '/sidebar_navigation/#2',
        text: 'Lorem ipsum',
        sprite_expand : '#it-expand',
        sub_items: [
          {
            isActive: false,
            text: 'Lorem ipsum',
            button_action: "save",
          },
          {
            isActive: false,
            text: 'Lorem ipsum',
            button_action: "draft",
          },
          {
            isActive: true,
            text: 'Lorem ipsum',
            button_action: "save",
          },
          {
            isActive: false,
            text: 'Lorem ipsum',
            button_action: "draft",
          },
          {
            isActive: false,
            text: 'Lorem ipsum',
            button_action: "save",
          },
          {
            isActive: false,
            text: 'Lorem ipsum',
            button_action: "save",
          },
        ]
      },
      {
        isDropdown: false,
        link: '/sidebar_navigation/#3',
        text: 'Lorem ipsum',
        sprite_expand : '#it-expand',
        button_action: "save",
      },
      {
        isDropdown: false,
        link: '/sidebar_navigation/#4',
        text: 'Lorem ipsum',
        sprite_expand : '#it-expand',
        button_action: "draft",
      },
      {
        isDropdown: false,
        link: '/sidebar_navigation/#5',
        text: 'Lorem ipsum',
        sprite_expand : '#it-expand',
        button_action: "save",
      },
      {
        isDropdown: false,
        link: '/sidebar_navigation/#6',
        text: 'Lorem ipsum',
        sprite_expand : '#it-expand',
        button_action: "draft",
      },
    ]
  }
}
