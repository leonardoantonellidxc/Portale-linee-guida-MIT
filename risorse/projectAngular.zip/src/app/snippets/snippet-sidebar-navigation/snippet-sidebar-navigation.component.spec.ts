import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetSidebarNavigationComponent } from './snippet-sidebar-navigation.component';

describe('SnippetSidebarNavigationComponent', () => {
  let component: SnippetSidebarNavigationComponent;
  let fixture: ComponentFixture<SnippetSidebarNavigationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetSidebarNavigationComponent]
    });
    fixture = TestBed.createComponent(SnippetSidebarNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
