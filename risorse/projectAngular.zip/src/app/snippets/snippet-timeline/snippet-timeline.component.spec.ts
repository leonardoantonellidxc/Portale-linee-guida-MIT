import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetTimelineComponent } from './snippet-timeline.component';

describe('SnippetTimelineComponent', () => {
  let component: SnippetTimelineComponent;
  let fixture: ComponentFixture<SnippetTimelineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnippetTimelineComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SnippetTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
