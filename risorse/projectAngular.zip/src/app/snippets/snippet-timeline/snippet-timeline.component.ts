import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-timeline',
  templateUrl: './snippet-timeline.component.html',
  styleUrls: ['./snippet-timeline.component.scss']
})
export class SnippetTimelineComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  ob_timeline_default = {
    type: "primary",
    date: "15/04/2024",
    subtype: "",
    state: "In lavorazione",
    title: "La pratica è in gestione alla DGT Nord Ovest",
    body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.`,
    firstButtonText: "Aprova documento",
    firstButtonLink: "#",
    secondButtonText: "Label text",
    secondButtonLink: "#",
    sprite_icon: "#it-example",
    button_action: "draft",
  };
  ob_timeline_active = {
    type: "primary",
    subtype: "active",
    date: "15/04/2024",
    state: "In lavorazione",
    title: "La pratica è in gestione alla DGT Nord Ovest",
    body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
    do eiusmod tempor incididunt ut labore.`,
    firstButtonText: "Aprova documento",
    firstButtonLink: "#",
    secondButtonText: "Label text",
    secondButtonLink: "#",
    sprite_icon: "#it-example",
    button_action: "draft",
  };
  ob_timeline_success = {
    type: "success",
    date: "15/04/2024",
    state: "In lavorazione",
    title: "La pratica è in gestione alla DGT Nord Ovest",
    body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
    do eiusmod tempor incididunt ut labore.`,
    firstButtonText: "Aprova documento",
    firstButtonLink: "#",
    secondButtonText: "Label text",
    secondButtonLink: "#",
    subtype: "success",
    sprite_icon: "#it-check-circle",
    button_action: "draft",
  };
  ob_timeline_warning = {
    type: "warning",
    date: "15/04/2024",
    state: "In lavorazione",
    title: "La pratica è in gestione alla DGT Nord Ovest",
    body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
    do eiusmod tempor incididunt ut labore.`,
    firstButtonText: "Aprova documento",
    firstButtonLink: "#",
    secondButtonText: "Label text",
    secondButtonLink: "#",
    subtype: "warning",
    sprite_icon: "#it-warning",
    button_action: "draft",
  };
  ob_timeline_danger = {
    type: "danger",
    date: "15/04/2024",
    state: "In lavorazione",
    title: "La pratica è in gestione alla DGT Nord Ovest",
    body: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
    do eiusmod tempor incididunt ut labore.`,
    firstButtonText: "Aprova documento",
    firstButtonLink: "#",
    secondButtonText: "Label text",
    secondButtonLink: "#",
    subtype: "danger",
    sprite_icon: "#it-error-circle",
    button_action: "draft",
  };
}
