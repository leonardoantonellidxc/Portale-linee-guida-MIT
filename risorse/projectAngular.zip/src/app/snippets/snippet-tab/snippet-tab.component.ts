import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-tab',
  templateUrl: './snippet-tab.component.html',
  styleUrls: ['./snippet-tab.component.scss']
})
export class SnippetTabComponent {

  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2');
          break;
        case 'draft':
          alert('Draft action here');
          break;
        case 'save':
          alert('Save action here');
          break;
        default:
          alert('no default functions for case: ' + buttonCase);
      }
    }
  }

  tab = {
    items: [
      {
        id: 'tab0-1',
        type: 'active',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab0-2',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "draft",
      },
      {
        id: 'tab0-3',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab0-4',
        type: 'disabled',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "draft",
      },
    ]
  }

  tab_light = {
    type: 'light',
    id: 'myTab1',
    role: 'tablist',
    items: [
      {
        id: 'tab1-1',
        type: 'active',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "draft",
      },
      {
        id: 'tab1-2',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab1-3',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab1-4',
        type: 'disabled',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
    ]
  }

  tab_white = {
    type: 'white',
    items: [
      {
        id: 'tab2-1',
        type: 'active',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab2-2',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab2-3',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
      {
        id: 'tab2-4',
        type: 'disabled',
        link: '#',
        text: 'Label text',
        sprite_example: '#it-example',
        button_action: "save",
      },
    ]
  }
}
