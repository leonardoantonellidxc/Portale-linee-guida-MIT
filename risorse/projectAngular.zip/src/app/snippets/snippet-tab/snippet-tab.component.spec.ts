import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetTabComponent } from './snippet-tab.component';

describe('SnippetTabComponent', () => {
  let component: SnippetTabComponent;
  let fixture: ComponentFixture<SnippetTabComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SnippetTabComponent]
    });
    fixture = TestBed.createComponent(SnippetTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
