import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetModaliComponent } from './snippet-modali.component';

describe('SnippetModaliComponent', () => {
  let component: SnippetModaliComponent;
  let fixture: ComponentFixture<SnippetModaliComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnippetModaliComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SnippetModaliComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
