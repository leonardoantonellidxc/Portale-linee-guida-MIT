import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnippetAccordionComponent } from './snippet-accordion.component';

describe('SnippetAccordionComponent', () => {
  let component: SnippetAccordionComponent;
  let fixture: ComponentFixture<SnippetAccordionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnippetAccordionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SnippetAccordionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
