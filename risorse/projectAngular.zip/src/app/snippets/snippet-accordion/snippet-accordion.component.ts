import { Component } from '@angular/core';

@Component({
  selector: 'app-snippet-accordion',
  templateUrl: './snippet-accordion.component.html',
  styleUrls: ['./snippet-accordion.component.scss']
})
export class SnippetAccordionComponent {
  //dati di esempio


  ob_buttons = [
    { button_action: "save", button_text: "Button text1" },
    { button_action: "draft", bg_white: true, button_text: "Button text2" }
  ]

  //esempi di funzione strutturata di ritorno da passare al componente
  actionFunc = (buttonCase: string) => {
    if (buttonCase) {
      switch (buttonCase) {
        case 'back':
          window.location.replace('/events/page/2')
          break
        //per esempio cambio pagina per andare alla precedente o compio azioni da definire
        case 'draft':
          alert('Draft action here')
          break
        case 'save':
          alert('Save action here')
          break
        default:
          alert('no default functions for case: ' + buttonCase)
        //alert di default se il caso non matcha i precedenti
      }
    }
  }

  object_accordion = [
    { title: 'Elemento Richiudibile #1', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. #1', buttons: this.ob_buttons,sprite: "#it-example", },
    { title: 'Elemento Richiudibile #2', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. #2', buttons: this.ob_buttons,sprite: "#it-example", },
    { title: 'Elemento Richiudibile #3', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. #3', buttons: this.ob_buttons,sprite: "#it-example", },
  ]
}
