import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'project36angular';

  header = {
    nav_left_menu: [
      {
        link: '',
        name: 'Item'
      },
      {
        link: '',
        name: 'Item'
      },
      {
        link: '',
        name: 'Item'
      },
      {
        link: '',
        name: 'Item'
      },
      {
        link: '',
        name: 'Item'
      },
      {
        link: '',
        name: 'Item',
        is_disabled: true
      },
    ],
    portal_name_line1: 'Nome del portale',
    portal_name_line2: 'verticale',
    input_search: {
      placeholder: 'Search',
      value: '',
      aria_label: 'Lorem ipsum dolor sit'
    },
    logged_in_link: '#',
    menu_items: [
      {
        demon_menu_key: '1',
        demon_menu_nav: 'true',
        is_active: true,
        is_disabled: false,
        title: 'Home',
        has_svg: true,
      },
      {
        demon_menu_key: '2',
        demon_menu_nav: 'true',
        data_toggle: 'dropdown',
        is_active: false,
        is_disabled: false,
        is_dropdown: true,
        title: 'Componenti A-B',
        has_svg: true,
        anchor_role: 'button',
        anchor_aria_exanded: 'false',
        expand: true,
        dd_menu_items: [
          {
            demon_menu_key: '2-200',
            demon_menu_nav: 'true',
            link: 'accordion',
            name: 'Accordion'
          },
          {
            demon_menu_key: '2-201',
            demon_menu_nav: 'true',
            link: 'bottom-bar',
            name: 'Bottom bar'
          },
        ]
      },
      {
        demon_menu_key: '3',
        demon_menu_nav: 'false',
        data_toggle: 'dropdown',
        is_active: false,
        is_disabled: false,
        is_dropdown: true,
        title: 'Componenti C-D',
        has_svg: true,
        anchor_role: 'button',
        anchor_aria_exanded: 'false',
        expand: true,
        dd_menu_items: [
          {
            demon_menu_key: '3-300',
            demon_menu_nav: 'true',
            link: 'card',
            name: 'Card'
          },
          {
            demon_menu_key: '3-301',
            demon_menu_nav: 'true',
            link: 'dropdown',
            name: 'Dropdown'
          },
          {
            demon_menu_key: '3-302',
            demon_menu_nav: 'true',
            link: 'hero_banner',
            name: 'Hero banner'
          },
          {
            demon_menu_key: '3-303',
            demon_menu_nav: 'true',
            link: 'modali',
            name: 'Modali'
          },
        ]
      },
      {
        demon_menu_key: '4',
        demon_menu_nav: 'false',
        data_toggle: 'dropdown',
        is_active: false,
        is_disabled: false,
        is_dropdown: true,
        title: 'Componenti E-Z',
        has_svg: true,
        anchor_role: 'button',
        anchor_aria_exanded: 'false',
        expand: true,
        dd_menu_items: [
          {
            demon_menu_key: '4-400',
            demon_menu_nav: 'true',
            link: 'pagination',
            name: 'Pagination'
          },
          {
            demon_menu_key: '4-401',
            demon_menu_nav: 'true',
            link: 'sidebar_navigation',
            name: 'Sidebar navigation'
          },
          {
            demon_menu_key: '4-402',
            demon_menu_nav: 'true',
            link: 'stepper',
            name: 'Stepper'
          },
          {
            demon_menu_key: '4-403',
            demon_menu_nav: 'true',
            link: 'tab',
            name: 'Tab'
          },
          {
            demon_menu_key: '4-404',
            demon_menu_nav: 'true',
            link: 'table',
            name: 'Table'
          },
          {
            demon_menu_key: '4-405',
            demon_menu_nav: 'true',
            link: 'timeline',
            name: 'Timeline'
          },
        ]
      },
      {
        demon_menu_key: '5',
        demon_menu_nav: 'false',
        data_toggle: 'dropdown',
        is_active: false,
        is_disabled: false,
        is_dropdown: true,
        title: 'Form',
        has_svg: true,
        anchor_role: 'button',
        anchor_aria_exanded: 'false',
        expand: true,
        dd_menu_items: [
          {
            demon_menu_key: '5-400',
            demon_menu_nav: 'true',
            link: 'date_picker',
            name: 'Date picker'
          },
          {
            demon_menu_key: '5-401',
            demon_menu_nav: 'true',
            link: 'input',
            name: 'Input'
          },
          {
            demon_menu_key: '5-402',
            demon_menu_nav: 'true',
            link: 'input_search',
            name: 'Input search'
          },
          {
            demon_menu_key: '5-403',
            demon_menu_nav: 'true',
            link: 'select',
            name: 'Select'
          },
          {
            demon_menu_key: '5-404',
            demon_menu_nav: 'true',
            link: 'slider',
            name: 'Slider'
          },
          {
            demon_menu_key: '5-405',
            demon_menu_nav: 'true',
            link: 'uploader',
            name: 'Uploader'
          },
        ]
      },
      {
        demon_menu_key: '6',
        mega_menu: true,
        demon_menu_nav: 'false',
        data_toggle: 'dropdown',
        is_active: false,
        is_disabled: false,
        is_dropdown: true,
        title: 'Mega menù',
        has_svg: true,
        anchor_role: 'button',
        anchor_aria_exanded: 'false',
        expand: true,
        dd_menu_cards: [
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit...`,
            label_text: 'Label text'
          },
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit...`,
            label_text: 'Label text'
          },
        ],
        dd_menu_most_used: [
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do elit consectetur.`,
            label: 'Label',
            label_text: 'Label text'
          },
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do elit consectetur.`,
            label: 'Label',
            label_text: 'Label text'
          },
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do elit consectetur.`,
            label: 'Label',
            label_text: 'Label text'
          },
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do elit consectetur.`,
            label: 'Label',
            label_text: 'Label text'
          },
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do elit consectetur.`,
            label: 'Label',
            label_text: 'Label text'
          },
          {
            title: 'Servizio/Voce di menù',
            text: `Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do elit consectetur.`,
            label: 'Label',
            label_text: 'Label text'
          },

        ]
      },
      {
        demon_menu_key: '10',
        demon_menu_nav: 'false',
        is_active: false,
        is_disabled: true,
        is_dropdown: false,
        title: 'Disable',
        has_svg: true,
        anchor_aria_exanded: 'false',
      }
    ]
  }

  footer = {
    cols: [
      {
        title: 'Label text',
        rows: [
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
        ]
      },
      {
        title: 'Label text',
        rows: [
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
        ]
      },
      {
        title: 'Label text',
        rows: [
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
          {
            link: '#',
            text: 'Label text'
          },
        ]
      },
      {
        title: 'Title description',
        text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud.`,
        cols: [
          {
            link: '',
            text: 'Link 1'
          },
          {
            link: '',
            text: 'Link 2'
          },
          {
            link: '',
            text: 'Link 3'
          },
          {
            link: '',
            text: 'Link 4'
          },
        ]
      }
    ],
    middle: [
      {
        head: 'progetto finanziato da',
        label_text1: 'Label text',
        label_text2: 'Label text'
      },
      {
        head: 'progetto finanziato da',
        label_text1: 'Label text',
        label_text2: 'Label text'
      },
      {
        head: 'progetto finanziato da',
        label_text1: 'Label text',
        label_text2: 'Label text'
      },
      {
        head: 'progetto finanziato da',
        label_text1: 'Label text',
        label_text2: 'Label text'
      },
    ],
    bottom: [
      {
        link: '#',
        text: 'Media Policy'
      },
      {
        link: '#',
        text: 'Note legali'
      },
      {
        link: '#',
        text: 'Privacy Policy'
      },
      {
        link: '#',
        text: 'Mappa del sito'
      },
      {
        link: '#',
        text: 'Dichiarazioni di accessibilità'
      },
    ]
  }
}
