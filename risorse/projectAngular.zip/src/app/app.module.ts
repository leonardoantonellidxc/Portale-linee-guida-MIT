import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TimelineComponent } from './lib36/components/timeline/timeline.component';
import { SnippetTimelineComponent } from './snippets/snippet-timeline/snippet-timeline.component';
import { AccordionComponent } from './lib36/components/accordion/accordion.component';
import { SnippetAccordionComponent } from './snippets/snippet-accordion/snippet-accordion.component';
import { SnippetBottomBarComponent } from './snippets/snippet-bottom-bar/snippet-bottom-bar.component';
import { BottomBarComponent } from './lib36/components/bottom-bar/bottom-bar.component';
import { SnippetModaliComponent } from './snippets/snippet-modali/snippet-modali.component';
import { ModaliComponent } from './lib36/components/modali/modali.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CardComponent } from './lib36/components/card/card.component';
import { DropdownComponent } from './lib36/components/dropdown/dropdown.component';
import { PaginationComponent } from './lib36/components/pagination/pagination.component';
import { StepperComponent } from './lib36/components/stepper/stepper.component';
import { TabComponent } from './lib36/components/tab/tab.component';
import { TableComponent } from './lib36/components/table/table.component';
import { DatePickerComponent } from './lib36/components/form/date-picker/date-picker.component';
import { InputComponent } from './lib36/components/form/input/input.component';
import { InputSearchComponent } from './lib36/components/form/input-search/input-search.component';
import { SelectComponent } from './lib36/components/form/select/select.component';
import { SliderComponent } from './lib36/components/form/slider/slider.component';
import { UploaderComponent } from './lib36/components/form/uploader/uploader.component';
import { SnippetCardComponent } from './snippets/snippet-card/snippet-card.component';
import { SnippetDropdownComponent } from './snippets/snippet-dropdown/snippet-dropdown.component';
import { SnippetPaginationComponent } from './snippets/snippet-pagination/snippet-pagination.component';
import { SnippetStepperComponent } from './snippets/snippet-stepper/snippet-stepper.component';
import { SnippetTabComponent } from './snippets/snippet-tab/snippet-tab.component';
import { SnippetTableComponent } from './snippets/snippet-table/snippet-table.component';
import { SnippetDatePickerComponent } from './snippets/form/snippet-date-picker/snippet-date-picker.component';
import { SnippetInputComponent } from './snippets/form/snippet-input/snippet-input.component';
import { SnippetInputSearchComponent } from './snippets/form/snippet-input-search/snippet-input-search.component';
import { SnippetSelectComponent } from './snippets/form/snippet-select/snippet-select.component';
import { SnippetSliderComponent } from './snippets/form/snippet-slider/snippet-slider.component';
import { SnippetUploaderComponent } from './snippets/form/snippet-uploader/snippet-uploader.component';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './lib36/components/header/header.component';
import { FooterComponent } from './lib36/components/footer/footer.component';
import { HeroBannerComponent } from './lib36/components/hero-banner/hero-banner.component';
import { SidebarNavigationComponent } from './lib36/components/sidebar-navigation/sidebar-navigation.component';
import { SnippetHeroBannerComponent } from './snippets/snippet-hero-banner/snippet-hero-banner.component';
import { SnippetSidebarNavigationComponent } from './snippets/snippet-sidebar-navigation/snippet-sidebar-navigation.component';

@NgModule({
  declarations: [
    AppComponent,
    TimelineComponent,
    SnippetTimelineComponent,
    AccordionComponent,
    SnippetAccordionComponent,
    SnippetBottomBarComponent,
    BottomBarComponent,
    SnippetModaliComponent,
    ModaliComponent,
    CardComponent,
    DropdownComponent,
    PaginationComponent,
    StepperComponent,
    TabComponent,
    TableComponent,
    DatePickerComponent,
    InputComponent,
    InputSearchComponent,
    SelectComponent,
    SliderComponent,
    UploaderComponent,
    SnippetCardComponent,
    SnippetDropdownComponent,
    SnippetPaginationComponent,
    SnippetStepperComponent,
    SnippetTabComponent,
    SnippetTableComponent,
    SnippetDatePickerComponent,
    SnippetInputComponent,
    SnippetInputSearchComponent,
    SnippetSelectComponent,
    SnippetSliderComponent,
    SnippetUploaderComponent,
    HeaderComponent,
    FooterComponent,
    HeroBannerComponent,
    SidebarNavigationComponent,
    SnippetHeroBannerComponent,
    SnippetSidebarNavigationComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
