import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SnippetTimelineComponent } from './snippets/snippet-timeline/snippet-timeline.component';
import { SnippetAccordionComponent } from './snippets/snippet-accordion/snippet-accordion.component';
import { SnippetBottomBarComponent } from './snippets/snippet-bottom-bar/snippet-bottom-bar.component';
import { SnippetModaliComponent } from './snippets/snippet-modali/snippet-modali.component';
import { SnippetInputComponent } from './snippets/form/snippet-input/snippet-input.component';
import { SnippetCardComponent } from './snippets/snippet-card/snippet-card.component';
import { SnippetDropdownComponent } from './snippets/snippet-dropdown/snippet-dropdown.component';
import { ModaliComponent } from './lib36/components/modali/modali.component';
import { SnippetPaginationComponent } from './snippets/snippet-pagination/snippet-pagination.component';
import { SnippetStepperComponent } from './snippets/snippet-stepper/snippet-stepper.component';
import { SnippetTabComponent } from './snippets/snippet-tab/snippet-tab.component';
import { SnippetTableComponent } from './snippets/snippet-table/snippet-table.component';
import { SnippetInputSearchComponent } from './snippets/form/snippet-input-search/snippet-input-search.component';
import { SnippetSelectComponent } from './snippets/form/snippet-select/snippet-select.component';
import { SnippetDatePickerComponent } from './snippets/form/snippet-date-picker/snippet-date-picker.component';
import { SnippetSliderComponent } from './snippets/form/snippet-slider/snippet-slider.component';
import { SnippetUploaderComponent } from './snippets/form/snippet-uploader/snippet-uploader.component';
import { SnippetHeroBannerComponent } from './snippets/snippet-hero-banner/snippet-hero-banner.component';
import { SnippetSidebarNavigationComponent } from './snippets/snippet-sidebar-navigation/snippet-sidebar-navigation.component';


const routes: Routes = [
  { path: "timeline", component: SnippetTimelineComponent },
  { path: "accordion", component: SnippetAccordionComponent },
  { path: "bottom-bar", component: SnippetBottomBarComponent },
  { path: "modali", component: SnippetModaliComponent },
  { path: "card", component: SnippetCardComponent },
  { path: "dropdown", component: SnippetDropdownComponent },
  { path: "modali", component: SnippetModaliComponent },
  { path: "pagination", component: SnippetPaginationComponent },
  { path: "stepper", component: SnippetStepperComponent },
  { path: "tab", component: SnippetTabComponent },
  { path: "table", component: SnippetTableComponent },
  { path: "input", component: SnippetInputComponent },
  { path: "input_search", component: SnippetInputSearchComponent },
  { path: "select", component: SnippetSelectComponent },
  { path: "date_picker", component: SnippetDatePickerComponent },
  { path: "slider", component: SnippetSliderComponent },
  { path: "uploader", component: SnippetUploaderComponent },
  { path: "hero_banner", component: SnippetHeroBannerComponent },
  { path: "sidebar_navigation", component: SnippetSidebarNavigationComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
